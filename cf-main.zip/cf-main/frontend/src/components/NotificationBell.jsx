import React from 'react';
import { useStore } from '@/context/DemoStoreContext';
import { useI18n } from '@/context/I18nContext';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Bell, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';

const ICONS = {
  success: CheckCircle2, warning: AlertTriangle, info: Info,
};
const COLORS = {
  success: 'text-success', warning: 'text-warning', info: 'text-info',
};

export const NotificationBell = ({ light = false }) => {
  const { notifications, markAllNotificationsRead } = useStore();
  const { t } = useI18n();
  const unread = notifications.filter((n) => !n.read).length;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        data-testid={RAWAFID.notificationBell}
        className={`relative h-9 w-9 grid place-items-center rounded-full border transition-all ${
          light
            ? 'border-white/20 text-white/90 hover:bg-white/10'
            : 'border-border text-foreground hover:bg-muted'
        }`}
        aria-label="Notifications"
      >
        <Bell className="w-4 h-4" />
        {unread > 0 && (
          <span className="absolute -top-1 -end-1 min-w-[18px] h-[18px] rounded-full bg-accent text-accent-foreground text-[10px] font-bold grid place-items-center px-1">
            {unread}
          </span>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[360px] p-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b bg-gradient-subtle">
          <div className="font-serif-display text-base text-primary">
            {t('common.notifications')}
          </div>
          <button
            data-testid={RAWAFID.notificationMarkAll}
            type="button"
            onClick={markAllNotificationsRead}
            className="text-xs text-muted-foreground hover:text-primary"
          >
            {t('common.mark_all_read')}
          </button>
        </div>
        <div className="max-h-[360px] overflow-y-auto">
          {notifications.length === 0 && (
            <div className="py-8 text-center text-sm text-muted-foreground">
              {t('notifications.empty')}
            </div>
          )}
          {notifications.map((n) => {
            const Icon = ICONS[n.type] || Info;
            const colorClass = COLORS[n.type] || 'text-info';
            const text = n.text || t(n.key);
            return (
              <div
                key={n.id}
                className={`flex items-start gap-3 px-4 py-3 border-b last:border-b-0 hover:bg-muted/50 transition-colors ${!n.read ? 'bg-accent/[0.04]' : ''}`}
              >
                <div className={`mt-0.5 ${colorClass}`}><Icon className="w-4 h-4" /></div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-foreground">{text}</div>
                  <div className="text-[11px] text-muted-foreground mt-1">{n.time}</div>
                </div>
                {!n.read && <span className="mt-1.5 w-2 h-2 rounded-full bg-accent shrink-0" />}
              </div>
            );
          })}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
