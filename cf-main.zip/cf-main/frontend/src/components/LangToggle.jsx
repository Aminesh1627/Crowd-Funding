import React from 'react';
import { useI18n } from '@/context/I18nContext';
import { RAWAFID } from '@/constants/testIds';
import { Globe } from 'lucide-react';

export const LangToggle = ({ light = false }) => {
  const { lang, toggle } = useI18n();
  return (
    <button
      type="button"
      onClick={toggle}
      data-testid={RAWAFID.langToggle}
      className={`group inline-flex items-center gap-2 h-9 px-3 rounded-full border transition-all ${
        light
          ? 'border-white/20 text-white/90 hover:bg-white/10'
          : 'border-border text-foreground hover:bg-muted'
      }`}
      aria-label="Toggle language"
    >
      <Globe className="w-4 h-4" />
      <span className="text-sm font-medium tracking-wide">
        {lang === 'en' ? 'العربية' : 'English'}
      </span>
    </button>
  );
};
