import React from 'react';
import { useLocation } from 'react-router-dom';
import { LangToggle } from '@/components/LangToggle';
import { RoleSwitcher } from '@/components/RoleSwitcher';
import { NotificationBell } from '@/components/NotificationBell';
import { UserMenu } from '@/components/UserMenu';

// Read-only ambient header — controls are tightly grouped to the right.
export const AppHeader = () => {
  const { pathname } = useLocation();

  return (
    <header className="sticky top-0 z-30 h-16 px-5 lg:px-8 flex items-center gap-3 bg-background/85 backdrop-blur-xl border-b border-border">
      <div className="flex-1 min-w-0">
        <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/70 font-mono truncate">
          {pathname}
        </div>
      </div>
      <div className="flex items-center gap-2 ms-auto">
        <LangToggle />
        <NotificationBell />
        <RoleSwitcher compact />
        <UserMenu />
      </div>
    </header>
  );
};
