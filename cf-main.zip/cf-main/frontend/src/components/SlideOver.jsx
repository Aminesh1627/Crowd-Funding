import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { useI18n } from '@/context/I18nContext';

// Premium right-side slide-over panel.
export const SlideOver = ({ open, onClose, title, subtitle, children, width = 'lg', footer, testId }) => {
  const { dir } = useI18n();
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose?.(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const widthClass = { sm: 'w-[420px]', md: 'w-[560px]', lg: 'w-[720px]', xl: 'w-[900px]' }[width] || 'w-[720px]';

  return (
    <div
      data-testid={testId}
      className={`fixed inset-0 z-50 transition-all ${open ? 'pointer-events-auto' : 'pointer-events-none'}`}
      aria-hidden={!open}
    >
      <div
        className={`absolute inset-0 bg-primary/60 backdrop-blur-sm transition-opacity ${open ? 'opacity-100' : 'opacity-0'}`}
        onClick={onClose}
      />
      <div
        className={`absolute top-0 bottom-0 ${dir === 'rtl' ? 'left-0' : 'right-0'} ${widthClass} max-w-[95vw] bg-card border-${dir === 'rtl' ? 'r' : 'l'} border-border shadow-elegant flex flex-col transform transition-transform duration-300 ${
          open ? 'translate-x-0' : (dir === 'rtl' ? '-translate-x-full' : 'translate-x-full')
        }`}
      >
        <div className="flex items-start justify-between gap-4 px-6 py-5 border-b border-border bg-gradient-subtle">
          <div className="min-w-0 flex-1">
            <h2 className="font-serif-display text-2xl text-primary leading-tight truncate">{title}</h2>
            {subtitle && <div className="text-xs text-muted-foreground mt-1">{subtitle}</div>}
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 grid place-items-center rounded-full border border-border hover:bg-muted shrink-0"
            aria-label="Close panel"
            data-testid="slide-over-close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6">{children}</div>
        {footer && <div className="border-t border-border p-4 pe-36 bg-muted/30">{footer}</div>}
      </div>
    </div>
  );
};
