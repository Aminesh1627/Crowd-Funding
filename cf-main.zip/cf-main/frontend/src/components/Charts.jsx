import React from 'react';
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, RadialBarChart,
  RadialBar, Legend, FunnelChart, Funnel, LabelList,
} from 'recharts';

const PALETTE = ['#1d3a66', '#d4a23a', '#2d6a4f', '#4a6b8a', '#c47a2f', '#6b8e7d', '#a98a4d'];

const tooltipStyle = {
  contentStyle: {
    background: 'hsl(215 45% 12% / 0.95)',
    border: '1px solid hsl(40 75% 52% / 0.3)',
    borderRadius: 12,
    color: 'white',
    fontSize: 12,
    padding: '10px 14px',
  },
  itemStyle: { color: 'white' },
  labelStyle: { color: 'hsl(40 75% 70%)', fontWeight: 600, marginBottom: 4 },
  cursor: { fill: 'hsl(40 75% 52% / 0.1)' },
};

export const ProfitAreaChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={220}>
    <AreaChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
      <defs>
        <linearGradient id="grad-profit" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#d4a23a" stopOpacity={0.5} />
          <stop offset="100%" stopColor="#d4a23a" stopOpacity={0} />
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="hsl(215 18% 88%)" vertical={false} />
      <XAxis dataKey="m" tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <Tooltip {...tooltipStyle} />
      <Area type="monotone" dataKey="profit" stroke="#d4a23a" strokeWidth={2.5} fill="url(#grad-profit)" />
    </AreaChart>
  </ResponsiveContainer>
);

export const CashFlowChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={220}>
    <BarChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="hsl(215 18% 88%)" vertical={false} />
      <XAxis dataKey="m" tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <Tooltip {...tooltipStyle} />
      <Bar dataKey="inflow" fill="#1d3a66" radius={[4, 4, 0, 0]} />
      <Bar dataKey="outflow" fill="#d4a23a" radius={[4, 4, 0, 0]} />
    </BarChart>
  </ResponsiveContainer>
);

export const PieAllocChart = ({ data, donut = true }) => (
  <ResponsiveContainer width="100%" height={220}>
    <PieChart>
      <Pie
        data={data} dataKey="value" nameKey="name"
        cx="50%" cy="50%" innerRadius={donut ? 56 : 0} outerRadius={84}
        paddingAngle={2} stroke="hsl(0 0% 100%)" strokeWidth={2}
      >
        {data.map((_, i) => (
          <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
        ))}
      </Pie>
      <Tooltip {...tooltipStyle} />
    </PieChart>
  </ResponsiveContainer>
);

export const RiskRadialChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={220}>
    <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="100%" data={data} startAngle={90} endAngle={-270}>
      <RadialBar background dataKey="value" cornerRadius={6}>
        {data.map((_, i) => (
          <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
        ))}
      </RadialBar>
      <Tooltip {...tooltipStyle} />
    </RadialBarChart>
  </ResponsiveContainer>
);

export const FundingComboChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={260}>
    <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="hsl(215 18% 88%)" vertical={false} />
      <XAxis dataKey="m" tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <Tooltip {...tooltipStyle} />
      <Bar dataKey="target" fill="hsl(215 18% 88%)" radius={[6, 6, 0, 0]} />
      <Bar dataKey="funded" fill="#d4a23a" radius={[6, 6, 0, 0]} />
    </BarChart>
  </ResponsiveContainer>
);

export const HorizontalBarChart = ({ data, dataKey = 'value', color = '#1d3a66' }) => (
  <ResponsiveContainer width="100%" height={Math.max(180, data.length * 40)}>
    <BarChart layout="vertical" data={data} margin={{ left: 20, right: 30, top: 0, bottom: 0 }}>
      <XAxis type="number" hide />
      <YAxis dataKey={data[0] && data[0].stage ? 'stage' : 'sector'} type="category" tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} width={90} />
      <Tooltip {...tooltipStyle} />
      <Bar dataKey={dataKey} fill={color} radius={[0, 6, 6, 0]}>
        {data.map((_, i) => (
          <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
        ))}
      </Bar>
    </BarChart>
  </ResponsiveContainer>
);

export const LineTrendChart = ({ data, keys = [{ key: 'flags', color: '#c44545' }, { key: 'resolved', color: '#2d6a4f' }] }) => (
  <ResponsiveContainer width="100%" height={220}>
    <LineChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="hsl(215 18% 88%)" vertical={false} />
      <XAxis dataKey="m" tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fill: 'hsl(215 18% 38%)', fontSize: 11 }} axisLine={false} tickLine={false} />
      <Tooltip {...tooltipStyle} />
      {keys.map((k) => (
        <Line key={k.key} type="monotone" dataKey={k.key} stroke={k.color} strokeWidth={2.5} dot={{ r: 3 }} />
      ))}
    </LineChart>
  </ResponsiveContainer>
);
