import React from 'react';
import { useAuth, MOCK_USERS, ROLE_KEYS } from '@/context/AuthContext';
import { useI18n } from '@/context/I18nContext';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ChevronDown, ChevronsUpDown, Briefcase, Building2, ShieldCheck, Scale } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';

const ICONS = {
  investor: Briefcase, borrower: Building2, admin: ShieldCheck, regulator: Scale,
};
const TEST_IDS = {
  investor: RAWAFID.roleSwitcherInvestor,
  borrower: RAWAFID.roleSwitcherBorrower,
  admin: RAWAFID.roleSwitcherAdmin,
  regulator: RAWAFID.roleSwitcherRegulator,
};

export const RoleSwitcher = ({ light = false, compact = false }) => {
  const { role, switchRole } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();

  const current = role || 'investor';
  const CurrentIcon = ICONS[current];

  const handleSelect = (r) => {
    switchRole(r);
    navigate('/app/dashboard');
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        data-testid={RAWAFID.roleSwitcherTrigger}
        className={`group inline-flex items-center gap-2 h-9 px-3 rounded-full border transition-all ${
          light
            ? 'border-accent/40 bg-white/5 text-white hover:bg-white/10'
            : 'border-accent/40 bg-accent/10 text-primary hover:bg-accent/20'
        }`}
      >
        <CurrentIcon className="w-4 h-4 text-accent" />
        {!compact && (
          <>
            <span className="text-xs uppercase tracking-[0.18em] opacity-70">
              {t('common.preview_mode')}
            </span>
            <span className="text-sm font-semibold">
              {t(`roles.${current}`)}
            </span>
          </>
        )}
        <ChevronsUpDown className="w-3.5 h-3.5 opacity-70" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72 p-1">
        <DropdownMenuLabel className="px-3 py-2">
          <div className="font-serif-display text-base text-primary">
            {t('common.open_role_switcher')}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {t('login.role_picker_sub')}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {ROLE_KEYS.map((r) => {
          const Icon = ICONS[r];
          const user = MOCK_USERS[r];
          const active = current === r;
          return (
            <DropdownMenuItem
              key={r}
              data-testid={TEST_IDS[r]}
              onClick={() => handleSelect(r)}
              className={`flex items-start gap-3 p-3 rounded-md cursor-pointer ${active ? 'bg-accent/10' : ''}`}
            >
              <div className={`w-9 h-9 rounded-full grid place-items-center shrink-0 ${active ? 'bg-accent text-accent-foreground' : 'bg-muted text-primary'}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-foreground flex items-center gap-2">
                  {t(`roles.${r}`)}
                  {active && (
                    <span className="text-[10px] uppercase tracking-[0.18em] text-accent">
                      ●
                    </span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  {user.name} · {user.email}
                </div>
                <div className="text-[11px] text-muted-foreground/80 mt-0.5">
                  {t(`roles.${r}_desc`)}
                </div>
              </div>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
