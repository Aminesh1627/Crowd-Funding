import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { useI18n } from '@/context/I18nContext';
import { useNavigate, Link } from 'react-router-dom';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { User, Settings, LogOut, HelpCircle } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';

export const UserMenu = ({ light = false }) => {
  const { user, role, logout } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        data-testid={RAWAFID.userMenuTrigger}
        className={`inline-flex items-center gap-2 h-9 ps-1 pe-3 rounded-full border transition-all ${
          light
            ? 'border-white/20 text-white hover:bg-white/10'
            : 'border-border text-foreground hover:bg-muted'
        }`}
      >
        <span
          className="w-7 h-7 rounded-full grid place-items-center text-xs font-bold text-primary-foreground"
          style={{ background: `hsl(${user.avatarHue} 50% 30%)` }}
        >
          {user.initials}
        </span>
        <span className="hidden sm:flex flex-col items-start leading-tight">
          <span className="text-xs font-semibold">{user.name}</span>
          <span className="text-[10px] uppercase tracking-[0.16em] opacity-70">
            {t(`roles.${role}`)}
          </span>
        </span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64 p-1">
        <DropdownMenuLabel className="px-3 py-2">
          <div className="text-sm font-semibold text-foreground">{user.name}</div>
          <div className="text-xs text-muted-foreground">{user.email}</div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          data-testid={RAWAFID.userMenuProfile}
          onClick={() => navigate('/app/profile')}
          className="cursor-pointer gap-2"
        >
          <User className="w-4 h-4" /> {t('common.profile')}
        </DropdownMenuItem>
        <DropdownMenuItem className="cursor-pointer gap-2">
          <Settings className="w-4 h-4" /> {t('common.settings')}
        </DropdownMenuItem>
        <DropdownMenuItem className="cursor-pointer gap-2">
          <HelpCircle className="w-4 h-4" /> {t('common.help')}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          data-testid={RAWAFID.userMenuSignOut}
          onClick={() => { logout(); navigate('/'); }}
          className="cursor-pointer gap-2 text-destructive focus:text-destructive"
        >
          <LogOut className="w-4 h-4" /> {t('common.sign_out')}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
