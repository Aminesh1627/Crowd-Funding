import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

// Premium KPI tile with optional sparkline-style accent bar
export const KpiTile = ({ label, value, sub, delta, icon: Icon, accent = false, testId }) => {
  const positive = delta && delta.value >= 0;
  return (
    <div
      data-testid={testId}
      className={`group relative overflow-hidden rounded-xl p-5 border ${
        accent
          ? 'bg-gradient-primary text-primary-foreground border-accent/30 shadow-elegant'
          : 'bg-card text-card-foreground border-border shadow-card-elegant hover:shadow-elegant'
      } transition-all hover-lift`}
    >
      {/* corner ornament */}
      <div className={`absolute -top-12 -end-12 w-32 h-32 rounded-full ${accent ? 'bg-accent/15' : 'bg-accent/[0.05]'} blur-2xl pointer-events-none`} />
      <div className="relative flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className={`text-[11px] uppercase tracking-[0.18em] ${accent ? 'text-accent/90' : 'text-muted-foreground'} font-medium`}>
            {label}
          </div>
          <div className={`mt-3 font-serif-display text-3xl ${accent ? 'text-white' : 'text-primary'} num-display`}>
            {value}
          </div>
          {sub && (
            <div className={`mt-1 text-xs ${accent ? 'text-white/70' : 'text-muted-foreground'}`}>
              {sub}
            </div>
          )}
        </div>
        {Icon && (
          <div className={`w-10 h-10 rounded-lg grid place-items-center shrink-0 ${
            accent ? 'bg-white/10 text-accent' : 'bg-accent/10 text-accent'
          }`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
      {delta && (
        <div className={`relative mt-3 inline-flex items-center gap-1 text-xs font-medium ${
          positive ? 'text-success' : 'text-destructive'
        }`}>
          {positive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
          <span>{positive ? '+' : ''}{delta.value}%</span>
          <span className={accent ? 'text-white/60' : 'text-muted-foreground'}>· {delta.label}</span>
        </div>
      )}
    </div>
  );
};

export const GlassCard = ({ className = '', children, ...props }) => (
  <div
    className={`rounded-xl p-6 bg-card border border-border shadow-card-elegant ${className}`}
    {...props}
  >
    {children}
  </div>
);

export const SectionHeader = ({ kicker, title, action }) => (
  <div className="flex items-end justify-between gap-3 mb-5">
    <div>
      {kicker && (
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {kicker}
        </div>
      )}
      <h2 className="font-serif-display text-2xl text-primary">{title}</h2>
    </div>
    {action}
  </div>
);

export const StatusPill = ({ tone = 'info', children }) => {
  const tones = {
    success: 'bg-success/10 text-success border-success/20',
    warning: 'bg-warning/10 text-warning border-warning/20',
    danger: 'bg-destructive/10 text-destructive border-destructive/20',
    info: 'bg-info/10 text-info border-info/20',
    neutral: 'bg-muted text-muted-foreground border-border',
    gold: 'bg-accent/15 text-accent border-accent/30',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${tones[tone]}`}>
      {children}
    </span>
  );
};

export const RiskBadge = ({ grade }) => {
  const colors = {
    AAA: 'gold', AA: 'success', A: 'info', BBB: 'neutral', BB: 'warning', B: 'danger',
  };
  return <StatusPill tone={colors[grade] || 'neutral'}>{grade}</StatusPill>;
};
