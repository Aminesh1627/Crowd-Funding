import React from 'react';
import { useI18n } from '@/context/I18nContext';

// Premium serif brand mark. Includes Arabic alt when in RTL.
export const Logo = ({ size = 'md', light = false, withTag = false }) => {
  const { lang, t } = useI18n();
  const sizes = {
    sm: { mark: 28, font: 'text-lg' },
    md: { mark: 36, font: 'text-2xl' },
    lg: { mark: 56, font: 'text-4xl' },
  };
  const s = sizes[size] || sizes.md;
  return (
    <div className="inline-flex items-center gap-3 select-none">
      <div className="relative" style={{ width: s.mark, height: s.mark }}>
        <svg viewBox="0 0 48 48" width={s.mark} height={s.mark} aria-hidden>
          <defs>
            <linearGradient id="rwfgold" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#d4a23a" />
              <stop offset="100%" stopColor="#f6cf6a" />
            </linearGradient>
            <linearGradient id="rwfnavy" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0e2342" />
              <stop offset="100%" stopColor="#1d3a66" />
            </linearGradient>
          </defs>
          <circle cx="24" cy="24" r="22" fill={light ? 'url(#rwfgold)' : 'url(#rwfnavy)'} />
          <path d="M14 32 L24 14 L34 32 Z" fill={light ? '#0e2342' : 'url(#rwfgold)'} />
          <circle cx="24" cy="26" r="3.4" fill={light ? '#0e2342' : 'url(#rwfgold)'} stroke={light ? '#f6cf6a' : '#0e2342'} strokeWidth="1.5" />
        </svg>
      </div>
      <div className="flex flex-col leading-tight">
        <span className={`font-serif-display ${s.font} ${light ? 'text-white' : 'text-primary'} tracking-tight`}>
          {lang === 'ar' ? 'روافد' : 'Rawafid'}
        </span>
        {withTag && (
          <span className={`text-[11px] uppercase tracking-[0.18em] ${light ? 'text-accent/90' : 'text-muted-foreground'}`}>
            {t('brand.tagline')}
          </span>
        )}
      </div>
    </div>
  );
};
