import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useI18n } from '@/context/I18nContext';
import {
  LayoutDashboard, Compass, PieChart, User, Plus, FolderKanban,
  ClipboardList, Users, ShieldCheck, FileText, Scale, BarChart3,
  Wallet, LifeBuoy, RefreshCcw, CheckSquare, GitBranch, Sparkles,
  KeyRound, Layers, ScrollText, Globe, Gavel, Briefcase,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RAWAFID } from '@/constants/testIds';

const investorNav = [
  { kind: 'item', key: 'dashboard', to: '/app/dashboard', icon: LayoutDashboard, label: 'nav.dashboard' },
  { kind: 'item', key: 'marketplace', to: '/app/marketplace', icon: Compass, label: 'investor.marketplace' },
  { kind: 'item', key: 'portfolio', to: '/app/portfolio', icon: PieChart, label: 'nav.portfolio' },
  { kind: 'item', key: 'wallet', to: '/app/wallet', icon: Wallet, label: 'nav.wallet' },
  { kind: 'item', key: 'support', to: '/app/support', icon: LifeBuoy, label: 'nav.support' },
  { kind: 'item', key: 'profile', to: '/app/profile', icon: User, label: 'nav.profile' },
];

const borrowerNav = [
  { kind: 'item', key: 'dashboard', to: '/app/dashboard', icon: LayoutDashboard, label: 'nav.dashboard' },
  { kind: 'item', key: 'create', to: '/app/create', icon: Plus, label: 'nav.create' },
  { kind: 'item', key: 'my-campaigns', to: '/app/my-campaigns', icon: FolderKanban, label: 'nav.my_campaigns' },
  { kind: 'item', key: 'repayments', to: '/app/repayments', icon: RefreshCcw, label: 'nav.repayments' },
  { kind: 'item', key: 'subscription', to: '/app/subscription', icon: CheckSquare, label: 'nav.subscription' },
  { kind: 'item', key: 'support', to: '/app/support', icon: LifeBuoy, label: 'nav.support' },
  { kind: 'item', key: 'profile', to: '/app/profile', icon: User, label: 'nav.profile' },
];

const adminNav = [
  { kind: 'item', key: 'dashboard', to: '/app/dashboard', icon: LayoutDashboard, label: 'nav.dashboard' },
  { kind: 'item', key: 'create', to: '/app/create', icon: Plus, label: 'nav.create' },
  { kind: 'item', key: 'marketplace', to: '/app/marketplace', icon: Compass, label: 'nav.market_admin' },
  { kind: 'group', label: 'nav.group_officers' },
  { kind: 'item', key: 'credit', to: '/app/credit-officer', icon: Briefcase, label: 'nav.credit_officer' },
  { kind: 'item', key: 'risk', to: '/app/risk-officer', icon: ShieldCheck, label: 'nav.risk_officer' },
  { kind: 'item', key: 'onboarding', to: '/app/onboarding-officer', icon: Sparkles, label: 'nav.onboarding_officer' },
  { kind: 'item', key: 'compliance-officer', to: '/app/compliance-officer', icon: Gavel, label: 'nav.compliance_officer' },
  { kind: 'group', label: 'nav.group_engine' },
  { kind: 'item', key: 'workflow', to: '/app/workflow', icon: GitBranch, label: 'nav.workflow' },
  { kind: 'item', key: 'decision-engine', to: '/app/decision-engine', icon: Layers, label: 'nav.decision_engine' },
  { kind: 'group', label: 'nav.group_admin' },
  { kind: 'item', key: 'manage-users', to: '/app/manage-users', icon: Users, label: 'nav.manage_user' },
  { kind: 'item', key: 'manage-roles', to: '/app/manage-roles', icon: KeyRound, label: 'nav.manage_role' },
  { kind: 'item', key: 'manage-groups', to: '/app/manage-groups', icon: Users, label: 'nav.manage_group' },
  { kind: 'group', label: 'nav.group_master' },
  { kind: 'item', key: 'master-loan', to: '/app/master/loan', icon: ScrollText, label: 'nav.master_loan' },
  { kind: 'item', key: 'master-doc', to: '/app/master/doc', icon: FileText, label: 'nav.master_doc' },
  { kind: 'item', key: 'master-lang', to: '/app/master/lang', icon: Globe, label: 'nav.master_lang' },
];

const regulatorNav = [
  { kind: 'item', key: 'dashboard', to: '/app/dashboard', icon: LayoutDashboard, label: 'nav.dashboard' },
  { kind: 'item', key: 'compliance', to: '/app/compliance', icon: ShieldCheck, label: 'nav.compliance' },
  { kind: 'item', key: 'audit', to: '/app/audit', icon: FileText, label: 'nav.audit' },
  { kind: 'item', key: 'law-suite', to: '/app/law-suite', icon: Scale, label: 'nav.law_suite' },
  { kind: 'item', key: 'profile', to: '/app/profile', icon: User, label: 'nav.profile' },
];

const NAV_PER_ROLE = {
  investor: investorNav,
  borrower: borrowerNav,
  admin: adminNav,
  regulator: regulatorNav,
};

export const Sidebar = () => {
  const { role } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();
  const items = NAV_PER_ROLE[role] || investorNav;

  return (
    <aside
      data-testid={RAWAFID.sidebar}
      className="hidden lg:flex w-64 shrink-0 sticky top-0 h-screen flex-col bg-gradient-royal text-white relative overflow-hidden"
    >
      <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-accent to-transparent" />
      <div className="absolute -bottom-32 -end-32 w-72 h-72 rounded-full bg-accent/10 blur-3xl pointer-events-none" />

      <button onClick={() => navigate('/')} className="flex items-center gap-3 px-6 py-6 hover:opacity-90 transition-opacity">
        <Logo size="sm" light />
      </button>

      <div className="px-4">
        <div className="text-[10px] uppercase tracking-[0.22em] text-accent/80 px-3 mb-2">
          {t(`roles.${role}`)}
        </div>
      </div>

      <nav className="px-3 flex-1 space-y-0.5 overflow-y-auto pb-4 scrollbar-thin">
        {items.map((it, i) => {
          if (it.kind === 'group') {
            return (
              <div key={`g-${i}`} className="mt-4 mb-1 px-3 text-[10px] uppercase tracking-[0.22em] text-accent/60">
                {t(it.label)}
              </div>
            );
          }
          const Icon = it.icon;
          return (
            <NavLink
              key={it.key}
              to={it.to}
              data-testid={RAWAFID.navItem(it.key)}
              end={it.to === '/app/dashboard'}
              className={({ isActive }) => `
                group flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all
                ${isActive
                  ? 'bg-white/10 text-white shadow-inner ring-1 ring-accent/30 [&_svg]:text-accent'
                  : 'text-white/75 hover:text-white hover:bg-white/5 [&_svg]:text-white/60 [&_svg]:group-hover:text-accent/80'}
              `}
            >
              <Icon className="w-4 h-4" />
              <span className="font-medium">{t(it.label)}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="p-4 mt-auto shrink-0">
        <div className="rounded-xl p-4 border border-accent/20 bg-white/5 backdrop-blur-sm">
          <div className="flex items-center gap-2 text-accent text-xs uppercase tracking-[0.18em] mb-2">
            <BarChart3 className="w-3.5 h-3.5" />
            {t('common.preview_mode')}
          </div>
          <p className="text-xs text-white/70 leading-relaxed">
            Phase 1 frontend prototype. All data is mocked locally.
          </p>
        </div>
      </div>
    </aside>
  );
};
