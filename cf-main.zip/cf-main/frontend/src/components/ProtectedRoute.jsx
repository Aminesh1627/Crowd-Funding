import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

export const ProtectedRoute = () => {
  const { authed } = useAuth();
  if (!authed) return <Navigate to="/login" replace />;
  return <Outlet />;
};
