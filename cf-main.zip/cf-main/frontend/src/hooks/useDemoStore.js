import { useEffect, useState, useCallback } from 'react';
import {
  seedCampaigns, seedInvestments, seedRepayments, seedNotifications,
  seedReviewQueue, seedUsers, seedAuditLogs, seedComplianceFlags,
} from '@/data/mockData';
import {
  seedEscrowTransactions, seedSupportTickets, seedDecisionRules,
  seedRoles, seedGroups, seedLoanTypes, seedDocTypes, seedLanguageSettings,
  seedLawSuiteCases,
} from '@/data/mockDataV2';

// Generic localStorage-backed state
const useLocalState = (key, seedFn) => {
  const [state, setState] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const seeded = seedFn();
    localStorage.setItem(key, JSON.stringify(seeded));
    return seeded;
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);

  return [state, setState];
};

export const useDemoStore = () => {
  const [campaigns, setCampaigns] = useLocalState('rwf_campaigns', seedCampaigns);
  const [investments, setInvestments] = useLocalState('rwf_investments', seedInvestments);
  const [repayments, setRepayments] = useLocalState('rwf_repayments', seedRepayments);
  const [notifications, setNotifications] = useLocalState('rwf_notifications', seedNotifications);
  const [reviewQueue, setReviewQueue] = useLocalState('rwf_review_queue', seedReviewQueue);
  const [users, setUsers] = useLocalState('rwf_users', seedUsers);
  const [auditLogs, setAuditLogs] = useLocalState('rwf_audit', seedAuditLogs);
  const [complianceFlags, setComplianceFlags] = useLocalState('rwf_compliance', seedComplianceFlags);
  const [wallet, setWallet] = useLocalState('rwf_wallet', () => ({ available: 12450, reserved: 4200 }));
  const [escrow, setEscrow] = useLocalState('rwf_escrow', seedEscrowTransactions);
  const [tickets, setTickets] = useLocalState('rwf_tickets', seedSupportTickets);
  const [decisionRules, setDecisionRules] = useLocalState('rwf_rules', seedDecisionRules);
  const [adminRoles, setAdminRoles] = useLocalState('rwf_roles', seedRoles);
  const [adminGroups, setAdminGroups] = useLocalState('rwf_groups', seedGroups);
  const [loanTypes, setLoanTypes] = useLocalState('rwf_loanTypes', seedLoanTypes);
  const [docTypes, setDocTypes] = useLocalState('rwf_docTypes', seedDocTypes);
  const [languageSettings, setLanguageSettings] = useLocalState('rwf_langSettings', seedLanguageSettings);
  const [lawSuite, setLawSuite] = useLocalState('rwf_lawsuite', seedLawSuiteCases);

  const pushNotification = useCallback((payload) => {
    setNotifications((prev) => [{ id: Date.now(), read: false, time: 'just now', ...payload }, ...prev]);
  }, [setNotifications]);

  const pushAudit = useCallback((entry) => {
    const at = new Date().toISOString().replace('T', ' ').slice(0, 19);
    setAuditLogs((prev) => [{ id: `L-${Date.now()}`, at, severity: 'info', ...entry }, ...prev]);
  }, [setAuditLogs]);

  const pushEscrow = useCallback((entry) => {
    const date = new Date().toISOString().slice(0, 10);
    setEscrow((prev) => [{ id: `TX-${Date.now()}`, date, ...entry }, ...prev]);
  }, [setEscrow]);

  const investInCampaign = useCallback((campaignId, amount) => {
    const c = campaigns.find((x) => x.id === campaignId);
    if (!c) return false;
    setCampaigns((prev) => prev.map((x) => x.id === campaignId
      ? { ...x, raised: Math.min(x.target, x.raised + amount), investors: x.investors + 1 }
      : x));
    setInvestments((prev) => [{
      id: `I-${Date.now()}`, campaignId, name: c.borrower, amount,
      rate: c.rate, tenure: c.tenure, status: 'active',
      invested: new Date().toISOString().slice(0, 10), sector: c.sector,
    }, ...prev]);
    setWallet((w) => ({ available: Math.max(0, w.available - amount), reserved: w.reserved + amount }));
    pushEscrow({ type: 'invest', label: `Investment in ${campaignId}`, amount: -amount, ref: `INV-${Date.now()}` });
    pushNotification({ text: `Investment of OMR ${amount.toLocaleString()} confirmed in ${c.borrower}.`, type: 'success' });
    pushAudit({ actor: 'Omar Al-Rashdi', role: 'investor', action: `Invested OMR ${amount.toLocaleString()} in ${campaignId}`, target: campaignId });
    return true;
  }, [campaigns, setCampaigns, setInvestments, setWallet, pushNotification, pushAudit, pushEscrow]);

  const createCampaign = useCallback((data) => {
    const id = `C-${Math.floor(1100 + Math.random() * 700)}`;
    const newCampaign = {
      id, borrower: data.borrower || 'Nabat Textiles SAOC',
      borrowerInitials: 'NT', sector: data.sector || 'manufacturing',
      title: data.title || 'New Campaign', purpose: data.purpose || '',
      target: Number(data.target) || 50000, raised: 0, investors: 0,
      rate: Number(data.rate) || 11, tenure: Number(data.tenure) || 24,
      riskGrade: 'BBB', daysLeft: Number(data.duration) || 30,
      stage: 'submitted', region: 'Muscat', established: 2020,
      summary: data.purpose || '', metrics: { dscr: 1.5, dti: 0.35, ltv: 0.7, creditScore: 700 },
    };
    setCampaigns((prev) => [newCampaign, ...prev]);
    setReviewQueue((prev) => [{
      id, borrower: newCampaign.borrower, amount: newCampaign.target,
      sector: newCampaign.sector, stage: 'credit', sla: '24h', priority: 'medium', score: 700,
    }, ...prev]);
    pushNotification({ text: `Campaign ${id} submitted for credit review.`, type: 'info' });
    pushAudit({ actor: 'Layla Al-Habsi', role: 'borrower', action: `Submitted campaign ${id} for review`, target: id });
    return newCampaign;
  }, [setCampaigns, setReviewQueue, pushNotification, pushAudit]);

  const decideCampaign = useCallback((campaignId, decision) => {
    setReviewQueue((prev) => prev.filter((x) => x.id !== campaignId));
    setCampaigns((prev) => prev.map((x) => x.id === campaignId
      ? { ...x, stage: decision === 'approve' ? 'funding' : 'rejected' }
      : x));
    pushNotification({
      text: `Campaign ${campaignId} ${decision === 'approve' ? 'approved & published' : 'rejected'}.`,
      type: decision === 'approve' ? 'success' : 'warning',
    });
    pushAudit({
      actor: 'Yusuf Al-Balushi', role: 'admin',
      action: `${decision === 'approve' ? 'Approved' : 'Rejected'} campaign ${campaignId}`,
      target: campaignId, severity: decision === 'approve' ? 'success' : 'warning',
    });
  }, [setReviewQueue, setCampaigns, pushNotification, pushAudit]);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, [setNotifications]);

  const fundWallet = useCallback((amount, method = 'bank') => {
    setWallet((w) => ({ ...w, available: w.available + amount }));
    pushEscrow({ type: 'deposit', label: `Wallet top-up (${method === 'card' ? 'Card' : 'Bank transfer'})`, amount, ref: `BTR-${Date.now().toString().slice(-6)}` });
    pushNotification({ text: `Wallet funded with OMR ${amount.toLocaleString()}.`, type: 'success' });
  }, [setWallet, pushNotification, pushEscrow]);

  const withdrawFromWallet = useCallback((amount) => {
    setWallet((w) => ({ ...w, available: Math.max(0, w.available - amount) }));
    pushEscrow({ type: 'withdraw', label: 'Withdrawal to bank', amount: -amount, ref: `WTH-${Date.now().toString().slice(-6)}` });
    pushNotification({ text: `Withdrawal of OMR ${amount.toLocaleString()} initiated.`, type: 'info' });
  }, [setWallet, pushNotification, pushEscrow]);

  const submitTicket = useCallback((payload) => {
    const id = `TKT-${Date.now().toString().slice(-4)}`;
    setTickets((prev) => [{
      id, status: 'open', priority: 'medium', messages: 1,
      updated: new Date().toISOString().slice(0, 16).replace('T', ' '),
      ...payload,
    }, ...prev]);
    pushNotification({ text: `Support ticket ${id} opened.`, type: 'info' });
    return id;
  }, [setTickets, pushNotification]);

  const updateDecisionRule = useCallback((id, patch) => {
    setDecisionRules((prev) => prev.map((r) => r.id === id ? { ...r, ...patch } : r));
  }, [setDecisionRules]);

  const addDecisionRule = useCallback((rule) => {
    setDecisionRules((prev) => [{ id: `R-${Date.now().toString().slice(-3)}`, active: true, ...rule }, ...prev]);
  }, [setDecisionRules]);

  const resetDemo = useCallback(() => {
    ['rwf_campaigns', 'rwf_investments', 'rwf_repayments', 'rwf_notifications',
     'rwf_review_queue', 'rwf_users', 'rwf_audit', 'rwf_compliance', 'rwf_wallet',
     'rwf_escrow', 'rwf_tickets', 'rwf_rules', 'rwf_roles', 'rwf_groups',
     'rwf_loanTypes', 'rwf_docTypes', 'rwf_langSettings', 'rwf_lawsuite',
     'rawafid_onboarding'].forEach((k) => localStorage.removeItem(k));
    window.location.reload();
  }, []);

  return {
    campaigns, investments, repayments, notifications, reviewQueue, users,
    auditLogs, complianceFlags, wallet, escrow, tickets, decisionRules,
    adminRoles, adminGroups, loanTypes, docTypes, languageSettings, lawSuite,
    investInCampaign, createCampaign, decideCampaign,
    markAllNotificationsRead, pushNotification, fundWallet, withdrawFromWallet,
    submitTicket, updateDecisionRule, addDecisionRule, resetDemo,
    setLoanTypes, setDocTypes, setLanguageSettings,
  };
};
