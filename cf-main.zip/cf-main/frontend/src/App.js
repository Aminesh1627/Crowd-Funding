import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { I18nProvider } from '@/context/I18nContext';
import { AuthProvider } from '@/context/AuthContext';
import { DemoStoreProvider } from '@/context/DemoStoreContext';
import { Toaster } from '@/components/ui/sonner';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AppShell } from '@/layouts/AppShell';

import Landing from '@/pages/Landing';
import Login from '@/pages/Login';
import Onboarding from '@/pages/Onboarding';
import Dashboard from '@/pages/Dashboard';
import { Marketplace } from '@/pages/investor/Marketplace';
import { CampaignDetail } from '@/pages/investor/CampaignDetail';
import { Portfolio } from '@/pages/investor/Portfolio';
import { CreateCampaign } from '@/pages/borrower/CreateCampaign';
import { MyCampaigns } from '@/pages/borrower/MyCampaigns';
import { RepaymentsPage } from '@/pages/borrower/Repayments';
import { SubscriptionDecisions } from '@/pages/borrower/SubscriptionDecisions';
import { ReviewQueue } from '@/pages/admin/ReviewQueue';
import { CreditOfficer, RiskOfficer, OnboardingOfficer, ComplianceOfficer } from '@/pages/admin/Officers';
import { Workflow } from '@/pages/admin/Workflow';
import { DecisionEngine } from '@/pages/admin/DecisionEngine';
import { ManageUsers, ManageRoles, ManageGroups } from '@/pages/admin/Manage';
import { MasterLoanTypes, MasterDocTypes, MasterLanguages } from '@/pages/admin/MasterData';
import { Compliance } from '@/pages/regulator/Compliance';
import { AuditLogs } from '@/pages/regulator/AuditLogs';
import { LawSuite } from '@/pages/regulator/LawSuite';
import { Profile } from '@/pages/Profile';
import { WalletPage } from '@/pages/shared/WalletPage';
import { SupportPage } from '@/pages/shared/SupportPage';

import '@/App.css';

function App() {
  return (
    <I18nProvider>
      <AuthProvider>
        <DemoStoreProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/login" element={<Login />} />
              <Route path="/onboarding" element={<Onboarding />} />

              <Route element={<ProtectedRoute />}>
                <Route element={<AppShell />}>
                  <Route path="/app" element={<Navigate to="/app/dashboard" replace />} />
                  <Route path="/app/dashboard" element={<Dashboard />} />
                  <Route path="/app/marketplace" element={<Marketplace />} />
                  <Route path="/app/marketplace/:id" element={<CampaignDetail />} />
                  <Route path="/app/portfolio" element={<Portfolio />} />
                  <Route path="/app/wallet" element={<WalletPage />} />
                  <Route path="/app/support" element={<SupportPage />} />

                  <Route path="/app/create" element={<CreateCampaign />} />
                  <Route path="/app/my-campaigns" element={<MyCampaigns />} />
                  <Route path="/app/repayments" element={<RepaymentsPage />} />
                  <Route path="/app/subscription" element={<SubscriptionDecisions />} />

                  <Route path="/app/review" element={<ReviewQueue />} />
                  <Route path="/app/credit-officer" element={<CreditOfficer />} />
                  <Route path="/app/risk-officer" element={<RiskOfficer />} />
                  <Route path="/app/onboarding-officer" element={<OnboardingOfficer />} />
                  <Route path="/app/compliance-officer" element={<ComplianceOfficer />} />
                  <Route path="/app/workflow" element={<Workflow />} />
                  <Route path="/app/decision-engine" element={<DecisionEngine />} />
                  <Route path="/app/manage-users" element={<ManageUsers />} />
                  <Route path="/app/manage-roles" element={<ManageRoles />} />
                  <Route path="/app/manage-groups" element={<ManageGroups />} />
                  <Route path="/app/master/loan" element={<MasterLoanTypes />} />
                  <Route path="/app/master/doc" element={<MasterDocTypes />} />
                  <Route path="/app/master/lang" element={<MasterLanguages />} />

                  <Route path="/app/compliance" element={<Compliance />} />
                  <Route path="/app/audit" element={<AuditLogs />} />
                  <Route path="/app/law-suite" element={<LawSuite />} />

                  <Route path="/app/profile" element={<Profile />} />
                </Route>
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
          <Toaster position="top-right" richColors closeButton />
        </DemoStoreProvider>
      </AuthProvider>
    </I18nProvider>
  );
}

export default App;
