import React, { createContext, useContext } from 'react';
import { useDemoStore } from '@/hooks/useDemoStore';

const DemoStoreContext = createContext(null);

export const DemoStoreProvider = ({ children }) => {
  const store = useDemoStore();
  return <DemoStoreContext.Provider value={store}>{children}</DemoStoreContext.Provider>;
};

export const useStore = () => {
  const ctx = useContext(DemoStoreContext);
  if (!ctx) throw new Error('useStore must be used inside DemoStoreProvider');
  return ctx;
};
