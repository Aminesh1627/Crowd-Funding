import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';

const AuthContext = createContext(null);

// 4 demo personas for institutional showcase
export const MOCK_USERS = {
  investor: {
    name: 'Omar Al-Rashdi', initials: 'OR', email: 'omar.rashdi@portfolio.om',
    civilId: '14523****', category: 'Sophisticated', joinedAt: '2024-08-12',
    title: 'Private Investor', avatarHue: 215,
  },
  borrower: {
    name: 'Layla Al-Habsi', initials: 'LH', email: 'layla@nabattextiles.om',
    company: 'Nabat Textiles SAOC', crNumber: 'CR-1184321', civilId: '21089****',
    title: 'Managing Director', avatarHue: 40,
  },
  admin: {
    name: 'Yusuf Al-Balushi', initials: 'YB', email: 'y.balushi@rawafid.om',
    team: 'Platform Operations', clearance: 'Tier 3', title: 'Platform Administrator',
    avatarHue: 160,
  },
  regulator: {
    name: 'Aisha Al-Saidi', initials: 'AS', email: 'a.saidi@cma.gov.om',
    entity: 'Capital Market Authority of Oman', title: 'Senior Regulator',
    clearance: 'Read-only audit', avatarHue: 210,
  },
};

export const ROLE_KEYS = ['investor', 'borrower', 'admin', 'regulator'];

// Investor onboarding statuses per role
const DEFAULT_ONBOARDING = {
  investor: {
    suitability: 'pending', kyc: 'pending', amlScreening: 'pending',
    wallet: 'pending', agreements: 'pending',
    completedAt: null, category: null,
  },
  borrower: {
    companyKyc: 'verified', crVerification: 'verified', amlScreening: 'verified',
    bankDetails: 'verified', boardResolution: 'verified',
    completedAt: '2024-09-04', category: 'SAOC Verified',
  },
};

export const AuthProvider = ({ children }) => {
  const [role, setRole] = useState(() => localStorage.getItem('rawafid_role') || null);
  const [authed, setAuthed] = useState(() => localStorage.getItem('rawafid_authed') === '1');
  const [onboarding, setOnboarding] = useState(() => {
    try {
      const raw = localStorage.getItem('rawafid_onboarding');
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return DEFAULT_ONBOARDING;
  });

  useEffect(() => {
    if (role) localStorage.setItem('rawafid_role', role);
    else localStorage.removeItem('rawafid_role');
  }, [role]);

  useEffect(() => {
    localStorage.setItem('rawafid_authed', authed ? '1' : '0');
  }, [authed]);

  useEffect(() => {
    localStorage.setItem('rawafid_onboarding', JSON.stringify(onboarding));
  }, [onboarding]);

  const login = useCallback((selectedRole) => {
    setRole(selectedRole);
    setAuthed(true);
  }, []);

  const logout = useCallback(() => {
    setAuthed(false);
    setRole(null);
  }, []);

  const switchRole = useCallback((r) => {
    setRole(r);
    setAuthed(true);
  }, []);

  const updateOnboarding = useCallback((roleKey, patch) => {
    setOnboarding((prev) => ({
      ...prev,
      [roleKey]: { ...(prev[roleKey] || {}), ...patch },
    }));
  }, []);

  const completeInvestorOnboarding = useCallback((data) => {
    setOnboarding((prev) => ({
      ...prev,
      investor: {
        ...prev.investor,
        ...data,
        suitability: 'verified', kyc: 'verified',
        amlScreening: 'verified', wallet: 'verified',
        agreements: 'verified',
        completedAt: new Date().toISOString().slice(0, 10),
      },
    }));
  }, []);

  const user = role ? MOCK_USERS[role] : null;

  const value = useMemo(() => ({
    role, authed, user, login, logout, switchRole,
    onboarding, updateOnboarding, completeInvestorOnboarding,
    MOCK_USERS, ROLE_KEYS,
  }), [role, authed, user, login, logout, switchRole, onboarding, updateOnboarding, completeInvestorOnboarding]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};
