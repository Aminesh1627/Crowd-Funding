import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { translations, getNested } from '@/data/translations';
import { overlay } from '@/data/translations_v2';

// Deep-merge overlay v2 into base translations (additive).
const deepMerge = (base, ext) => {
  const out = { ...(base || {}) };
  for (const k of Object.keys(ext || {})) {
    if (ext[k] && typeof ext[k] === 'object' && !Array.isArray(ext[k])) {
      out[k] = deepMerge(base?.[k], ext[k]);
    } else {
      out[k] = ext[k];
    }
  }
  return out;
};
const MERGED = {
  en: deepMerge(translations.en, overlay.en),
  ar: deepMerge(translations.ar, overlay.ar),
};

const I18nContext = createContext(null);

export const I18nProvider = ({ children }) => {
  const [lang, setLang] = useState(() => localStorage.getItem('rawafid_lang') || 'en');

  useEffect(() => {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', dir);
    localStorage.setItem('rawafid_lang', lang);
  }, [lang]);

  const t = useCallback((key, fallback) => {
    const val = getNested(MERGED[lang], key);
    if (val !== undefined) return val;
    const en = getNested(MERGED.en, key);
    return en !== undefined ? en : (fallback ?? key);
  }, [lang]);

  const toggle = useCallback(() => setLang((l) => (l === 'en' ? 'ar' : 'en')), []);

  const fmtNum = useCallback((n, opts = {}) => {
    try {
      return new Intl.NumberFormat(lang === 'ar' ? 'ar-OM' : 'en-OM', opts).format(n);
    } catch (e) { return String(n); }
  }, [lang]);

  const fmtCurrency = useCallback((n) => `${fmtNum(n, { maximumFractionDigits: 0 })} ${t('common.currency')}`, [fmtNum, t]);

  const value = useMemo(() => ({ lang, setLang, toggle, t, fmtNum, fmtCurrency, dir: lang === 'ar' ? 'rtl' : 'ltr' }), [lang, t, fmtNum, fmtCurrency, toggle]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export const useI18n = () => {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
};
