import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '@/components/Sidebar';
import { AppHeader } from '@/components/AppHeader';

export const AppShell = () => {
  return (
    <div className="min-h-screen flex bg-gradient-subtle">
      <Sidebar />
      <div className="flex-1 min-w-0 flex flex-col">
        <AppHeader />
        <main className="flex-1 p-5 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
