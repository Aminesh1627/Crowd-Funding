// All seed/dummy data for the prototype
export const SECTORS = ['manufacturing', 'logistics', 'hospitality', 'tech', 'retail', 'healthcare', 'agritech', 'services'];
export const RISK_GRADES = ['AAA', 'AA', 'A', 'BBB', 'BB', 'B'];

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

export const seedCampaigns = () => ([
  {
    id: 'C-1042', borrower: 'Nabat Textiles SAOC', borrowerInitials: 'NT', sector: 'manufacturing',
    title: 'Expansion of weaving line in Sohar', purpose: 'Equipment procurement & working capital',
    target: 120000, raised: 86400, investors: 142, rate: 11.5, tenure: 24, riskGrade: 'A',
    daysLeft: 9, stage: 'funding', region: 'Sohar', established: 2014,
    summary: 'A second-generation textile manufacturer expanding capacity to fulfil a 3-year apparel contract with a regional retail group.',
    metrics: { dscr: 1.8, dti: 0.32, ltv: 0.65, creditScore: 742 },
  },
  {
    id: 'C-1041', borrower: 'Khareef Logistics LLC', borrowerInitials: 'KL', sector: 'logistics',
    title: 'New cold-chain fleet — 12 refrigerated trucks',
    purpose: 'Fleet acquisition for pharmaceutical distribution',
    target: 240000, raised: 240000, investors: 318, rate: 9.8, tenure: 36, riskGrade: 'AA',
    daysLeft: 0, stage: 'funded', region: 'Muscat', established: 2009,
    summary: 'Established cold-chain operator securing a multi-year tender with the Ministry of Health.',
    metrics: { dscr: 2.4, dti: 0.21, ltv: 0.55, creditScore: 798 },
  },
  {
    id: 'C-1040', borrower: 'Salalah Boutique Resorts', borrowerInitials: 'SR', sector: 'hospitality',
    title: 'Eco-lodge expansion for Khareef season',
    purpose: 'Renovation of 18 new suites ahead of monsoon tourism',
    target: 180000, raised: 54000, investors: 71, rate: 12.5, tenure: 30, riskGrade: 'BBB',
    daysLeft: 21, stage: 'funding', region: 'Salalah', established: 2017,
    summary: 'Premium eco-tourism operator with 86% average occupancy during the Khareef season.',
    metrics: { dscr: 1.5, dti: 0.41, ltv: 0.72, creditScore: 688 },
  },
  {
    id: 'C-1039', borrower: 'BaitCode Technologies', borrowerInitials: 'BC', sector: 'tech',
    title: 'Series-B bridge for regional SaaS expansion',
    purpose: 'Sales hiring across GCC and product localization',
    target: 95000, raised: 28500, investors: 53, rate: 13.2, tenure: 18, riskGrade: 'BB',
    daysLeft: 15, stage: 'funding', region: 'Muscat', established: 2020,
    summary: 'Oman-based SaaS platform serving SMEs across the GCC. ARR up 78% YoY.',
    metrics: { dscr: 1.3, dti: 0.48, ltv: 0.80, creditScore: 651 },
  },
  {
    id: 'C-1038', borrower: 'Nizwa Date Co-op', borrowerInitials: 'ND', sector: 'agritech',
    title: 'Smart irrigation across 240 hectares',
    purpose: 'Sensor-based irrigation & packaging line upgrade',
    target: 160000, raised: 160000, investors: 264, rate: 10.4, tenure: 36, riskGrade: 'A',
    daysLeft: 0, stage: 'repayment', region: 'Nizwa', established: 1996,
    summary: 'Cooperative of 78 date farmers introducing precision agriculture tech.',
    metrics: { dscr: 2.0, dti: 0.28, ltv: 0.60, creditScore: 758 },
  },
  {
    id: 'C-1037', borrower: 'Muscat Medical Imaging', borrowerInitials: 'MM', sector: 'healthcare',
    title: 'MRI suite for new Al-Khoudh branch',
    purpose: 'Acquisition of advanced imaging equipment',
    target: 320000, raised: 220800, investors: 410, rate: 8.9, tenure: 48, riskGrade: 'AAA',
    daysLeft: 5, stage: 'funding', region: 'Muscat', established: 2008,
    summary: 'Leading private imaging provider serving 12,000 monthly patients.',
    metrics: { dscr: 2.9, dti: 0.18, ltv: 0.50, creditScore: 821 },
  },
  {
    id: 'C-1036', borrower: 'Dunes & Sails Tours', borrowerInitials: 'DS', sector: 'services',
    title: 'Adventure tourism fleet renewal',
    purpose: '6 new 4x4 vehicles and 3 dhow boats',
    target: 75000, raised: 14250, investors: 22, rate: 13.8, tenure: 24, riskGrade: 'B',
    daysLeft: 25, stage: 'funding', region: 'Wahiba Sands', established: 2015,
    summary: 'Boutique adventure operator pivoting toward higher-margin private experiences.',
    metrics: { dscr: 1.2, dti: 0.52, ltv: 0.85, creditScore: 612 },
  },
  {
    id: 'C-1035', borrower: 'Maha Modern Retail', borrowerInitials: 'MR', sector: 'retail',
    title: 'Three new flagship store fit-outs',
    purpose: 'Premium retail expansion in The Avenues Mall',
    target: 140000, raised: 49000, investors: 88, rate: 11.0, tenure: 24, riskGrade: 'BBB',
    daysLeft: 12, stage: 'funding', region: 'Muscat', established: 2012,
    summary: 'Omani fashion retailer with steady same-store growth of 11% over three years.',
    metrics: { dscr: 1.6, dti: 0.35, ltv: 0.68, creditScore: 704 },
  },
]);

export const seedInvestments = () => ([
  { id: 'I-9001', campaignId: 'C-1042', name: 'Nabat Textiles', amount: 2500, rate: 11.5, tenure: 24, status: 'active', invested: '2025-09-12', sector: 'manufacturing' },
  { id: 'I-9002', campaignId: 'C-1041', name: 'Khareef Logistics', amount: 5000, rate: 9.8, tenure: 36, status: 'active', invested: '2025-08-04', sector: 'logistics' },
  { id: 'I-9003', campaignId: 'C-1038', name: 'Nizwa Date Co-op', amount: 3000, rate: 10.4, tenure: 36, status: 'active', invested: '2025-06-22', sector: 'agritech' },
  { id: 'I-9004', campaignId: 'C-1037', name: 'Muscat Medical Imaging', amount: 4000, rate: 8.9, tenure: 48, status: 'active', invested: '2025-10-01', sector: 'healthcare' },
  { id: 'I-9005', campaignId: 'C-1035', name: 'Maha Modern Retail', amount: 1500, rate: 11.0, tenure: 24, status: 'active', invested: '2025-11-02', sector: 'retail' },
  { id: 'I-9006', campaignId: 'C-1040', name: 'Salalah Boutique Resorts', amount: 2000, rate: 12.5, tenure: 30, status: 'pending', invested: '2025-11-15', sector: 'hospitality' },
]);

export const seedRepayments = () => ([
  { id: 'R-01', campaignId: 'C-1042', installment: 1, due: '2025-12-15', principal: 4500, interest: 1150, total: 5650, status: 'upcoming' },
  { id: 'R-02', campaignId: 'C-1042', installment: 2, due: '2026-01-15', principal: 4540, interest: 1110, total: 5650, status: 'upcoming' },
  { id: 'R-03', campaignId: 'C-1041', installment: 6, due: '2025-12-04', principal: 6200, interest: 1480, total: 7680, status: 'upcoming' },
  { id: 'R-04', campaignId: 'C-1041', installment: 5, due: '2025-11-04', principal: 6150, interest: 1530, total: 7680, status: 'paid' },
  { id: 'R-05', campaignId: 'C-1041', installment: 4, due: '2025-10-04', principal: 6100, interest: 1580, total: 7680, status: 'paid' },
]);

export const seedNotifications = () => ([
  { id: 1, key: 'notifications.n1', type: 'info', time: '2m ago', read: false },
  { id: 2, key: 'notifications.n2', type: 'success', time: '1h ago', read: false },
  { id: 3, key: 'notifications.n3', type: 'success', time: '4h ago', read: false },
  { id: 4, key: 'notifications.n4', type: 'info', time: 'Yesterday', read: true },
  { id: 5, key: 'notifications.n5', type: 'warning', time: '2 days ago', read: true },
  { id: 6, key: 'notifications.n6', type: 'success', time: '3 days ago', read: true },
  { id: 7, key: 'notifications.n7', type: 'info', time: '5 days ago', read: true },
]);

export const seedReviewQueue = () => ([
  { id: 'C-1042', borrower: 'Nabat Textiles SAOC', amount: 120000, sector: 'manufacturing', stage: 'credit', sla: '4h', priority: 'high', score: 742 },
  { id: 'C-1043', borrower: 'Falaj Plumbing & Co', amount: 65000, sector: 'services', stage: 'credit', sla: '11h', priority: 'medium', score: 681 },
  { id: 'C-1044', borrower: 'Misfah Heritage Café', amount: 28000, sector: 'hospitality', stage: 'credit', sla: '23h', priority: 'low', score: 656 },
  { id: 'C-1045', borrower: 'Wadi Logistics & Trans.', amount: 95000, sector: 'logistics', stage: 'risk', sla: '8h', priority: 'high', score: 712 },
  { id: 'C-1046', borrower: 'Oasis Healthcare LLC', amount: 210000, sector: 'healthcare', stage: 'risk', sla: '16h', priority: 'medium', score: 768 },
  { id: 'C-1047', borrower: 'Mawasim Agri Tech', amount: 50000, sector: 'agritech', stage: 'compliance', sla: '6h', priority: 'high', score: 695 },
]);

export const seedUsers = () => ([
  { id: 'U-2001', name: 'Omar Al-Rashdi', type: 'investor', kyc: 'verified', status: 'active', joined: '2024-08-12', invested: 18000 },
  { id: 'U-2002', name: 'Reem Al-Ismaili', type: 'investor', kyc: 'verified', status: 'active', joined: '2023-11-04', invested: 42500 },
  { id: 'U-2003', name: 'Layla Al-Habsi', type: 'borrower', kyc: 'verified', status: 'active', joined: '2024-09-04', raised: 86400 },
  { id: 'U-2004', name: 'Hassan Al-Lawati', type: 'borrower', kyc: 'verified', status: 'active', joined: '2023-05-12', raised: 240000 },
  { id: 'U-2005', name: 'Maryam Al-Habsi', type: 'investor', kyc: 'pending', status: 'pending', joined: '2025-11-19', invested: 0 },
  { id: 'U-2006', name: 'Ali Al-Hinai', type: 'borrower', kyc: 'verified', status: 'active', joined: '2022-07-08', raised: 160000 },
  { id: 'U-2007', name: 'Noor Al-Mahrouqi', type: 'investor', kyc: 'verified', status: 'active', joined: '2025-02-14', invested: 6200 },
  { id: 'U-2008', name: 'Khalid Al-Maamari', type: 'investor', kyc: 'verified', status: 'active', joined: '2024-04-22', invested: 24800 },
]);

export const seedAuditLogs = () => ([
  { id: 'L-9821', at: '2025-12-04 14:21:08', actor: 'Yusuf Al-Balushi', role: 'admin', action: 'Approved campaign C-1041 for funding', target: 'C-1041', severity: 'info' },
  { id: 'L-9820', at: '2025-12-04 11:08:44', actor: 'System', role: 'platform', action: 'AML screening cleared for borrower BC-1039', target: 'BC-1039', severity: 'success' },
  { id: 'L-9819', at: '2025-12-03 17:35:12', actor: 'Layla Al-Habsi', role: 'borrower', action: 'Submitted campaign C-1042 for review', target: 'C-1042', severity: 'info' },
  { id: 'L-9818', at: '2025-12-03 09:14:50', actor: 'Aisha Al-Saidi', role: 'regulator', action: 'Exported Q3 disclosure pack', target: 'Filing-Q3-2025', severity: 'info' },
  { id: 'L-9817', at: '2025-12-02 22:02:18', actor: 'System', role: 'platform', action: 'Sanctions screening flagged adverse media on U-2099', target: 'U-2099', severity: 'warning' },
  { id: 'L-9816', at: '2025-12-02 16:45:31', actor: 'Yusuf Al-Balushi', role: 'admin', action: 'Returned C-1044 for clarification', target: 'C-1044', severity: 'info' },
  { id: 'L-9815', at: '2025-12-01 13:22:09', actor: 'Khalid Al-Maamari', role: 'compliance', action: 'Closed AML investigation INV-201', target: 'INV-201', severity: 'success' },
  { id: 'L-9814', at: '2025-11-30 19:11:02', actor: 'System', role: 'platform', action: 'Distributed OMR 14,820 in investor returns', target: 'Settlement-1124', severity: 'success' },
]);

export const seedComplianceFlags = () => ([
  { id: 'F-1', type: 'AML', subject: 'U-2099', detail: 'Adverse media match — pending review', severity: 'high', opened: '2025-12-02' },
  { id: 'F-2', type: 'KYC', subject: 'U-2005', detail: 'Civil ID document quality below threshold', severity: 'medium', opened: '2025-11-19' },
  { id: 'F-3', type: 'Disclosure', subject: 'C-1037', detail: 'Quarterly disclosure overdue by 3 days', severity: 'medium', opened: '2025-12-01' },
  { id: 'F-4', type: 'Complaint', subject: 'C-1036', detail: 'Investor complaint regarding marketing claim', severity: 'low', opened: '2025-11-28' },
]);

export const monthlyReturnSeries = [
  { m: 'Jun', profit: 180 }, { m: 'Jul', profit: 240 }, { m: 'Aug', profit: 270 },
  { m: 'Sep', profit: 310 }, { m: 'Oct', profit: 365 }, { m: 'Nov', profit: 412 },
];
export const cashFlowForecast = [
  { m: 'Dec', inflow: 980, outflow: 250 }, { m: 'Jan', inflow: 1120, outflow: 280 },
  { m: 'Feb', inflow: 1240, outflow: 300 }, { m: 'Mar', inflow: 1380, outflow: 310 },
  { m: 'Apr', inflow: 1450, outflow: 330 }, { m: 'May', inflow: 1610, outflow: 340 },
];
export const riskDistribution = [
  { name: 'AAA', value: 1200 }, { name: 'AA', value: 3200 },
  { name: 'A', value: 5500 }, { name: 'BBB', value: 2800 }, { name: 'BB', value: 1500 }, { name: 'B', value: 400 },
];
export const industryAlloc = [
  { name: 'Manufacturing', value: 28 }, { name: 'Logistics', value: 22 }, { name: 'Healthcare', value: 18 },
  { name: 'Agritech', value: 12 }, { name: 'Hospitality', value: 10 }, { name: 'Retail', value: 6 }, { name: 'Tech', value: 4 },
];

// Admin charts
export const monthlyFunding = [
  { m: 'Jun', funded: 720000, target: 800000 },
  { m: 'Jul', funded: 880000, target: 900000 },
  { m: 'Aug', funded: 960000, target: 1000000 },
  { m: 'Sep', funded: 1140000, target: 1100000 },
  { m: 'Oct', funded: 1280000, target: 1200000 },
  { m: 'Nov', funded: 1485000, target: 1350000 },
];
export const onboardingFunnel = [
  { stage: 'Signed up', value: 2400 },
  { stage: 'Suitability', value: 1840 },
  { stage: 'KYC', value: 1520 },
  { stage: 'AML', value: 1410 },
  { stage: 'Wallet', value: 1310 },
  { stage: 'Verified', value: 1268 },
];
export const sectorExposure = [
  { sector: 'Mfg.', exposure: 28 }, { sector: 'Log.', exposure: 22 },
  { sector: 'Health', exposure: 18 }, { sector: 'Agri', exposure: 12 },
  { sector: 'Hosp.', exposure: 10 }, { sector: 'Retail', exposure: 6 },
  { sector: 'Tech', exposure: 4 },
];

// Regulator charts
export const complianceTrend = [
  { m: 'Jun', flags: 4, resolved: 4 }, { m: 'Jul', flags: 6, resolved: 5 },
  { m: 'Aug', flags: 3, resolved: 4 }, { m: 'Sep', flags: 8, resolved: 7 },
  { m: 'Oct', flags: 5, resolved: 6 }, { m: 'Nov', flags: 4, resolved: 4 },
];
export const sectorConcentration = [
  { sector: 'Manufacturing', share: 28 }, { sector: 'Logistics', share: 22 },
  { sector: 'Healthcare', share: 18 }, { sector: 'Agritech', share: 12 },
  { sector: 'Hospitality', share: 10 }, { sector: 'Retail', share: 6 },
  { sector: 'Tech', share: 4 },
];

export const testimonials = [
  { quote: 'Rawafid funded our cold-chain fleet in three weeks. The investor visibility we now have is genuinely institutional-grade.', name: 'Hassan Al-Lawati', role: 'CEO, Khareef Logistics' },
  { quote: 'I run a diversified portfolio of 22 campaigns. The wallet, escrow trail and IRR view are exactly what serious investors expect.', name: 'Reem Al-Ismaili', role: 'Private investor, Muscat' },
  { quote: 'For our family business, this was the first time financing felt fully transparent — every reviewer, every step, every comment.', name: 'Ali Al-Hinai', role: 'MD, Nizwa Date Co-op' },
];

export const stats = {
  funded: 18420000, campaigns: 47, investors: 6320, avgReturn: 10.6,
};

export const sparkline = Array.from({ length: 24 }).map((_, i) => ({ x: i, y: 100 + Math.sin(i / 2) * 18 + i * 4 + rand(-6, 6) }));
