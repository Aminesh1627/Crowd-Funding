// Additional seed data for v2 enhancements.

export const seedEscrowTransactions = () => ([
  { id: 'TX-9012', date: '2025-12-04', type: 'deposit', label: 'Wallet top-up (Bank transfer)', amount: 5000, ref: 'BTR-882131' },
  { id: 'TX-9011', date: '2025-12-01', type: 'return', label: 'Profit distribution — C-1041', amount: 41, ref: 'DST-771203' },
  { id: 'TX-9010', date: '2025-11-30', type: 'principal', label: 'Principal credit — C-1041', amount: 138, ref: 'DST-771202' },
  { id: 'TX-9009', date: '2025-11-15', type: 'invest', label: 'Investment in C-1037', amount: -4000, ref: 'INV-690-2' },
  { id: 'TX-9008', date: '2025-11-10', type: 'return', label: 'Profit distribution — C-1038', amount: 26, ref: 'DST-770988' },
  { id: 'TX-9007', date: '2025-11-02', type: 'invest', label: 'Investment in C-1035', amount: -1500, ref: 'INV-690-1' },
  { id: 'TX-9006', date: '2025-10-21', type: 'deposit', label: 'Wallet top-up (Card)', amount: 8000, ref: 'BTR-882098' },
  { id: 'TX-9005', date: '2025-10-05', type: 'withdraw', label: 'Withdrawal to bank', amount: -2200, ref: 'WTH-441199' },
]);

export const seedSupportTickets = () => ([
  { id: 'TKT-2041', subject: 'Profit distribution not received for C-1041', category: 'cat_investment', status: 'open', priority: 'high', updated: '2025-12-04 11:08', messages: 3 },
  { id: 'TKT-2032', subject: 'KYC re-verification request', category: 'cat_kyc', status: 'reviewing', priority: 'medium', updated: '2025-12-02 16:11', messages: 2 },
  { id: 'TKT-2019', subject: 'Wallet withdrawal delayed', category: 'cat_wallet', status: 'resolved', priority: 'low', updated: '2025-11-22 09:30', messages: 5 },
  { id: 'TKT-2009', subject: 'Update bank account', category: 'cat_account', status: 'closed', priority: 'low', updated: '2025-11-08 14:55', messages: 4 },
]);

// Listing data per officer queue
export const seedOfficerCases = (officer) => {
  const base = [
    { id: 'C-1042', borrower: 'Nabat Textiles SAOC', amount: 120000, sector: 'manufacturing', score: 742, priority: 'high', sla: '4h', status: 'pending' },
    { id: 'C-1043', borrower: 'Falaj Plumbing & Co', amount: 65000, sector: 'services', score: 681, priority: 'medium', sla: '11h', status: 'pending' },
    { id: 'C-1044', borrower: 'Misfah Heritage Café', amount: 28000, sector: 'hospitality', score: 656, priority: 'low', sla: '23h', status: 'pending' },
    { id: 'C-1045', borrower: 'Wadi Logistics & Trans.', amount: 95000, sector: 'logistics', score: 712, priority: 'high', sla: '8h', status: 'pending' },
    { id: 'C-1046', borrower: 'Oasis Healthcare LLC', amount: 210000, sector: 'healthcare', score: 768, priority: 'medium', sla: '16h', status: 'pending' },
    { id: 'C-1047', borrower: 'Mawasim Agri Tech', amount: 50000, sector: 'agritech', score: 695, priority: 'high', sla: '6h', status: 'pending' },
    { id: 'C-1048', borrower: 'Bayt Al Hadara Retail', amount: 38000, sector: 'retail', score: 663, priority: 'low', sla: '28h', status: 'pending' },
  ];
  // Mask to the officer's lane (assign different visible subsets per officer for variety)
  const lanes = {
    credit: ['C-1042', 'C-1043', 'C-1044', 'C-1048'],
    risk: ['C-1042', 'C-1045', 'C-1046'],
    onboarding: ['C-1043', 'C-1047', 'C-1048'],
    compliance: ['C-1042', 'C-1046', 'C-1047'],
  };
  const ids = lanes[officer] || base.map((b) => b.id);
  return base.filter((b) => ids.includes(b.id));
};

// Mocked Ma'laa credit-pull data per borrower-id
export const malaaPull = (id) => ({
  cbScore: 720 + (id.charCodeAt(id.length - 1) % 12) * 3,
  status: 'Active',
  activeFacilities: 3,
  totalExposureOMR: 84000,
  delinquentLast24m: 0,
  inquiriesLast6m: 2,
  asOfDate: '2025-12-03',
});

export const policyChecks = [
  { id: 'P1', name: 'Sector exposure within 30%', status: 'pass' },
  { id: 'P2', name: 'Borrower max single-party limit', status: 'pass' },
  { id: 'P3', name: 'DSCR ≥ 1.3', status: 'pass' },
  { id: 'P4', name: 'KYC freshness < 12 months', status: 'pass' },
  { id: 'P5', name: 'Concentration in same beneficiary', status: 'warn' },
  { id: 'P6', name: 'AML/PEP clean', status: 'pass' },
];

export const scorecardRows = [
  { factor: 'CB Score', weight: 25, score: 84, contribution: 21.0 },
  { factor: 'DSCR', weight: 20, score: 78, contribution: 15.6 },
  { factor: 'Sector outlook', weight: 15, score: 72, contribution: 10.8 },
  { factor: 'Management tenure', weight: 10, score: 88, contribution: 8.8 },
  { factor: 'Collateral coverage', weight: 15, score: 65, contribution: 9.75 },
  { factor: 'Liquidity profile', weight: 15, score: 76, contribution: 11.4 },
];

// Decision engine rules (interactive)
export const seedDecisionRules = () => ([
  { id: 'R-101', category: 'credit', name: 'Minimum CB score', condition: 'cb_score >= 650', threshold: 650, weight: 25, active: true },
  { id: 'R-102', category: 'credit', name: 'DSCR floor', condition: 'dscr >= 1.30', threshold: 1.3, weight: 20, active: true },
  { id: 'R-103', category: 'credit', name: 'DTI ceiling', condition: 'dti <= 0.50', threshold: 0.5, weight: 15, active: true },
  { id: 'R-201', category: 'risk', name: 'Single-borrower max exposure', condition: 'exposure_pct <= 8', threshold: 8, weight: 15, active: true },
  { id: 'R-202', category: 'risk', name: 'Sector concentration cap', condition: 'sector_pct <= 30', threshold: 30, weight: 15, active: true },
  { id: 'R-301', category: 'compliance', name: 'AML/PEP screening clean', condition: 'aml = clean', threshold: 'clean', weight: 10, active: true },
  { id: 'R-302', category: 'compliance', name: 'Sanctions match', condition: 'sanctions = 0', threshold: 0, weight: 10, active: true },
  { id: 'R-401', category: 'onboarding', name: 'KYC freshness', condition: 'kyc_age_months <= 12', threshold: 12, weight: 5, active: true },
]);

// Roles + groups + master data
export const seedRoles = () => ([
  { id: 'R-CRED', name: 'Credit Officer', members: 6, permissions: ['Review credit', 'Pull Ma\u02beala\u02bea', 'Apply credit decision'] },
  { id: 'R-RISK', name: 'Risk Officer', members: 4, permissions: ['Review risk', 'Configure thresholds', 'Escalate'] },
  { id: 'R-COMP', name: 'Compliance Officer', members: 5, permissions: ['Run AML', 'Review compliance', 'Submit committee'] },
  { id: 'R-ONB', name: 'Onboarding Officer', members: 8, permissions: ['Approve KYC', 'Reject KYC', 'Re-verify'] },
  { id: 'R-ADM', name: 'Platform Admin', members: 3, permissions: ['Manage users', 'Configure platform', 'Read audit'] },
  { id: 'R-REG', name: 'Regulator', members: 2, permissions: ['Read-only oversight', 'Export filings', 'Open compliance review'] },
]);

export const seedGroups = () => ([
  { id: 'G-CC', name: 'Credit Committee', type: 'committee', members: 7, region: 'Muscat HQ' },
  { id: 'G-RC', name: 'Risk Committee', type: 'committee', members: 5, region: 'Muscat HQ' },
  { id: 'G-AM', name: 'AML Working Group', type: 'committee', members: 4, region: 'Muscat HQ' },
  { id: 'G-OS', name: 'Onboarding — Sohar Desk', type: 'desk', members: 3, region: 'Sohar' },
  { id: 'G-OZ', name: 'Onboarding — Salalah Desk', type: 'desk', members: 3, region: 'Salalah' },
]);

export const seedLoanTypes = () => ([
  { code: 'WC-SME', name: 'SME Working Capital', minAmount: 10000, maxAmount: 250000, minTenure: 6, maxTenure: 36, minRate: 8.5, maxRate: 14.5, enabled: true },
  { code: 'EQP', name: 'Equipment Financing', minAmount: 25000, maxAmount: 500000, minTenure: 12, maxTenure: 60, minRate: 7.5, maxRate: 12.5, enabled: true },
  { code: 'TRD', name: 'Trade & Receivables', minAmount: 10000, maxAmount: 200000, minTenure: 3, maxTenure: 18, minRate: 9.5, maxRate: 15.5, enabled: true },
  { code: 'EXP', name: 'Expansion Capital', minAmount: 50000, maxAmount: 750000, minTenure: 18, maxTenure: 72, minRate: 8.0, maxRate: 13.5, enabled: true },
  { code: 'INV-T', name: 'Inventory Finance', minAmount: 15000, maxAmount: 150000, minTenure: 6, maxTenure: 24, minRate: 10.0, maxRate: 14.5, enabled: false },
]);

export const seedDocTypes = () => ([
  { code: 'CIVID', name: 'Civil ID', stage: 'Onboarding', party: 'Investor', mandatory: true },
  { code: 'PSSPT', name: 'Passport (non-Omani)', stage: 'Onboarding', party: 'Investor', mandatory: false },
  { code: 'POAR', name: 'Proof of address', stage: 'Onboarding', party: 'Investor', mandatory: true },
  { code: 'CRTC', name: 'CR Certificate', stage: 'Campaign', party: 'Borrower', mandatory: true },
  { code: 'AFS', name: 'Audited financial statements', stage: 'Campaign', party: 'Borrower', mandatory: true },
  { code: 'BSTM', name: 'Bank statements (6m)', stage: 'Campaign', party: 'Borrower', mandatory: true },
  { code: 'BLIC', name: 'Business license', stage: 'Campaign', party: 'Borrower', mandatory: true },
  { code: 'BRES', name: 'Board resolution', stage: 'Campaign', party: 'Borrower', mandatory: true },
]);

export const seedLanguageSettings = () => ([
  { code: 'en', name: 'English', coverage: 100, enabled: true, primary: false },
  { code: 'ar', name: 'العربية', coverage: 100, enabled: true, primary: true },
  { code: 'ur', name: 'اردو', coverage: 32, enabled: false, primary: false },
  { code: 'hi', name: 'हिन्दी', coverage: 18, enabled: false, primary: false },
]);

export const seedWorkflowStages = () => ([
  { key: 'submitted', label: 'Submitted', count: 12, avgDwell: '0.2d' },
  { key: 'credit', label: 'Credit', count: 4, avgDwell: '0.8d' },
  { key: 'risk', label: 'Risk', count: 3, avgDwell: '1.1d' },
  { key: 'compliance', label: 'Compliance', count: 3, avgDwell: '0.6d' },
  { key: 'committee', label: 'Committee', count: 2, avgDwell: '0.9d' },
  { key: 'funding', label: 'Funding open', count: 6, avgDwell: '12d' },
  { key: 'disbursed', label: 'Disbursed', count: 18, avgDwell: '1d' },
  { key: 'repayment', label: 'Repayment', count: 22, avgDwell: '—' },
  { key: 'closed', label: 'Closed', count: 31, avgDwell: '—' },
]);

export const seedLawSuiteCases = () => ([
  { id: 'LS-2024-001', plaintiff: 'Rawafid Platform LLC', defendant: 'Dunes & Sails Tours', type: 'type_default', stage: 'stage_hearing', court: 'Commercial Court — Muscat', filed: '2024-08-21', nextHearing: '2025-12-18', amount: 32500 },
  { id: 'LS-2024-014', plaintiff: 'Investor consortium', defendant: 'BaitCode Technologies', type: 'type_disclosure', stage: 'stage_filed', court: 'Civil Court — Muscat', filed: '2024-11-04', nextHearing: '2026-01-12', amount: 18900 },
  { id: 'LS-2023-082', plaintiff: 'Rawafid Platform LLC', defendant: 'Salalah Boutique Resorts', type: 'type_default', stage: 'stage_judgment', court: 'Commercial Court — Salalah', filed: '2023-12-09', nextHearing: '—', amount: 54000, outcome: 'won' },
  { id: 'LS-2023-061', plaintiff: 'CMA Oman', defendant: 'Rawafid Platform LLC', type: 'type_disclosure', stage: 'stage_closed', court: 'CMA Tribunal', filed: '2023-09-22', nextHearing: '—', amount: 0, outcome: 'settled' },
  { id: 'LS-2025-009', plaintiff: 'Maryam Al-Habsi', defendant: 'Rawafid Platform LLC', type: 'type_consumer', stage: 'stage_appeal', court: 'Consumer Tribunal', filed: '2025-04-15', nextHearing: '2026-02-08', amount: 4200 },
  { id: 'LS-2025-022', plaintiff: 'Rawafid Platform LLC', defendant: 'Wadi Logistics', type: 'type_default', stage: 'stage_hearing', court: 'Commercial Court — Muscat', filed: '2025-07-18', nextHearing: '2026-01-30', amount: 41200 },
]);

// Generate investor monthly distributions from current investments
export const distributionsFor = (investment, monthsPaid = 2) => {
  const monthlyProfit = +(investment.amount * (investment.rate / 100) / 12).toFixed(2);
  const monthlyPrincipal = +(investment.amount / investment.tenure).toFixed(2);
  const out = [];
  const start = new Date(investment.invested);
  for (let i = 1; i <= Math.min(investment.tenure, 6); i++) {
    const dt = new Date(start.getFullYear(), start.getMonth() + i, 5);
    out.push({
      id: `DST-${investment.id.slice(2)}-${i}`,
      campaignId: investment.campaignId, name: investment.name,
      month: i, date: dt.toISOString().slice(0, 10),
      profit: monthlyProfit, principal: monthlyPrincipal,
      total: +(monthlyProfit + monthlyPrincipal).toFixed(2),
      status: i <= monthsPaid ? 'paid' : 'pending',
    });
  }
  return out;
};
