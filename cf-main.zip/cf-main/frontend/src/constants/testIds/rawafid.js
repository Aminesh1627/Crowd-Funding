// Test IDs for the Rawafid crowdfunding prototype.
export const RAWAFID = {
  // Header / shell
  langToggle: 'header-lang-toggle',
  roleSwitcherTrigger: 'header-role-switcher-trigger',
  roleSwitcherInvestor: 'role-switcher-investor',
  roleSwitcherBorrower: 'role-switcher-borrower',
  roleSwitcherAdmin: 'role-switcher-admin',
  roleSwitcherRegulator: 'role-switcher-regulator',
  notificationBell: 'header-notification-bell',
  notificationMarkAll: 'notification-mark-all-read',
  userMenuTrigger: 'header-user-menu-trigger',
  userMenuSignOut: 'user-menu-sign-out',
  userMenuProfile: 'user-menu-profile',
  sidebar: 'app-sidebar',
  navItem: (key) => `sidebar-nav-${key}`,

  // Landing
  landingHero: 'landing-hero',
  landingCtaPrimary: 'landing-cta-primary',
  landingCtaSecondary: 'landing-cta-secondary',
  landingCtaSignin: 'landing-cta-signin',

  // Login
  loginEmail: 'login-email',
  loginPassword: 'login-password',
  loginSubmit: 'login-submit',
  loginRoleCard: (key) => `login-role-card-${key}`,

  // Onboarding
  onboardingStart: 'onboarding-start',
  onboardingNext: 'onboarding-next',
  onboardingBack: 'onboarding-back',
  onboardingFinish: 'onboarding-finish',

  // Marketplace
  marketplaceCard: (id) => `marketplace-card-${id}`,
  marketplaceFilterSector: 'marketplace-filter-sector',
  marketplaceFilterRisk: 'marketplace-filter-risk',
  marketplaceSort: 'marketplace-sort',

  // Campaign detail / invest
  investNowButton: 'invest-now-button',
  investAmountInput: 'invest-amount-input',
  investConfirm: 'invest-confirm',

  // Borrower create
  createCampaignButton: 'create-campaign-button',
  createCampaignSubmit: 'create-campaign-submit',

  // Admin review
  reviewApprove: (id) => `review-approve-${id}`,
  reviewReject: (id) => `review-reject-${id}`,

  // Profile
  resetDemo: 'profile-reset-demo',
};
