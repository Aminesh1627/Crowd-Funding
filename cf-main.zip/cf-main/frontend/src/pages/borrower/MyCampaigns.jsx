import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill, RiskBadge } from '@/components/Primitives';
import { Plus, MapPin } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';

const STAGE_TONE = {
  submitted: 'info', credit: 'info', risk: 'warning', compliance: 'warning',
  funding: 'gold', funded: 'success', repayment: 'success', closed: 'neutral', rejected: 'danger',
};

export const MyCampaigns = () => {
  const { t, fmtCurrency } = useI18n();
  const { campaigns } = useStore();
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('borrower.campaigns_title')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">My Campaigns</h1>
        </div>
        <Button
          data-testid={RAWAFID.createCampaignButton}
          onClick={() => navigate('/app/create')}
          className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full font-semibold shadow-gold"
        >
          <Plus className="me-1 w-4 h-4" /> {t('borrower.qa_new')}
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {campaigns.map((c) => {
          const pct = Math.round((c.raised / c.target) * 100);
          return (
            <GlassCard key={c.id} className="hover-lift">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <RiskBadge grade={c.riskGrade} />
                  <StatusPill tone={STAGE_TONE[c.stage] || 'neutral'}>{t(`borrower.stage_${c.stage}`)}</StatusPill>
                </div>
                <span className="text-[10px] text-muted-foreground">{c.id}</span>
              </div>
              <div className="font-serif-display text-lg text-primary line-clamp-2 mb-2 min-h-[3rem]">{c.title}</div>
              <div className="text-xs text-muted-foreground flex items-center gap-1.5 mb-4">
                <MapPin className="w-3 h-3" /> {c.region} · {t(`sectors.${c.sector}`)}
              </div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">{fmtCurrency(c.raised)} / {fmtCurrency(c.target)}</span>
                <span className="font-semibold text-primary num-display">{pct}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden mb-4">
                <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{c.investors} investors · {c.rate}% · {c.tenure}m</span>
                <Button size="sm" variant="ghost" onClick={() => navigate(`/app/marketplace/${c.id}`)}>{t('common.view')}</Button>
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
};

export default MyCampaigns;
