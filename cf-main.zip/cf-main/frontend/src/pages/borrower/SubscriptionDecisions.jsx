import React, { useMemo, useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill, KpiTile, RiskBadge } from '@/components/Primitives';
import { CheckSquare, Users, TrendingUp, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export const SubscriptionDecisions = () => {
  const { t, fmtCurrency } = useI18n();
  const { campaigns } = useStore();

  // Simulate subscription levels by injecting excess on some campaigns
  const items = useMemo(() => {
    const overrides = {
      'C-1041': { received: 268000, investors: 318 }, // Oversubscribed (+28k)
      'C-1037': { received: 320000, investors: 410 }, // Fully subscribed
      'C-1038': { received: 184000, investors: 264 }, // Oversubscribed (+24k)
      'C-1042': { received: 86400, investors: 142 },  // Undersubscribed (72%)
    };
    return campaigns
      .filter((c) => ['funding', 'funded'].includes(c.stage) && overrides[c.id])
      .map((c) => {
        const o = overrides[c.id];
        const excess = Math.max(0, o.received - c.target);
        const status = excess > 0 ? 'oversub' : o.received >= c.target ? 'sub_complete' : 'undersub';
        return { ...c, received: o.received, investors: o.investors, excess, status };
      });
  }, [campaigns]);

  const [decisions, setDecisions] = useState({});

  const totalOver = items.reduce((s, it) => s + it.excess, 0);
  const totalInvestors = items.reduce((s, it) => s + it.investors, 0);
  const oversubCount = items.filter((it) => it.status === 'oversub').length;

  const decide = (id, decision, item) => {
    setDecisions((prev) => ({ ...prev, [id]: decision }));
    if (decision === 'accept_all') {
      toast.success(t('subscription.cap_lifted').replace('{{amount}}', (item.target + item.excess).toLocaleString()));
    } else if (decision === 'reject_excess') {
      const investorsHit = Math.ceil(item.investors * (item.excess / item.received));
      toast.info(t('subscription.refund_initiated').replace('{{n}}', investorsHit));
    } else {
      toast.success(t('subscription.decision_recorded'));
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <CheckSquare className="w-3.5 h-3.5" /> {t('nav.subscription')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('subscription.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('subscription.subtitle')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiTile label={t('subscription.decision_required')} value={oversubCount} icon={AlertCircle} accent />
        <KpiTile label={t('subscription.excess')} value={fmtCurrency(totalOver)} icon={TrendingUp} />
        <KpiTile label={t('subscription.effect_investors')} value={totalInvestors} icon={Users} />
        <KpiTile label="Active campaigns" value={items.length} icon={CheckSquare} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {items.length === 0 && (
          <GlassCard><div className="text-center text-muted-foreground py-8">{t('subscription.no_pending')}</div></GlassCard>
        )}
        {items.map((it) => {
          const filledPct = Math.min(200, Math.round((it.received / it.target) * 100));
          const decisionMade = decisions[it.id];
          return (
            <GlassCard key={it.id} className="hover-lift">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="min-w-0">
                  <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{it.id}</div>
                  <div className="font-serif-display text-lg text-primary line-clamp-2">{it.title}</div>
                  <div className="mt-1 flex items-center gap-2">
                    <RiskBadge grade={it.riskGrade} />
                    <StatusPill tone={it.status === 'oversub' ? 'warning' : it.status === 'sub_complete' ? 'success' : 'info'}>
                      {t(`subscription.${it.status}`)}
                    </StatusPill>
                  </div>
                </div>
                <div className="text-end shrink-0">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('subscription.pct_filled')}</div>
                  <div className={`font-serif-display text-2xl num-display ${it.status === 'oversub' ? 'text-accent' : 'text-primary'}`}>{filledPct}%</div>
                </div>
              </div>

              <div className="h-2.5 rounded-full bg-muted overflow-hidden mb-1.5 relative">
                <div className="h-full bg-gradient-gold" style={{ width: `${Math.min(100, filledPct)}%` }} />
                {filledPct > 100 && (
                  <div className="absolute inset-y-0 bg-accent/40" style={{ left: '100%', width: `${Math.min(100, filledPct - 100)}%` }} />
                )}
              </div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-4">
                <span>{t('subscription.target')}: {fmtCurrency(it.target)}</span>
                <span>{t('subscription.received')}: {fmtCurrency(it.received)}</span>
              </div>

              {it.status === 'oversub' ? (
                <div className="rounded-lg p-3 bg-accent/10 border border-accent/30 mb-3">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{t('subscription.effect_title')}</div>
                  <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('subscription.excess')}</div>
                      <div className="font-serif-display text-base text-accent num-display">{fmtCurrency(it.excess)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('subscription.effect_investors')}</div>
                      <div className="font-serif-display text-base text-primary num-display">{it.investors}</div>
                    </div>
                  </div>
                </div>
              ) : null}

              {it.status === 'oversub' && !decisionMade && (
                <div className="grid grid-cols-1 gap-2">
                  <DecisionBtn data-testid={`sub-accept-all-${it.id}`} label={t('subscription.accept_all')} onClick={() => decide(it.id, 'accept_all', it)} primary />
                  <DecisionBtn data-testid={`sub-accept-target-${it.id}`} label={t('subscription.accept_target')} onClick={() => decide(it.id, 'accept_target', it)} />
                  <DecisionBtn data-testid={`sub-reject-${it.id}`} label={t('subscription.reject_excess')} onClick={() => decide(it.id, 'reject_excess', it)} />
                </div>
              )}
              {decisionMade && (
                <div className="text-sm flex items-center gap-2 text-success">
                  <CheckSquare className="w-4 h-4" />
                  Decision recorded: <strong>{t(`subscription.${decisionMade}`)}</strong>
                </div>
              )}
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
};

const DecisionBtn = ({ label, onClick, primary, ...props }) => (
  <Button onClick={onClick} variant={primary ? 'default' : 'outline'}
    className={`justify-start rounded-lg ${primary ? 'bg-primary hover:bg-primary/90' : ''}`} {...props}>
    {label}
  </Button>
);

export default SubscriptionDecisions;
