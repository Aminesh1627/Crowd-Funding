import React, { useMemo, useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill, KpiTile } from '@/components/Primitives';
import { ProfitAreaChart } from '@/components/Charts';
import {
  RefreshCcw, AlertCircle, CheckCircle2, Calendar, Banknote, Clock, ArrowRight,
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';

// Build a complete amortising schedule for a campaign
const buildSchedule = (c, paidUpto = 0) => {
  const months = c.tenure;
  const rate = c.rate / 100;
  const monthlyPrincipal = +(c.target / months).toFixed(2);
  const monthlyProfit = +((c.target * rate) / 12).toFixed(2);
  const total = +(monthlyPrincipal + monthlyProfit).toFixed(2);
  const start = new Date('2025-09-15');
  const out = [];
  for (let i = 1; i <= Math.min(months, 18); i++) {
    const dt = new Date(start.getFullYear(), start.getMonth() + i, 15);
    out.push({
      id: `${c.id}-INST-${i}`,
      campaignId: c.id, installment: i,
      due: dt.toISOString().slice(0, 10),
      principal: monthlyPrincipal, profit: monthlyProfit, total,
      status: i <= paidUpto ? 'paid' : (i === paidUpto + 1 ? 'upcoming' : 'pending'),
    });
  }
  return out;
};

const REVENUE = [
  { m: 'Jun', profit: 4200 }, { m: 'Jul', profit: 5200 }, { m: 'Aug', profit: 4900 },
  { m: 'Sep', profit: 6100 }, { m: 'Oct', profit: 5800 }, { m: 'Nov', profit: 6400 },
];

export const RepaymentsPage = () => {
  const { t, fmtCurrency } = useI18n();
  const { campaigns } = useStore();
  const [selected, setSelected] = useState(null);
  const [earlyOpen, setEarlyOpen] = useState(false);
  const [restructureOpen, setRestructureOpen] = useState(false);
  const [restructureForm, setRestructureForm] = useState({ extension: 6, reason: '' });

  // Filter active campaigns the borrower would repay (mock: all funded/repayment/funding-late stage)
  const myCampaigns = useMemo(
    () => campaigns.filter((c) => ['funded', 'repayment', 'funding'].includes(c.stage)).slice(0, 3),
    [campaigns]
  );

  const schedules = useMemo(() => myCampaigns.map((c) => buildSchedule(c, c.id === 'C-1041' ? 5 : c.id === 'C-1038' ? 9 : 2)), [myCampaigns]);

  const allInstallments = schedules.flat();
  const totalOutstanding = allInstallments.filter((x) => x.status !== 'paid').reduce((s, x) => s + x.total, 0);
  const paidToDate = allInstallments.filter((x) => x.status === 'paid').reduce((s, x) => s + x.total, 0);
  const nextDue = allInstallments.find((x) => x.status === 'upcoming');
  const overdue = 0;

  const payNow = (inst) => {
    toast.success(`${t('repayments.paid_success')} (${fmtCurrency(inst.total)})`);
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <RefreshCcw className="w-3.5 h-3.5" /> {t('nav.repayments')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('repayments.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('repayments.subtitle')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiTile label={t('repayments.total_outstanding')} value={fmtCurrency(Math.round(totalOutstanding))} icon={Banknote} accent />
        <KpiTile label={t('repayments.paid_to_date')} value={fmtCurrency(Math.round(paidToDate))} icon={CheckCircle2} />
        <KpiTile label={t('repayments.next_due')} value={nextDue ? fmtCurrency(Math.round(nextDue.total)) : '—'} sub={nextDue?.due || '—'} icon={Calendar} />
        <KpiTile label={t('repayments.overdue')} value={fmtCurrency(overdue)} icon={AlertCircle} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader
            kicker={t('repayments.schedule')}
            title="By campaign"
            action={
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" onClick={() => setRestructureOpen(true)} data-testid="repayments-restructure">
                  {t('repayments.restructure')}
                </Button>
                <Button size="sm" onClick={() => setEarlyOpen(true)} className="bg-primary hover:bg-primary/90 rounded-full" data-testid="repayments-early">
                  {t('repayments.settle_early')}
                </Button>
              </div>
            }
          />
          <div className="space-y-3">
            {myCampaigns.length === 0 && (
              <div className="text-center text-sm text-muted-foreground py-8">{t('repayments.no_items')}</div>
            )}
            {myCampaigns.map((c, idx) => {
              const sched = schedules[idx];
              const paid = sched.filter((x) => x.status === 'paid').length;
              const pct = Math.round((paid / sched.length) * 100);
              const isSelected = selected === c.id;
              return (
                <div key={c.id} className="rounded-xl border border-border overflow-hidden">
                  <button
                    onClick={() => setSelected(isSelected ? null : c.id)}
                    className="w-full flex items-center justify-between gap-3 p-4 hover:bg-muted/40 text-start"
                  >
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground">{c.id} · {t(`sectors.${c.sector}`)}</div>
                      <div className="font-serif-display text-base text-primary truncate">{c.title}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-end">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('repayments.paid_to_date')}</div>
                        <div className="font-semibold num-display">{paid}/{sched.length}</div>
                      </div>
                      <div className="w-28 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
                      </div>
                      <ArrowRight className={`w-4 h-4 text-muted-foreground transition-transform ${isSelected ? 'rotate-90' : ''} rtl-flip`} />
                    </div>
                  </button>
                  {isSelected && (
                    <div className="border-t border-border bg-muted/20 px-4 py-3 overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            <th className="text-start py-2">{t('borrower.installment')}</th>
                            <th className="text-end py-2">{t('borrower.due')}</th>
                            <th className="text-end py-2">{t('borrower.principal')}</th>
                            <th className="text-end py-2">{t('borrower.interest')}</th>
                            <th className="text-end py-2">{t('borrower.total_due')}</th>
                            <th className="text-end py-2">{t('common.status')}</th>
                            <th className="text-end py-2">{t('common.actions')}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {sched.map((r) => (
                            <tr key={r.id} className="border-t border-border/50">
                              <td className="py-2">#{r.installment}</td>
                              <td className="py-2 text-end text-muted-foreground">{r.due}</td>
                              <td className="py-2 text-end num-display">{fmtCurrency(r.principal)}</td>
                              <td className="py-2 text-end num-display">{fmtCurrency(r.profit)}</td>
                              <td className="py-2 text-end num-display font-semibold">{fmtCurrency(r.total)}</td>
                              <td className="py-2 text-end">
                                <StatusPill tone={r.status === 'paid' ? 'success' : r.status === 'upcoming' ? 'warning' : 'info'}>
                                  {t(`borrower.${r.status === 'pending' ? 'upcoming' : r.status}`)}
                                </StatusPill>
                              </td>
                              <td className="py-2 text-end">
                                {r.status !== 'paid' && (
                                  <Button size="sm" variant="ghost" data-testid={`repayment-pay-${r.id}`} onClick={() => payNow(r)}>
                                    {t('repayments.pay_now')}
                                  </Button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </GlassCard>

        <GlassCard>
          <SectionHeader kicker="Health" title="Revenue trend" />
          <ProfitAreaChart data={REVENUE} />
          <div className="mt-4 space-y-2">
            <Row label="DSCR (last 6m)" value="1.84" tone="success" />
            <Row label="DPD (avg)" value="2.1 days" tone="success" />
            <Row label="Next collection" value={nextDue?.due || '—'} />
            <Row label="Auto-debit" value="Enabled" tone="success" />
          </div>
        </GlassCard>
      </div>

      {/* Early settlement dialog */}
      <Dialog open={earlyOpen} onOpenChange={setEarlyOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">{t('repayments.settle_early')}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">{t('repayments.early_sub')}</p>
          <div className="rounded-lg p-4 bg-muted/40 space-y-2">
            <SumRow label={t('repayments.total_outstanding')} value={fmtCurrency(Math.round(totalOutstanding))} />
            <SumRow label="Early settlement fee (1%)" value={fmtCurrency(Math.round(totalOutstanding * 0.01))} />
            <SumRow label="Final payable" value={fmtCurrency(Math.round(totalOutstanding * 1.01))} accent />
          </div>
          <Button
            onClick={() => { setEarlyOpen(false); toast.success('Early settlement initiated.'); }}
            className="w-full bg-primary hover:bg-primary/90 rounded-full"
            data-testid="confirm-early"
          >
            {t('common.confirm')}
          </Button>
        </DialogContent>
      </Dialog>

      {/* Restructure dialog */}
      <Dialog open={restructureOpen} onOpenChange={setRestructureOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">{t('repayments.restructure')}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">{t('repayments.restructure_sub')}</p>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">Tenure extension (months)</label>
            <input
              type="number" value={restructureForm.extension}
              onChange={(e) => setRestructureForm((f) => ({ ...f, extension: Number(e.target.value) || 0 }))}
              className="w-full h-11 px-3 rounded-lg border border-input bg-background num-display"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">Reason</label>
            <textarea
              value={restructureForm.reason}
              onChange={(e) => setRestructureForm((f) => ({ ...f, reason: e.target.value }))}
              rows={3}
              className="w-full px-3 py-2 rounded-lg border border-input bg-background"
            />
          </div>
          <Button
            onClick={() => { setRestructureOpen(false); toast.success('Restructure request submitted for review.'); }}
            className="w-full bg-primary hover:bg-primary/90 rounded-full"
            data-testid="confirm-restructure"
          >
            {t('common.submit')}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const Row = ({ label, value, tone }) => (
  <div className="flex justify-between items-center text-sm">
    <span className="text-muted-foreground">{label}</span>
    <span className={`font-semibold num-display ${tone === 'success' ? 'text-success' : 'text-foreground'}`}>{value}</span>
  </div>
);
const SumRow = ({ label, value, accent }) => (
  <div className="flex justify-between items-center text-sm">
    <span className={accent ? 'font-semibold text-foreground' : 'text-muted-foreground'}>{label}</span>
    <span className={`num-display font-semibold ${accent ? 'text-accent text-base' : ''}`}>{value}</span>
  </div>
);

export default RepaymentsPage;
