import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { GlassCard, KpiTile, SectionHeader, StatusPill, RiskBadge } from '@/components/Primitives';
import { ProfitAreaChart, FundingComboChart } from '@/components/Charts';
import { monthlyReturnSeries, monthlyFunding } from '@/data/mockData';
import {
  Plus, FolderKanban, Banknote, Clock, AlertTriangle, FileEdit, CheckCircle2,
} from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';

const STAGE_TONE = {
  submitted: 'info', credit: 'info', risk: 'warning', compliance: 'warning',
  funding: 'gold', funded: 'success', repayment: 'success', closed: 'neutral', rejected: 'danger',
};

export const BorrowerDashboard = () => {
  const { t, fmtCurrency } = useI18n();
  const { user } = useAuth();
  const { campaigns } = useStore();
  const navigate = useNavigate();

  // Filter "my" campaigns — for the demo, use 4 from seed
  const myCampaigns = campaigns.filter((c) =>
    ['Nabat Textiles SAOC', 'Khareef Logistics LLC', user?.company].includes(c.borrower)
  ).slice(0, 4);
  // Fall back to first 3 if filter empty
  const showing = myCampaigns.length > 0 ? myCampaigns : campaigns.slice(0, 3);

  const active = showing.filter((c) => c.stage === 'funding').length;
  const funded = showing.filter((c) => ['funded', 'repayment'].includes(c.stage)).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('common.welcome')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{user?.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">{user?.company} · {t('borrower.dashboard')}</p>
        </div>
        <Button
          data-testid={RAWAFID.createCampaignButton}
          onClick={() => navigate('/app/create')}
          className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full h-10 px-5 font-semibold shadow-gold"
        >
          <Plus className="me-1 w-4 h-4" /> {t('borrower.qa_new')}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiTile label={t('borrower.kpi_active')} value={active} icon={FolderKanban} accent />
        <KpiTile label={t('borrower.kpi_funded')} value={funded} icon={CheckCircle2} />
        <KpiTile label={t('borrower.kpi_draft')} value={1} icon={FileEdit} />
        <KpiTile label={t('borrower.kpi_outstanding')} value={fmtCurrency(86400)} icon={Banknote} />
        <KpiTile label={t('borrower.kpi_upcoming')} value={fmtCurrency(5650)} sub="Dec 15, 2025" icon={Clock} />
        <KpiTile label={t('borrower.kpi_overdue')} value={fmtCurrency(0)} icon={AlertTriangle} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker={t('common.overview')} title={t('borrower.funding_pipeline')} />
          <FundingComboChart data={monthlyFunding} />
          <div className="mt-3 flex items-center gap-5 text-xs text-muted-foreground">
            <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm bg-muted" /> Target</span>
            <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm bg-accent" /> Funded</span>
          </div>
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker="Trend" title={t('borrower.revenue_trend')} />
          <ProfitAreaChart data={monthlyReturnSeries} />
        </GlassCard>
      </div>

      <GlassCard>
        <SectionHeader
          kicker={t('borrower.campaigns_title')}
          title={t('borrower.tracker_title')}
          action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/my-campaigns')}>{t('common.view_all')} →</Button>}
        />
        <div className="space-y-3">
          {showing.map((c) => {
            const pct = Math.round((c.raised / c.target) * 100);
            return (
              <div key={c.id} className="p-4 rounded-xl border border-border hover:border-accent/40 hover:shadow-card-elegant transition-all bg-card">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <RiskBadge grade={c.riskGrade} />
                    <div>
                      <div className="font-serif-display text-lg text-primary leading-tight">{c.title}</div>
                      <div className="text-xs text-muted-foreground">{c.id} · {t(`sectors.${c.sector}`)}</div>
                    </div>
                  </div>
                  <StatusPill tone={STAGE_TONE[c.stage] || 'neutral'}>{t(`borrower.stage_${c.stage}`)}</StatusPill>
                </div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">{fmtCurrency(c.raised)} / {fmtCurrency(c.target)} · {c.investors} investors</span>
                  <span className="font-semibold text-primary num-display">{pct}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
};
