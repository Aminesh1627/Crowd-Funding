import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { SECTORS } from '@/data/mockData';
import {
  ArrowRight, ArrowLeft, Save, CheckCircle2, FileText, Building2, BarChart3, Send,
} from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { toast } from 'sonner';

const STEPS = ['details', 'financials', 'documents', 'review'];

export const CreateCampaign = () => {
  const { t } = useI18n();
  const { createCampaign } = useStore();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [idx, setIdx] = useState(0);
  const [data, setData] = useState({
    title: '', purpose: '', target: 75000, tenure: 24, duration: 30, sector: 'manufacturing', rate: 11,
    revenue: 480000, profit: 78000, debt: 120000, assets: 220000, liabilities: 95000,
    borrower: user?.company || 'Nabat Textiles SAOC',
    docs: { cr: false, fin: false, bank: false, lic: false, board: false },
  });

  const update = (patch) => setData((d) => ({ ...d, ...patch }));
  const docUpload = (k) => update({ docs: { ...data.docs, [k]: true } });

  const dti = data.revenue ? (data.debt / data.revenue) : 0;
  const dscr = data.debt ? (data.profit / (data.debt * 0.05 + data.debt / data.tenure)) : 0;
  const currR = data.liabilities ? (data.assets / data.liabilities) : 0;

  const canNext = () => {
    if (idx === 0) return data.title.trim().length > 3 && data.target > 0;
    if (idx === 1) return data.revenue > 0 && data.profit > 0;
    if (idx === 2) return Object.values(data.docs).every(Boolean);
    return true;
  };

  const submit = () => {
    createCampaign(data);
    toast.success(t('borrower.campaign_submitted'));
    navigate('/app/my-campaigns');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('borrower.create')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">New Campaign</h1>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
            {t('borrower.create_step')} {idx + 1} {t('borrower.of')} {STEPS.length}
          </span>
        </div>
        <Progress value={((idx + 1) / STEPS.length) * 100} className="h-1.5 bg-muted [&>div]:bg-gradient-gold" />
        <div className="mt-4 grid grid-cols-4 gap-2">
          {STEPS.map((s, i) => (
            <div key={s} className={`text-center px-3 py-2 rounded-lg border ${i === idx ? 'border-accent bg-accent/10 font-semibold' : i < idx ? 'border-success/40 bg-success/5' : 'border-border'}`}>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{i + 1}</div>
              <div className="text-xs">{t(`borrower.step_${'abcd'[i]}`)}</div>
            </div>
          ))}
        </div>
      </div>

      <GlassCard>
        {idx === 0 && (
          <div>
            <SectionHeader kicker="Step 1" title={t('borrower.step_a')} />
            <div className="grid sm:grid-cols-2 gap-5">
              <Field span={2} label={t('borrower.f_title')} value={data.title} onChange={(v) => update({ title: v })} />
              <Field span={2} label={t('borrower.f_purpose')} value={data.purpose} onChange={(v) => update({ purpose: v })} textarea />
              <NumberField label={t('borrower.f_amount')} value={data.target} onChange={(v) => update({ target: v })} />
              <NumberField label={t('borrower.f_tenure')} value={data.tenure} onChange={(v) => update({ tenure: v })} />
              <NumberField label={t('borrower.f_duration')} value={data.duration} onChange={(v) => update({ duration: v })} />
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('borrower.f_sector')}</label>
                <select value={data.sector} onChange={(e) => update({ sector: e.target.value })} className="w-full h-11 px-3 rounded-lg border border-input bg-background text-sm">
                  {SECTORS.map((s) => <option key={s} value={s}>{t(`sectors.${s}`)}</option>)}
                </select>
              </div>
            </div>
          </div>
        )}

        {idx === 1 && (
          <div>
            <SectionHeader kicker="Step 2" title={t('borrower.step_b')} />
            <div className="grid sm:grid-cols-2 gap-5">
              <NumberField label={t('borrower.f_revenue')} value={data.revenue} onChange={(v) => update({ revenue: v })} />
              <NumberField label={t('borrower.f_profit')} value={data.profit} onChange={(v) => update({ profit: v })} />
              <NumberField label={t('borrower.f_debt')} value={data.debt} onChange={(v) => update({ debt: v })} />
              <NumberField label={t('borrower.f_assets')} value={data.assets} onChange={(v) => update({ assets: v })} />
              <NumberField label={t('borrower.f_liab')} value={data.liabilities} onChange={(v) => update({ liabilities: v })} />
            </div>
            <div className="mt-6 grid sm:grid-cols-3 gap-3">
              <Metric label={t('borrower.dti')} value={dti.toFixed(2)} tone={dti < 0.5 ? 'success' : 'warning'} />
              <Metric label={t('borrower.dscr')} value={dscr.toFixed(2)} tone={dscr > 1.5 ? 'success' : 'warning'} />
              <Metric label={t('borrower.currR')} value={currR.toFixed(2)} tone={currR > 1.5 ? 'success' : 'warning'} />
            </div>
          </div>
        )}

        {idx === 2 && (
          <div>
            <SectionHeader kicker="Step 3" title={t('borrower.step_c')} />
            <div className="space-y-3">
              {[
                { k: 'cr', l: 'borrower.doc_cr' }, { k: 'fin', l: 'borrower.doc_fin' },
                { k: 'bank', l: 'borrower.doc_bank' }, { k: 'lic', l: 'borrower.doc_lic' },
                { k: 'board', l: 'borrower.doc_board' },
              ].map((d) => (
                <div key={d.k} className={`p-4 rounded-lg border flex items-center justify-between ${data.docs[d.k] ? 'border-success/40 bg-success/5' : 'border-dashed border-border bg-muted/30'}`}>
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-accent" />
                    <span className="text-sm font-medium">{t(d.l)}</span>
                  </div>
                  {data.docs[d.k] ? (
                    <StatusPill tone="success"><CheckCircle2 className="w-3 h-3" /> Uploaded</StatusPill>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => docUpload(d.k)}>{t('common.upload')}</Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {idx === 3 && (
          <div>
            <SectionHeader kicker="Step 4" title={t('borrower.step_d')} />
            <div className="grid sm:grid-cols-2 gap-4">
              <ReviewRow label={t('borrower.f_title')} value={data.title} />
              <ReviewRow label={t('borrower.f_sector')} value={t(`sectors.${data.sector}`)} />
              <ReviewRow label={t('borrower.f_amount')} value={data.target.toLocaleString()} />
              <ReviewRow label={t('borrower.f_tenure')} value={`${data.tenure} months`} />
              <ReviewRow label={t('borrower.dti')} value={dti.toFixed(2)} />
              <ReviewRow label={t('borrower.dscr')} value={dscr.toFixed(2)} />
              <ReviewRow label={t('borrower.currR')} value={currR.toFixed(2)} />
              <ReviewRow label="Documents" value={`${Object.values(data.docs).filter(Boolean).length}/5 uploaded`} />
            </div>
            <div className="mt-6 rounded-lg p-4 bg-accent/10 border border-accent/30 text-xs">
              Once submitted, your campaign will be routed through Credit → Risk → Compliance review (typically 5 business days).
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
          <Button variant="ghost" onClick={() => setIdx((i) => Math.max(0, i - 1))} disabled={idx === 0}>
            <ArrowLeft className="me-1 w-4 h-4 rtl-flip" /> {t('common.back')}
          </Button>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={() => toast.info(t('borrower.draft_saved'))}>
              <Save className="me-1 w-4 h-4" /> {t('common.save')}
            </Button>
            {idx < STEPS.length - 1 ? (
              <Button onClick={() => setIdx((i) => i + 1)} disabled={!canNext()} className="bg-primary hover:bg-primary/90 rounded-full">
                {t('common.next')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
              </Button>
            ) : (
              <Button
                data-testid={RAWAFID.createCampaignSubmit}
                onClick={submit}
                className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full font-semibold shadow-gold"
              >
                <Send className="me-1 w-4 h-4" /> {t('borrower.submit_campaign')}
              </Button>
            )}
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

const Field = ({ label, value, onChange, span, textarea }) => (
  <div className={span === 2 ? 'sm:col-span-2' : ''}>
    <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{label}</label>
    {textarea ? (
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3} className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
    ) : (
      <input type="text" value={value} onChange={(e) => onChange(e.target.value)} className="w-full h-11 px-3 rounded-lg border border-input bg-background text-sm" />
    )}
  </div>
);

const NumberField = ({ label, value, onChange }) => (
  <div>
    <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{label}</label>
    <input type="number" value={value} onChange={(e) => onChange(Number(e.target.value) || 0)} className="w-full h-11 px-3 rounded-lg border border-input bg-background text-sm num-display" />
  </div>
);

const Metric = ({ label, value, tone }) => (
  <div className="rounded-lg border border-border bg-card p-4 text-center">
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    <div className={`font-serif-display text-2xl mt-1 num-display ${tone === 'success' ? 'text-success' : 'text-warning'}`}>{value}</div>
  </div>
);

const ReviewRow = ({ label, value }) => (
  <div className="flex justify-between p-3 rounded-lg bg-muted/40">
    <span className="text-xs text-muted-foreground">{label}</span>
    <span className="text-sm font-medium">{value || '—'}</span>
  </div>
);

export default CreateCampaign;
