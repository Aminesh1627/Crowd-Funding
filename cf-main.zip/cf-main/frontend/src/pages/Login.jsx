import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useAuth, MOCK_USERS, ROLE_KEYS } from '@/context/AuthContext';
import { Logo } from '@/components/Logo';
import { LangToggle } from '@/components/LangToggle';
import { Button } from '@/components/ui/button';
import { Briefcase, Building2, ShieldCheck, Scale, ArrowRight, Lock, Mail, Eye, EyeOff } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { StatusPill } from '@/components/Primitives';

const ROLE_ICONS = { investor: Briefcase, borrower: Building2, admin: ShieldCheck, regulator: Scale };

export const Login = () => {
  const { t } = useI18n();
  const { login, onboarding } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState('credentials'); // 'credentials' | 'role'
  const [email, setEmail] = useState('demo@rawafid.om');
  const [password, setPassword] = useState('demo1234');
  const [showPwd, setShowPwd] = useState(false);

  const handleSignIn = (e) => {
    e.preventDefault();
    setStep('role');
  };

  const handleRolePick = (r) => {
    login(r);
    // Investor goes to onboarding if not yet verified
    if (r === 'investor' && onboarding?.investor?.completedAt == null) {
      navigate('/onboarding');
    } else {
      navigate('/app/dashboard');
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      {/* Left visual */}
      <div className="hidden lg:block relative overflow-hidden bg-gradient-royal text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,hsl(40_80%_60%/0.25),transparent_60%)]" />
        <div className="absolute -top-20 -end-20 w-96 h-96 rounded-full bg-accent/10 blur-3xl" />
        <div className="absolute -bottom-32 -start-32 w-[500px] h-[500px] rounded-full bg-secondary/20 blur-3xl" />
        <div className="relative h-full p-12 flex flex-col">
          <Logo size="md" light withTag />
          <div className="mt-auto max-w-md animate-fade-up">
            <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-3">
              {t('login.title')}
            </div>
            <h1 className="font-serif-display text-5xl leading-tight text-white">
              {t('landing.title_a')} <span className="gradient-text-gold">{t('landing.title_b')}</span>
            </h1>
            <p className="mt-5 text-white/75 text-lg leading-relaxed">{t('landing.subtitle')}</p>
            <div className="mt-10 flex items-center gap-2 text-xs text-accent/90 tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              {t('landing.trust_pill')}
            </div>
          </div>
        </div>
      </div>

      {/* Right form */}
      <div className="relative flex flex-col">
        <div className="flex items-center justify-between px-8 py-6">
          <div className="flex items-center gap-3">
            <a
              href="/"
              data-testid="login-back-home"
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <span aria-hidden>←</span> {t('common.back_to_home')}
            </a>
          </div>
          <div className="lg:hidden"><Logo size="sm" /></div>
          <div className="ms-auto"><LangToggle /></div>
        </div>

        <div className="flex-1 grid place-items-center p-6 sm:p-12">
          <div className="w-full max-w-md animate-fade-up">
            {step === 'credentials' && (
              <>
                <h2 className="font-serif-display text-3xl text-primary">{t('login.title')}</h2>
                <p className="mt-2 text-muted-foreground">{t('login.subtitle')}</p>

                <form onSubmit={handleSignIn} className="mt-10 space-y-5">
                  <div>
                    <label className="text-xs uppercase tracking-[0.16em] text-muted-foreground font-medium block mb-2">
                      {t('login.email')}
                    </label>
                    <div className="relative">
                      <Mail className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <input
                        data-testid={RAWAFID.loginEmail}
                        type="text"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full h-11 ps-10 pe-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs uppercase tracking-[0.16em] text-muted-foreground font-medium block mb-2">
                      {t('login.password')}
                    </label>
                    <div className="relative">
                      <Lock className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <input
                        data-testid={RAWAFID.loginPassword}
                        type={showPwd ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full h-11 ps-10 pe-10 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPwd((v) => !v)}
                        className="absolute end-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <label className="inline-flex items-center gap-2 text-muted-foreground">
                      <input type="checkbox" className="rounded border-input" defaultChecked />
                      {t('login.remember')}
                    </label>
                    <a href="#" className="text-accent hover:underline">{t('login.forgot')}</a>
                  </div>
                  <Button
                    type="submit"
                    data-testid={RAWAFID.loginSubmit}
                    className="w-full h-12 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg font-semibold shadow-elegant"
                  >
                    {t('login.signin')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
                  </Button>
                </form>

                <div className="mt-8 p-4 rounded-lg bg-accent/10 border border-accent/30">
                  <div className="text-xs text-foreground/80 leading-relaxed">
                    <ShieldCheck className="inline w-3.5 h-3.5 me-1 text-accent" />
                    {t('login.demo_hint')}
                  </div>
                </div>

                <p className="mt-8 text-center text-sm text-muted-foreground">
                  {t('login.new_here')}{' '}
                  <a href="#" className="text-primary font-semibold hover:underline">{t('login.create_account')}</a>
                </p>
              </>
            )}

            {step === 'role' && (
              <>
                <h2 className="font-serif-display text-3xl text-primary">
                  {t('login.role_picker_title')}
                </h2>
                <p className="mt-2 text-muted-foreground">{t('login.role_picker_sub')}</p>

                <div className="mt-8 space-y-3">
                  {ROLE_KEYS.map((r) => {
                    const Icon = ROLE_ICONS[r];
                    const u = MOCK_USERS[r];
                    return (
                      <button
                        key={r}
                        data-testid={RAWAFID.loginRoleCard(r)}
                        onClick={() => handleRolePick(r)}
                        className="group w-full text-start flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:border-accent hover:shadow-elegant hover-lift transition-all"
                      >
                        <div className="w-12 h-12 rounded-lg bg-gradient-gold grid place-items-center shadow-gold shrink-0">
                          <Icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <div className="font-semibold text-foreground">{t(`roles.${r}`)}</div>
                            {r === 'investor' && (
                              <StatusPill tone="info">Onboarding</StatusPill>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5 truncate">
                            {u.name} · {u.email}
                          </div>
                          <div className="text-[11px] text-muted-foreground/80 mt-1">
                            {t(`roles.${r}_desc`)}
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-accent transition-colors rtl-flip" />
                      </button>
                    );
                  })}
                </div>

                <button
                  onClick={() => setStep('credentials')}
                  className="mt-6 text-sm text-muted-foreground hover:text-foreground"
                >
                  ← {t('common.back')}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
