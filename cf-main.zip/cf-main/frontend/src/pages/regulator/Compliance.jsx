import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { LineTrendChart, HorizontalBarChart } from '@/components/Charts';
import { complianceTrend, sectorConcentration } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Download, ShieldAlert, Eye, Paperclip, CheckCircle2 } from 'lucide-react';
import { SlideOver } from '@/components/SlideOver';
import { toast } from 'sonner';

export const Compliance = () => {
  const { t } = useI18n();
  const { complianceFlags } = useStore();
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('roles.regulator')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('regulator.compliance_title')}</h1>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker="Trend" title="Flags vs. resolutions" />
          <LineTrendChart data={complianceTrend} />
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker="Concentration" title={t('regulator.sector_concentration')} />
          <HorizontalBarChart data={sectorConcentration} dataKey="share" />
        </GlassCard>
      </div>

      <GlassCard>
        <SectionHeader
          kicker="Open"
          title="Live compliance flags"
          action={<Button size="sm" variant="outline"><Download className="me-1 w-4 h-4" /> {t('regulator.export_csv')}</Button>}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">Flag</th>
                <th className="text-start py-3">Type</th>
                <th className="text-start py-3">Subject</th>
                <th className="text-start py-3">Detail</th>
                <th className="text-end py-3">Severity</th>
                <th className="text-end py-3">Opened</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {complianceFlags.map((f) => (
                <tr key={f.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{f.id}</td>
                  <td className="py-3"><StatusPill tone="warning"><ShieldAlert className="w-3 h-3" /> {f.type}</StatusPill></td>
                  <td className="py-3 font-mono text-xs">{f.subject}</td>
                  <td className="py-3">{f.detail}</td>
                  <td className="py-3 text-end"><StatusPill tone={f.severity === 'high' ? 'danger' : f.severity === 'medium' ? 'warning' : 'info'}>{f.severity}</StatusPill></td>
                  <td className="py-3 text-end text-xs text-muted-foreground">{f.opened}</td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="outline" data-testid={`compliance-review-${f.id}`} onClick={() => setOpen(f)}>
                      <Eye className="me-1 w-3.5 h-3.5" /> {t('common.view')}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <SlideOver
        open={!!open}
        onClose={() => setOpen(null)}
        title={open ? `${open.id} · ${t('compliance_review.title')}` : ''}
        subtitle={open?.detail}
        testId="compliance-slideover"
        width="md"
        footer={
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => { toast.info('Escalated to committee'); setOpen(null); }} data-testid="compliance-escalate">
              {t('compliance_review.escalate')}
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => toast.info('Finding attached.')} data-testid="compliance-attach">
                <Paperclip className="me-1 w-4 h-4" /> {t('compliance_review.attach')}
              </Button>
              <Button className="bg-success hover:bg-success/90 text-success-foreground" data-testid="compliance-close" onClick={() => { toast.success(t('compliance_review.finding_recorded')); setOpen(null); }}>
                <CheckCircle2 className="me-1 w-4 h-4" /> {t('compliance_review.close')}
              </Button>
            </div>
          </div>
        }
      >
        {open && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-3">
              <Box label={t('compliance_review.severity')} value={open.severity} />
              <Box label={t('compliance_review.opened')} value={open.opened} />
              <Box label={t('compliance_review.affected')} value={open.subject} />
              <Box label={t('compliance_review.regulator_ref')} value={`REG-${open.id}`} />
            </div>

            <Section title={t('compliance_review.summary')} kicker="Detail">
              <div className="text-sm p-3 rounded-lg bg-muted/40 border border-border">{open.detail}</div>
            </Section>

            <Section title={t('compliance_review.evidence')} kicker="Attachments">
              <div className="space-y-2">
                {['AML screening log', 'Sanctions hit detail', 'Adverse media excerpts'].map((d) => (
                  <div key={d} className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30">
                    <div className="text-sm">{d}</div>
                    <Button size="sm" variant="ghost"><Download className="me-1 w-3.5 h-3.5" /> {t('common.download')}</Button>
                  </div>
                ))}
              </div>
            </Section>

            <Section title={t('compliance_review.timeline')} kicker="History">
              <ol className="relative border-s border-border ms-3 space-y-3 ps-4">
                {[
                  { d: '2025-12-04 09:15', t: 'Flag escalated to committee' },
                  { d: '2025-12-03 17:48', t: 'AML evidence pack attached' },
                  { d: '2025-12-02 22:02', t: 'Flag opened by AML screening' },
                ].map((row, i) => (
                  <li key={i} className="text-sm">
                    <span className="absolute -start-1.5 mt-1 w-2 h-2 rounded-full bg-accent" />
                    <div className="text-xs text-muted-foreground">{row.d}</div>
                    <div>{row.t}</div>
                  </li>
                ))}
              </ol>
            </Section>

            <Section title={t('compliance_review.actions')} kicker="Note">
              <textarea
                value={note} onChange={(e) => setNote(e.target.value)}
                rows={3} placeholder="Add regulator finding..."
                className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm"
              />
            </Section>
          </div>
        )}
      </SlideOver>
    </div>
  );
};

const Box = ({ label, value }) => (
  <div className="rounded-lg p-3 bg-gradient-subtle border border-border">
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    <div className="font-serif-display text-base text-primary num-display mt-0.5 capitalize">{value}</div>
  </div>
);
const Section = ({ kicker, title, children }) => (
  <div>
    <div className="mb-2">
      <div className="text-[10px] uppercase tracking-[0.22em] text-accent font-semibold">{kicker}</div>
      <div className="font-serif-display text-base text-primary">{title}</div>
    </div>
    {children}
  </div>
);

export default Compliance;
