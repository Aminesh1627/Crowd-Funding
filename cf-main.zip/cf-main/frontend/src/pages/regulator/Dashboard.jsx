import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, KpiTile, SectionHeader, StatusPill } from '@/components/Primitives';
import {
  PieAllocChart, LineTrendChart, HorizontalBarChart,
} from '@/components/Charts';
import { complianceTrend, sectorConcentration, industryAlloc } from '@/data/mockData';
import {
  Banknote, FolderKanban, ShieldAlert, AlertOctagon, MessageSquareWarning, FileText,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export const RegulatorDashboard = () => {
  const { t, fmtCurrency, fmtNum } = useI18n();
  const { complianceFlags, campaigns, auditLogs } = useStore();
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('roles.regulator')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('regulator.dashboard')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('regulator.sub')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiTile label={t('regulator.kpi_aum')} value={fmtCurrency(18420000)} icon={Banknote} accent />
        <KpiTile label={t('regulator.kpi_campaigns')} value={campaigns.filter((c) => c.stage === 'funding').length} icon={FolderKanban} />
        <KpiTile label={t('regulator.kpi_compliance')} value={complianceFlags.length} icon={ShieldAlert} />
        <KpiTile label={t('regulator.kpi_aml')} value={3} delta={{ value: -1, label: 'WoW' }} icon={AlertOctagon} />
        <KpiTile label={t('regulator.kpi_complaints')} value={1} icon={MessageSquareWarning} />
        <KpiTile label={t('regulator.kpi_disclosures')} value={47} icon={FileText} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker="Trend" title="Compliance flags vs. resolutions" />
          <LineTrendChart data={complianceTrend} />
          <div className="mt-3 flex items-center gap-5 text-xs text-muted-foreground">
            <span className="flex items-center gap-2"><span className="w-3 h-0.5 rounded-sm bg-[#c44545]" /> Flags</span>
            <span className="flex items-center gap-2"><span className="w-3 h-0.5 rounded-sm bg-[#2d6a4f]" /> Resolved</span>
          </div>
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker="Mix" title={t('regulator.sector_concentration')} />
          <PieAllocChart data={industryAlloc} />
        </GlassCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard>
          <SectionHeader
            kicker="Live"
            title={t('regulator.compliance_title')}
            action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/compliance')}>{t('common.view_all')} <ArrowRight className="ms-1 w-3.5 h-3.5 rtl-flip" /></Button>}
          />
          <div className="space-y-2">
            {complianceFlags.map((f) => (
              <div key={f.id} className="p-3 rounded-lg border border-border flex items-center justify-between gap-3 hover:bg-muted/40">
                <div className="flex items-center gap-3 min-w-0">
                  <StatusPill tone={f.severity === 'high' ? 'danger' : f.severity === 'medium' ? 'warning' : 'info'}>
                    {f.type}
                  </StatusPill>
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{f.detail}</div>
                    <div className="text-[11px] text-muted-foreground">{f.subject} · {f.opened}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard>
          <SectionHeader
            kicker="Audit"
            title="Latest platform events"
            action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/audit')}>{t('regulator.audit_title')} <ArrowRight className="ms-1 w-3.5 h-3.5 rtl-flip" /></Button>}
          />
          <div className="space-y-2">
            {auditLogs.slice(0, 5).map((l) => (
              <div key={l.id} className="p-3 rounded-lg border border-border">
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                  <span className="font-mono">{l.at}</span>
                  <StatusPill tone={l.severity === 'warning' ? 'warning' : l.severity === 'success' ? 'success' : 'info'}>{l.severity}</StatusPill>
                </div>
                <div className="text-sm text-foreground">{l.action}</div>
                <div className="text-[11px] text-muted-foreground mt-1">{l.actor} · {l.role}</div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
