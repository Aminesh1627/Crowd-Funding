import React, { useState, useMemo } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, StatusPill, KpiTile, RiskBadge } from '@/components/Primitives';
import { Button } from '@/components/ui/button';
import { Scale, Search, ExternalLink, Gavel, FileText, Calendar, Building2 } from 'lucide-react';
import { seedLawSuiteCases } from '@/data/mockDataV2';

const STAGE_TONE = {
  stage_filed: 'info', stage_hearing: 'warning', stage_judgment: 'gold',
  stage_appeal: 'warning', stage_closed: 'neutral',
};
const OUTCOME_TONE = { won: 'success', lost: 'danger', settled: 'neutral' };

export const LawSuite = () => {
  const { t, fmtCurrency } = useI18n();
  const cases = seedLawSuiteCases();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = useMemo(() => {
    let list = cases;
    if (filter !== 'all') list = list.filter((c) => c.stage === filter);
    if (q) list = list.filter((c) =>
      [c.id, c.plaintiff, c.defendant, c.court].join(' ').toLowerCase().includes(q.toLowerCase())
    );
    return list;
  }, [cases, q, filter]);

  const stats = {
    active: cases.filter((c) => !['stage_closed'].includes(c.stage)).length,
    won: cases.filter((c) => c.outcome === 'won').length,
    lost: cases.filter((c) => c.outcome === 'lost').length,
    pending: cases.filter((c) => c.stage === 'stage_hearing').length,
    settled: cases.filter((c) => c.outcome === 'settled').length,
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <Scale className="w-3.5 h-3.5" /> {t('nav.law_suite')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('lawsuite.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('lawsuite.subtitle')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <KpiTile label={t('lawsuite.kpi_active')} value={stats.active} icon={Gavel} accent />
        <KpiTile label={t('lawsuite.kpi_pending')} value={stats.pending} icon={Calendar} />
        <KpiTile label={t('lawsuite.kpi_won')} value={stats.won} icon={FileText} />
        <KpiTile label={t('lawsuite.kpi_lost')} value={stats.lost} icon={FileText} />
        <KpiTile label={t('lawsuite.kpi_settled')} value={stats.settled} icon={FileText} />
      </div>

      <GlassCard>
        <SectionHeader
          kicker="Cases"
          title="All proceedings"
          action={
            <div className="flex items-center gap-2">
              <select value={filter} onChange={(e) => setFilter(e.target.value)} className="h-9 px-3 rounded-full border border-input bg-background text-sm">
                <option value="all">All stages</option>
                {['stage_filed', 'stage_hearing', 'stage_judgment', 'stage_appeal', 'stage_closed'].map((s) =>
                  <option key={s} value={s}>{t(`lawsuite.${s}`)}</option>)}
              </select>
              <div className="relative">
                <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.type_to_search')}
                  className="h-9 w-64 ps-9 pe-3 rounded-full border border-input bg-background text-sm" />
              </div>
            </div>
          }
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">{t('lawsuite.case_id')}</th>
                <th className="text-start py-3">{t('lawsuite.plaintiff')}</th>
                <th className="text-start py-3">{t('lawsuite.defendant')}</th>
                <th className="text-start py-3">Type</th>
                <th className="text-start py-3">{t('lawsuite.court')}</th>
                <th className="text-end py-3">{t('common.amount')}</th>
                <th className="text-end py-3">{t('lawsuite.filed')}</th>
                <th className="text-end py-3">Stage</th>
                <th className="text-end py-3">{t('lawsuite.next_hearing')}</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{c.id}</td>
                  <td className="py-3 font-medium">{c.plaintiff}</td>
                  <td className="py-3">{c.defendant}</td>
                  <td className="py-3 text-xs text-muted-foreground">{t(`lawsuite.${c.type}`)}</td>
                  <td className="py-3 text-xs">{c.court}</td>
                  <td className="py-3 text-end num-display font-semibold">{c.amount > 0 ? fmtCurrency(c.amount) : '—'}</td>
                  <td className="py-3 text-end text-xs text-muted-foreground">{c.filed}</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={STAGE_TONE[c.stage] || 'neutral'}>{t(`lawsuite.${c.stage}`)}</StatusPill>
                    {c.outcome && (
                      <div className="mt-1">
                        <StatusPill tone={OUTCOME_TONE[c.outcome]}>{c.outcome}</StatusPill>
                      </div>
                    )}
                  </td>
                  <td className="py-3 text-end text-xs">{c.nextHearing}</td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="ghost" data-testid={`lawsuite-open-${c.id}`}>
                      <ExternalLink className="me-1 w-3.5 h-3.5" /> {t('lawsuite.open_pdf')}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export default LawSuite;
