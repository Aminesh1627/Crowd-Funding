import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Button } from '@/components/ui/button';
import { Download, Search, ShieldCheck } from 'lucide-react';

export const AuditLogs = () => {
  const { t } = useI18n();
  const { auditLogs } = useStore();
  const [q, setQ] = useState('');

  const filtered = auditLogs.filter((l) =>
    JSON.stringify(l).toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('roles.regulator')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('regulator.audit_title')}</h1>
        <p className="text-sm text-muted-foreground mt-1 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-accent" />
          {t('regulator.audit_sub')}
        </p>
      </div>

      <GlassCard>
        <SectionHeader
          kicker="Logs"
          title="All events"
          action={
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={t('common.type_to_search')}
                  className="h-9 w-64 ps-9 pe-3 rounded-full border border-input bg-background text-sm"
                />
              </div>
              <Button size="sm" variant="outline"><Download className="me-1 w-4 h-4" /> {t('regulator.export_csv')}</Button>
            </div>
          }
        />

        <div className="space-y-2">
          {filtered.map((l) => (
            <div key={l.id} className="p-4 rounded-lg border border-border hover:bg-muted/30 transition-colors">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{l.at}</span>
                  <StatusPill tone={l.severity === 'warning' ? 'warning' : l.severity === 'success' ? 'success' : 'info'}>{l.severity}</StatusPill>
                </div>
                <span className="font-mono text-[11px] text-muted-foreground">{l.id}</span>
              </div>
              <div className="text-sm font-medium text-foreground">{l.action}</div>
              <div className="text-xs text-muted-foreground mt-1.5 flex flex-wrap items-center gap-3">
                <span>{l.actor}</span>
                <span>·</span>
                <span className="capitalize">{l.role}</span>
                <span>·</span>
                <span className="font-mono">{l.target}</span>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};

export default AuditLogs;
