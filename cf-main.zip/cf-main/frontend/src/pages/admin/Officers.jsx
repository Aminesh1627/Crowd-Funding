import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, KpiTile, SectionHeader, StatusPill, RiskBadge } from '@/components/Primitives';
import { SlideOver } from '@/components/SlideOver';
import { Briefcase, ShieldCheck, Sparkles, Gavel, Check, X, MessageSquare, RefreshCcw, FileText, ScanSearch, Plus } from 'lucide-react';
import { seedOfficerCases, malaaPull, policyChecks, scorecardRows } from '@/data/mockDataV2';
import { toast } from 'sonner';

const OFFICER_META = {
  credit: { icon: Briefcase, titleKey: 'officer.credit_title', kicker: 'nav.credit_officer' },
  risk: { icon: ShieldCheck, titleKey: 'officer.risk_title', kicker: 'nav.risk_officer' },
  onboarding: { icon: Sparkles, titleKey: 'officer.onboarding_title', kicker: 'nav.onboarding_officer' },
  compliance: { icon: Gavel, titleKey: 'officer.compliance_title', kicker: 'nav.compliance_officer' },
};

export const OfficerPage = ({ officer }) => {
  const { t, fmtCurrency } = useI18n();
  const { decideCampaign } = useStore();
  const [cases, setCases] = useState(() => seedOfficerCases(officer));
  const [open, setOpen] = useState(null);
  const [comment, setComment] = useState('');
  const [conditions, setConditions] = useState([]);
  const [newCondition, setNewCondition] = useState('');

  const meta = OFFICER_META[officer] || OFFICER_META.credit;
  const Icon = meta.icon;

  const decide = (decision) => {
    if (!open) return;
    const id = open.id;
    // Update local UI first so the queue row is removed immediately.
    setCases((prev) => prev.filter((c) => c.id !== id));
    setOpen(null);
    setComment('');
    setConditions([]);
    // Defer the global mutation to avoid racing the slide-over close.
    setTimeout(() => {
      decideCampaign(id, decision === 'approve' ? 'approve' : 'reject');
      toast.success(`${decision === 'approve' ? 'Approved' : 'Rejected'} · routed to next stage`);
    }, 50);
  };

  const addCondition = () => {
    if (!newCondition.trim()) return;
    setConditions((prev) => [...prev, newCondition.trim()]);
    setNewCondition('');
  };

  const avgScore = Math.round(cases.reduce((s, c) => s + c.score, 0) / Math.max(1, cases.length));
  const slaBreaches = cases.filter((c) => parseInt(c.sla) <= 6).length;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
            <Icon className="w-3.5 h-3.5" /> {t(meta.kicker)}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{t(meta.titleKey)}</h1>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiTile label={t('officer.cases_in_queue')} value={cases.length} icon={Icon} accent />
        <KpiTile label={t('officer.sla_breach')} value={slaBreaches} icon={RefreshCcw} />
        <KpiTile label={t('officer.avg_sla')} value="9.4h" icon={ScanSearch} />
        <KpiTile label="Avg. score" value={avgScore} icon={FileText} />
      </div>

      <GlassCard>
        <SectionHeader kicker="Queue" title="Pending cases" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Borrower</th>
                <th className="text-start py-3">{t('common.sector')}</th>
                <th className="text-end py-3">{t('common.amount')}</th>
                <th className="text-end py-3">Score</th>
                <th className="text-end py-3">{t('admin.priority')}</th>
                <th className="text-end py-3">{t('admin.sla')}</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {cases.length === 0 && (
                <tr><td colSpan="8" className="py-12 text-center text-muted-foreground">All clear — no pending cases.</td></tr>
              )}
              {cases.map((c) => (
                <tr key={c.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{c.id}</td>
                  <td className="py-3 font-medium">{c.borrower}</td>
                  <td className="py-3"><StatusPill tone="gold">{t(`sectors.${c.sector}`)}</StatusPill></td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(c.amount)}</td>
                  <td className="py-3 text-end num-display">{c.score}</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={c.priority === 'high' ? 'danger' : c.priority === 'medium' ? 'warning' : 'neutral'}>
                      {t(`admin.${c.priority[0]}_priority`)}
                    </StatusPill>
                  </td>
                  <td className="py-3 text-end font-mono text-xs text-muted-foreground">{c.sla}</td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="outline" data-testid={`officer-open-${c.id}`} onClick={() => setOpen(c)}>
                      {t('officer.open_panel')} →
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <SlideOver
        open={!!open}
        onClose={() => setOpen(null)}
        title={open ? `${open.id} · ${open.borrower}` : ''}
        subtitle={open ? `${t(meta.kicker)} review` : ''}
        testId="officer-slideover"
        width="xl"
        footer={
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={() => { toast.info('Returned for clarification.'); setOpen(null); }} data-testid="officer-clarify">
              <MessageSquare className="me-1 w-4 h-4" /> {t('common.clarify')}
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => toast.info('Escalated to committee.')} data-testid="officer-escalate">
                {t('officer.escalate')}
              </Button>
              <Button variant="destructive" data-testid="officer-reject" onClick={() => decide('reject')}>
                <X className="me-1 w-4 h-4" /> {t('common.reject')}
              </Button>
              <Button className="bg-success hover:bg-success/90 text-success-foreground" data-testid="officer-approve" onClick={() => decide('approve')}>
                <Check className="me-1 w-4 h-4" /> {t('common.approve')}
              </Button>
            </div>
          </div>
        }
      >
        {open && (
          <div className="space-y-6">
            {/* Summary stripe */}
            <div className="grid sm:grid-cols-4 gap-3">
              <SmallBox label={t('common.amount')} value={fmtCurrency(open.amount)} />
              <SmallBox label="Sector" value={t(`sectors.${open.sector}`)} />
              <SmallBox label="Score" value={open.score} />
              <SmallBox label="SLA" value={open.sla} />
            </div>

            {/* Ma'laa pull */}
            <Section title={t('officer.malaa')} kicker={t('officer.external_pulls')}>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {(() => {
                  const m = malaaPull(open.id);
                  return [
                    { l: t('officer.malaa_score'), v: m.cbScore },
                    { l: t('officer.malaa_status'), v: m.status },
                    { l: t('officer.malaa_loans'), v: m.activeFacilities },
                    { l: 'Total exposure', v: fmtCurrency(m.totalExposureOMR) },
                    { l: 'Delinquent (24m)', v: m.delinquentLast24m },
                    { l: 'Inquiries (6m)', v: m.inquiriesLast6m },
                    { l: 'As of', v: m.asOfDate },
                  ].map((x, i) => (
                    <div key={i} className="rounded-lg p-3 bg-muted/40 border border-border">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{x.l}</div>
                      <div className="font-serif-display text-lg text-primary num-display mt-0.5">{x.v}</div>
                    </div>
                  ));
                })()}
              </div>
            </Section>

            {/* Policy checks */}
            <Section title={t('officer.policy_checks')} kicker="Policy">
              <div className="grid sm:grid-cols-2 gap-2">
                {policyChecks.map((p) => (
                  <div key={p.id} className={`flex items-center justify-between p-3 rounded-lg border ${
                    p.status === 'pass' ? 'border-success/30 bg-success/5' :
                    p.status === 'warn' ? 'border-warning/30 bg-warning/5' :
                    'border-destructive/30 bg-destructive/5'
                  }`}>
                    <div className="text-sm">{p.name}</div>
                    <StatusPill tone={p.status === 'pass' ? 'success' : p.status === 'warn' ? 'warning' : 'danger'}>{p.status}</StatusPill>
                  </div>
                ))}
              </div>
            </Section>

            {/* Scorecard */}
            <Section title={t('officer.scorecard')} kicker="Decision">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b">
                      <th className="text-start py-2">Factor</th>
                      <th className="text-end py-2">Weight</th>
                      <th className="text-end py-2">Score</th>
                      <th className="text-end py-2">Contribution</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scorecardRows.map((row, i) => (
                      <tr key={i} className="border-b border-border/40 last:border-b-0">
                        <td className="py-2">{row.factor}</td>
                        <td className="py-2 text-end num-display">{row.weight}%</td>
                        <td className="py-2 text-end num-display">{row.score}</td>
                        <td className="py-2 text-end num-display font-semibold">{row.contribution.toFixed(1)}</td>
                      </tr>
                    ))}
                    <tr className="font-semibold">
                      <td colSpan={3} className="py-2 text-end">Composite</td>
                      <td className="py-2 text-end num-display text-accent text-lg">
                        {scorecardRows.reduce((s, r) => s + r.contribution, 0).toFixed(1)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Section>

            {/* Conditions */}
            <Section title={t('officer.conditions')} kicker="Apply">
              <div className="space-y-2 mb-2">
                {conditions.map((c, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/40 border border-border">
                    <span className="text-sm">{c}</span>
                    <button onClick={() => setConditions((prev) => prev.filter((_, j) => j !== i))} className="text-muted-foreground hover:text-destructive">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                {conditions.length === 0 && <div className="text-xs text-muted-foreground">No conditions added.</div>}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text" value={newCondition} onChange={(e) => setNewCondition(e.target.value)}
                  placeholder="e.g. Personal guarantee from MD"
                  className="flex-1 h-10 px-3 rounded-lg border border-input bg-background text-sm"
                />
                <Button size="sm" variant="outline" onClick={addCondition} data-testid="officer-add-condition">
                  <Plus className="me-1 w-3.5 h-3.5" /> {t('officer.add_condition')}
                </Button>
              </div>
            </Section>

            {/* Comments */}
            <Section title={t('admin.comments')} kicker="Notes">
              <textarea
                value={comment} onChange={(e) => setComment(e.target.value)} rows={3}
                placeholder="Add reviewer comments..."
                className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm"
              />
            </Section>
          </div>
        )}
      </SlideOver>
    </div>
  );
};

const Section = ({ title, kicker, children }) => (
  <div>
    <div className="flex items-end justify-between mb-2">
      <div>
        <div className="text-[10px] uppercase tracking-[0.22em] text-accent font-semibold">{kicker}</div>
        <div className="font-serif-display text-lg text-primary">{title}</div>
      </div>
    </div>
    {children}
  </div>
);
const SmallBox = ({ label, value }) => (
  <div className="rounded-lg p-3 bg-gradient-subtle border border-border">
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    <div className="font-serif-display text-base text-primary num-display mt-0.5">{value}</div>
  </div>
);

// Specific officer entry components
export const CreditOfficer = () => <OfficerPage officer="credit" />;
export const RiskOfficer = () => <OfficerPage officer="risk" />;
export const OnboardingOfficer = () => <OfficerPage officer="onboarding" />;
export const ComplianceOfficer = () => <OfficerPage officer="compliance" />;
