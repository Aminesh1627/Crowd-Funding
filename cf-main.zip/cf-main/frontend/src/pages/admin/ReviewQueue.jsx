import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill, RiskBadge } from '@/components/Primitives';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Check, X, MessageSquare, FileText, ShieldCheck, ScanSearch,
} from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { toast } from 'sonner';

export const ReviewQueue = () => {
  const { t, fmtCurrency } = useI18n();
  const { reviewQueue, decideCampaign } = useStore();
  const [selected, setSelected] = useState(null);
  const [comment, setComment] = useState('');

  const decide = (decision) => {
    if (!selected) return;
    decideCampaign(selected.id, decision);
    toast.success(t('admin.decision_logged'));
    setSelected(null);
    setComment('');
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('admin.dashboard')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('admin.review_title')}</h1>
      </div>

      <div className="grid sm:grid-cols-4 gap-4">
        {['credit', 'risk', 'compliance', 'all'].map((s) => {
          const count = s === 'all' ? reviewQueue.length : reviewQueue.filter((r) => r.stage === s).length;
          return (
            <div key={s} className="rounded-xl p-5 bg-card border border-border">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{s}</div>
              <div className="font-serif-display text-3xl text-primary num-display mt-2">{count}</div>
            </div>
          );
        })}
      </div>

      <GlassCard>
        <SectionHeader kicker="Queue" title="All pending reviews" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Borrower</th>
                <th className="text-start py-3">{t('common.sector')}</th>
                <th className="text-end py-3">{t('common.amount')}</th>
                <th className="text-end py-3">Stage</th>
                <th className="text-end py-3">Score</th>
                <th className="text-end py-3">{t('admin.priority')}</th>
                <th className="text-end py-3">{t('admin.sla')}</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {reviewQueue.map((r) => (
                <tr key={r.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{r.id}</td>
                  <td className="py-3 font-medium">{r.borrower}</td>
                  <td className="py-3"><StatusPill tone="gold">{t(`sectors.${r.sector}`)}</StatusPill></td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(r.amount)}</td>
                  <td className="py-3 text-end"><StatusPill tone={r.stage === 'credit' ? 'info' : r.stage === 'risk' ? 'warning' : 'gold'}>{r.stage}</StatusPill></td>
                  <td className="py-3 text-end num-display">{r.score}</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={r.priority === 'high' ? 'danger' : r.priority === 'medium' ? 'warning' : 'neutral'}>
                      {t(`admin.${r.priority[0]}_priority`)}
                    </StatusPill>
                  </td>
                  <td className="py-3 text-end font-mono text-xs text-muted-foreground">{r.sla}</td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="outline" onClick={() => setSelected(r)}>{t('admin.decision')}</Button>
                  </td>
                </tr>
              ))}
              {reviewQueue.length === 0 && (
                <tr><td colSpan="9" className="py-12 text-center text-muted-foreground">All clear — no pending reviews.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="font-serif-display text-2xl text-primary">
                  {selected.id} · {selected.borrower}
                </DialogTitle>
              </DialogHeader>

              <div className="grid sm:grid-cols-4 gap-3 my-4">
                <Box label="Amount" value={fmtCurrency(selected.amount)} />
                <Box label="Sector" value={t(`sectors.${selected.sector}`)} />
                <Box label="Score" value={selected.score} />
                <Box label="Stage" value={selected.stage} />
              </div>

              <div className="grid sm:grid-cols-3 gap-2 mb-4">
                {[
                  { icon: FileText, l: 'Documents OK' },
                  { icon: ShieldCheck, l: 'KYC verified' },
                  { icon: ScanSearch, l: 'AML clear' },
                ].map((b, i) => {
                  const Icon = b.icon;
                  return (
                    <div key={i} className="flex items-center gap-2 p-3 rounded-lg bg-success/10 border border-success/20 text-success text-xs">
                      <Icon className="w-4 h-4" /> {b.l}
                    </div>
                  );
                })}
              </div>

              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('admin.comments')}</label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  placeholder="Add reviewer comments..."
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm"
                />
              </div>

              <div className="flex items-center justify-end gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => { toast.info('Returned for clarification'); setSelected(null); }}
                >
                  <MessageSquare className="me-1 w-4 h-4" /> {t('common.clarify')}
                </Button>
                <Button
                  variant="destructive"
                  data-testid={RAWAFID.reviewReject(selected.id)}
                  onClick={() => decide('reject')}
                >
                  <X className="me-1 w-4 h-4" /> {t('common.reject')}
                </Button>
                <Button
                  className="bg-success hover:bg-success/90 text-success-foreground"
                  data-testid={RAWAFID.reviewApprove(selected.id)}
                  onClick={() => decide('approve')}
                >
                  <Check className="me-1 w-4 h-4" /> {t('common.approve')}
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const Box = ({ label, value }) => (
  <div className="rounded-lg p-3 bg-muted/40">
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    <div className="font-serif-display text-base text-primary num-display mt-0.5">{value}</div>
  </div>
);

export default ReviewQueue;
