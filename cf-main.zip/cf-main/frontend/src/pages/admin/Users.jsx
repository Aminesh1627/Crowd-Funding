import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Search } from 'lucide-react';

export const Users = () => {
  const { t, fmtCurrency } = useI18n();
  const { users } = useStore();
  const [q, setQ] = useState('');

  const filtered = users.filter((u) =>
    u.name.toLowerCase().includes(q.toLowerCase()) ||
    u.id.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('admin.dashboard')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('admin.users_title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('admin.user_directory_sub')}</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <div className="rounded-xl p-5 bg-card border border-border">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('admin.total_users')}</div>
          <div className="font-serif-display text-3xl text-primary num-display mt-2">{users.length * 800}</div>
        </div>
        <div className="rounded-xl p-5 bg-card border border-border">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Investors</div>
          <div className="font-serif-display text-3xl text-primary num-display mt-2">{users.filter((u) => u.type === 'investor').length * 600}</div>
        </div>
        <div className="rounded-xl p-5 bg-card border border-border">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Borrowers</div>
          <div className="font-serif-display text-3xl text-primary num-display mt-2">{users.filter((u) => u.type === 'borrower').length * 80}</div>
        </div>
      </div>

      <GlassCard>
        <SectionHeader
          kicker="Directory"
          title="All users"
          action={
            <div className="relative">
              <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t('common.type_to_search')}
                className="h-9 w-64 ps-9 pe-3 rounded-full border border-input bg-background text-sm"
              />
            </div>
          }
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Name</th>
                <th className="text-start py-3">Type</th>
                <th className="text-start py-3">KYC</th>
                <th className="text-start py-3">{t('common.status')}</th>
                <th className="text-end py-3">Joined</th>
                <th className="text-end py-3">Volume</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs text-muted-foreground">{u.id}</td>
                  <td className="py-3 font-medium">{u.name}</td>
                  <td className="py-3 capitalize">{u.type}</td>
                  <td className="py-3">
                    <StatusPill tone={u.kyc === 'verified' ? 'success' : 'warning'}>{u.kyc}</StatusPill>
                  </td>
                  <td className="py-3">
                    <StatusPill tone={u.status === 'active' ? 'success' : 'info'}>{u.status}</StatusPill>
                  </td>
                  <td className="py-3 text-end text-xs text-muted-foreground">{u.joined}</td>
                  <td className="py-3 text-end num-display font-semibold">
                    {fmtCurrency(u.invested ?? u.raised ?? 0)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export default Users;
