import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Layers, Plus, Save, FlaskConical } from 'lucide-react';
import { scorecardRows } from '@/data/mockDataV2';
import { toast } from 'sonner';

const CATEGORIES = ['credit', 'risk', 'compliance', 'onboarding'];
const CAT_TONE = { credit: 'info', risk: 'warning', compliance: 'gold', onboarding: 'success' };

export const DecisionEngine = () => {
  const { t } = useI18n();
  const { decisionRules, updateDecisionRule, addDecisionRule } = useStore();
  const [cat, setCat] = useState('credit');
  const [edit, setEdit] = useState(null);
  const [draft, setDraft] = useState({ name: '', condition: '', threshold: '', weight: 0 });

  const filtered = decisionRules.filter((r) => r.category === cat);

  const simulatedScore = scorecardRows.reduce((s, r) => s + r.contribution, 0).toFixed(1);

  const openEdit = (rule) => {
    setEdit(rule);
    setDraft({ name: rule.name, condition: rule.condition, threshold: String(rule.threshold), weight: rule.weight });
  };

  const save = () => {
    if (edit) {
      updateDecisionRule(edit.id, {
        name: draft.name, condition: draft.condition,
        threshold: isNaN(Number(draft.threshold)) ? draft.threshold : Number(draft.threshold),
        weight: Number(draft.weight) || 0,
      });
    } else {
      addDecisionRule({
        category: cat, name: draft.name || 'New rule', condition: draft.condition || '—',
        threshold: isNaN(Number(draft.threshold)) ? draft.threshold : Number(draft.threshold),
        weight: Number(draft.weight) || 5,
      });
    }
    setEdit(null); setDraft({ name: '', condition: '', threshold: '', weight: 0 });
    toast.success(t('decision_engine.saved'));
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5" /> {t('nav.decision_engine')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('decision_engine.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('decision_engine.subtitle')}</p>
      </div>

      <div className="flex flex-wrap items-center gap-2 justify-between">
        <div className="inline-flex p-1 rounded-full bg-muted">
          {CATEGORIES.map((c) => (
            <button
              key={c} onClick={() => setCat(c)}
              data-testid={`engine-tab-${c}`}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                cat === c ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {t(`decision_engine.category_${c}`)}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => toast.info(`${t('decision_engine.simulate_score')}: ${simulatedScore}`)} data-testid="engine-simulate">
            <FlaskConical className="me-1 w-4 h-4" /> {t('decision_engine.simulate')}
          </Button>
          <Button size="sm" data-testid="engine-add-rule"
            onClick={() => { setEdit({ id: 'new' }); setDraft({ name: '', condition: '', threshold: '', weight: 5 }); }}>
            <Plus className="me-1 w-4 h-4" /> {t('decision_engine.add_rule')}
          </Button>
        </div>
      </div>

      <GlassCard>
        <SectionHeader kicker={t(`decision_engine.category_${cat}`)} title="Active rules" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">{t('decision_engine.rule')}</th>
                <th className="text-start py-3">{t('decision_engine.condition')}</th>
                <th className="text-end py-3">{t('decision_engine.threshold')}</th>
                <th className="text-end py-3">{t('decision_engine.weight')}</th>
                <th className="text-center py-3">{t('decision_engine.active')}</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{r.id}</td>
                  <td className="py-3 font-medium">{r.name}</td>
                  <td className="py-3 font-mono text-xs text-muted-foreground">{r.condition}</td>
                  <td className="py-3 text-end num-display">{String(r.threshold)}</td>
                  <td className="py-3 text-end num-display">{r.weight}%</td>
                  <td className="py-3">
                    <div className="flex justify-center">
                      <Switch checked={r.active} onCheckedChange={(v) => updateDecisionRule(r.id, { active: v })} />
                    </div>
                  </td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="ghost" data-testid={`engine-edit-${r.id}`} onClick={() => openEdit(r)}>
                      {t('common.edit')}
                    </Button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan="7" className="py-10 text-center text-muted-foreground">No rules in this category yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <GlassCard>
        <SectionHeader kicker="Composite" title="Sample scorecard simulation" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b">
                <th className="text-start py-2">Factor</th>
                <th className="text-end py-2">Weight</th>
                <th className="text-end py-2">Score</th>
                <th className="text-end py-2">Contribution</th>
              </tr>
            </thead>
            <tbody>
              {scorecardRows.map((row, i) => (
                <tr key={i} className="border-b border-border/40">
                  <td className="py-2">{row.factor}</td>
                  <td className="py-2 text-end num-display">{row.weight}%</td>
                  <td className="py-2 text-end num-display">{row.score}</td>
                  <td className="py-2 text-end num-display font-semibold">{row.contribution.toFixed(1)}</td>
                </tr>
              ))}
              <tr className="font-semibold">
                <td colSpan={3} className="py-2 text-end">{t('decision_engine.simulate_score')}</td>
                <td className="py-2 text-end num-display text-accent text-lg">{simulatedScore}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </GlassCard>

      <Dialog open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">
              {edit?.id === 'new' ? t('decision_engine.add_rule') : t('decision_engine.edit_rule')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <FormField label={t('decision_engine.rule')} value={draft.name} onChange={(v) => setDraft((d) => ({ ...d, name: v }))} />
            <FormField label={t('decision_engine.condition')} value={draft.condition} onChange={(v) => setDraft((d) => ({ ...d, condition: v }))} />
            <FormField label={t('decision_engine.threshold')} value={draft.threshold} onChange={(v) => setDraft((d) => ({ ...d, threshold: v }))} />
            <FormField label={`${t('decision_engine.weight')} (%)`} value={draft.weight} onChange={(v) => setDraft((d) => ({ ...d, weight: v }))} type="number" />
            <Button onClick={save} className="w-full bg-primary hover:bg-primary/90 rounded-full" data-testid="engine-save-rule">
              <Save className="me-1 w-4 h-4" /> {t('decision_engine.save_rule')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const FormField = ({ label, value, onChange, type = 'text' }) => (
  <div>
    <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{label}</label>
    <input
      type={type} value={value} onChange={(e) => onChange(e.target.value)}
      className="w-full h-11 px-3 rounded-lg border border-input bg-background text-sm"
    />
  </div>
);

export default DecisionEngine;
