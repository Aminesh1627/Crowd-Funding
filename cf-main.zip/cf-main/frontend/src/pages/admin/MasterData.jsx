import React from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Switch } from '@/components/ui/switch';
import { ScrollText, FileText, Globe, Plus, CheckCircle2 } from 'lucide-react';

export const MasterLoanTypes = () => {
  const { t, fmtCurrency } = useI18n();
  const { loanTypes, setLoanTypes } = useStore();
  return (
    <div className="space-y-6">
      <Header icon={ScrollText} kicker="nav.group_master" title="master.loan_title" sub="master.loan_sub" />
      <GlassCard>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">{t('master.loan_code')}</th>
                <th className="text-start py-3">{t('master.loan_name')}</th>
                <th className="text-end py-3">{t('master.min_amount')}</th>
                <th className="text-end py-3">{t('master.max_amount')}</th>
                <th className="text-end py-3">{t('master.min_tenure')}</th>
                <th className="text-end py-3">{t('master.max_tenure')}</th>
                <th className="text-end py-3">{t('master.min_rate')}</th>
                <th className="text-end py-3">{t('master.max_rate')}</th>
                <th className="text-center py-3">{t('common.enabled')}</th>
              </tr>
            </thead>
            <tbody>
              {loanTypes.map((l) => (
                <tr key={l.code} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{l.code}</td>
                  <td className="py-3 font-medium">{l.name}</td>
                  <td className="py-3 text-end num-display">{fmtCurrency(l.minAmount)}</td>
                  <td className="py-3 text-end num-display">{fmtCurrency(l.maxAmount)}</td>
                  <td className="py-3 text-end num-display">{l.minTenure}m</td>
                  <td className="py-3 text-end num-display">{l.maxTenure}m</td>
                  <td className="py-3 text-end num-display">{l.minRate}%</td>
                  <td className="py-3 text-end num-display">{l.maxRate}%</td>
                  <td className="py-3"><div className="flex justify-center"><Switch checked={l.enabled} onCheckedChange={(v) => setLoanTypes((prev) => prev.map((x) => x.code === l.code ? { ...x, enabled: v } : x))} /></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export const MasterDocTypes = () => {
  const { t } = useI18n();
  const { docTypes } = useStore();
  return (
    <div className="space-y-6">
      <Header icon={FileText} kicker="nav.group_master" title="master.doc_title" sub="master.doc_sub" />
      <GlassCard>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">Code</th>
                <th className="text-start py-3">Name</th>
                <th className="text-start py-3">{t('master.stage')}</th>
                <th className="text-start py-3">{t('master.party')}</th>
                <th className="text-center py-3">{t('master.mandatory')}</th>
              </tr>
            </thead>
            <tbody>
              {docTypes.map((d) => (
                <tr key={d.code} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{d.code}</td>
                  <td className="py-3 font-medium">{d.name}</td>
                  <td className="py-3"><StatusPill tone="info">{d.stage}</StatusPill></td>
                  <td className="py-3">{d.party}</td>
                  <td className="py-3 text-center">
                    <StatusPill tone={d.mandatory ? 'gold' : 'neutral'}>{d.mandatory ? t('master.mandatory') : t('master.optional')}</StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export const MasterLanguages = () => {
  const { t } = useI18n();
  const { languageSettings, setLanguageSettings } = useStore();
  return (
    <div className="space-y-6">
      <Header icon={Globe} kicker="nav.group_master" title="master.lang_title" sub="master.lang_sub" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {languageSettings.map((l) => (
          <GlassCard key={l.code}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-serif-display text-2xl text-primary">{l.name}</div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{l.code}</div>
              </div>
              {l.primary && <StatusPill tone="gold"><CheckCircle2 className="w-3 h-3" /> Primary</StatusPill>}
            </div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{t('master.coverage')}</div>
            <div className="h-2 rounded-full bg-muted overflow-hidden mb-2">
              <div className="h-full bg-gradient-gold" style={{ width: `${l.coverage}%` }} />
            </div>
            <div className="text-sm num-display font-semibold">{l.coverage}%</div>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{t('common.enabled')}</span>
              <Switch checked={l.enabled} onCheckedChange={(v) => setLanguageSettings((prev) => prev.map((x) => x.code === l.code ? { ...x, enabled: v } : x))} />
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

const Header = ({ icon: Icon, kicker, title, sub }) => {
  const { t } = useI18n();
  return (
    <div>
      <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
        <Icon className="w-3.5 h-3.5" /> {t(kicker)}
      </div>
      <h1 className="font-serif-display text-3xl text-primary">{t(title)}</h1>
      <p className="text-sm text-muted-foreground mt-1">{t(sub)}</p>
    </div>
  );
};
