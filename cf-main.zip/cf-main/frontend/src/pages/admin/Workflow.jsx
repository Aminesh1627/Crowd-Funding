import React from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, KpiTile } from '@/components/Primitives';
import { LineTrendChart } from '@/components/Charts';
import { seedWorkflowStages } from '@/data/mockDataV2';
import { GitBranch, Clock, Activity, ArrowRight } from 'lucide-react';

const TREND = [
  { m: 'Jun', flags: 18, resolved: 17 }, { m: 'Jul', flags: 22, resolved: 21 },
  { m: 'Aug', flags: 19, resolved: 20 }, { m: 'Sep', flags: 24, resolved: 22 },
  { m: 'Oct', flags: 27, resolved: 26 }, { m: 'Nov', flags: 31, resolved: 30 },
];

export const Workflow = () => {
  const { t } = useI18n();
  const stages = seedWorkflowStages();

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <GitBranch className="w-3.5 h-3.5" /> {t('nav.workflow')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('workflow.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('workflow.subtitle')}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiTile label={t('workflow.throughput')} value="42" icon={Activity} accent />
        <KpiTile label={t('workflow.avg_dwell')} value="3.4 days" icon={Clock} />
        <KpiTile label="Total in pipeline" value={stages.reduce((s, x) => s + x.count, 0)} icon={GitBranch} />
        <KpiTile label="Approval rate" value="78%" delta={{ value: 4.2, label: 'QoQ' }} icon={Activity} />
      </div>

      <GlassCard>
        <SectionHeader kicker="Pipeline" title="Stage flow" />
        <div className="overflow-x-auto py-4">
          <div className="flex items-center gap-2 min-w-max">
            {stages.map((s, i) => (
              <React.Fragment key={s.key}>
                <div className="flex-1 min-w-[140px] rounded-xl p-4 bg-card border border-border text-center hover:shadow-card-elegant transition-shadow">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</div>
                  <div className="font-serif-display text-3xl text-primary num-display mt-1">{s.count}</div>
                  <div className="text-[10px] text-muted-foreground mt-1">{t('workflow.avg_dwell')}: {s.avgDwell}</div>
                </div>
                {i < stages.length - 1 && <ArrowRight className="w-4 h-4 text-accent shrink-0 rtl-flip" />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </GlassCard>

      <GlassCard>
        <SectionHeader kicker="Trend" title="Flags vs. resolutions (6 months)" />
        <LineTrendChart data={TREND} />
      </GlassCard>
    </div>
  );
};

export default Workflow;
