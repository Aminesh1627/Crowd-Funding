import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, KpiTile, SectionHeader, StatusPill } from '@/components/Primitives';
import {
  FundingComboChart, PieAllocChart, HorizontalBarChart,
} from '@/components/Charts';
import { monthlyFunding, sectorExposure, onboardingFunnel, industryAlloc } from '@/data/mockData';
import {
  Banknote, Users, FolderKanban, Clock, AlertTriangle, TrendingUp, ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export const AdminDashboard = () => {
  const { t, fmtCurrency, fmtNum } = useI18n();
  const { reviewQueue, users, campaigns } = useStore();
  const navigate = useNavigate();

  const aum = 18420000;
  const activeCampaigns = campaigns.filter((c) => c.stage === 'funding').length;
  const pendingReviews = reviewQueue.length;
  const disbursedMonth = 1485000;
  const defaultRate = 0.6;

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('roles.admin')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('admin.dashboard')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('admin.sub')}</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiTile label={t('admin.kpi_aum')} value={fmtCurrency(aum)} delta={{ value: 12.4, label: 'YTD' }} icon={Banknote} accent />
        <KpiTile label={t('admin.kpi_active_campaigns')} value={activeCampaigns} icon={FolderKanban} />
        <KpiTile label={t('admin.kpi_users')} value={fmtNum(users.length * 800)} delta={{ value: 6.1, label: 'MoM' }} icon={Users} />
        <KpiTile label={t('admin.kpi_pending')} value={pendingReviews} icon={Clock} />
        <KpiTile label={t('admin.kpi_disbursed')} value={fmtCurrency(disbursedMonth)} icon={TrendingUp} />
        <KpiTile label={t('admin.kpi_defaults')} value={`${defaultRate}%`} delta={{ value: -0.2, label: 'QoQ' }} icon={AlertTriangle} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader
            kicker={t('common.overview')}
            title={t('admin.monthly_funding')}
            action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/review')}>{t('common.view_all')} →</Button>}
          />
          <FundingComboChart data={monthlyFunding} />
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker="Mix" title={t('admin.sector_split')} />
          <PieAllocChart data={industryAlloc} />
        </GlassCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard>
          <SectionHeader kicker="Funnel" title={t('admin.onboarding_funnel')} />
          <HorizontalBarChart data={onboardingFunnel} dataKey="value" />
        </GlassCard>
        <GlassCard className="lg:col-span-2">
          <SectionHeader
            kicker="Queue"
            title={t('admin.review_title')}
            action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/review')}>Open <ArrowRight className="ms-1 w-3.5 h-3.5 rtl-flip" /></Button>}
          />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                  <th className="text-start py-2.5">ID</th>
                  <th className="text-start py-2.5">Borrower</th>
                  <th className="text-end py-2.5">{t('common.amount')}</th>
                  <th className="text-end py-2.5">Stage</th>
                  <th className="text-end py-2.5">{t('admin.priority')}</th>
                  <th className="text-end py-2.5">{t('admin.sla')}</th>
                </tr>
              </thead>
              <tbody>
                {reviewQueue.slice(0, 5).map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-b-0">
                    <td className="py-2.5 font-mono text-xs">{r.id}</td>
                    <td className="py-2.5 font-medium text-sm">{r.borrower}</td>
                    <td className="py-2.5 text-end num-display">{fmtCurrency(r.amount)}</td>
                    <td className="py-2.5 text-end">
                      <StatusPill tone={r.stage === 'credit' ? 'info' : r.stage === 'risk' ? 'warning' : 'gold'}>{r.stage}</StatusPill>
                    </td>
                    <td className="py-2.5 text-end">
                      <StatusPill tone={r.priority === 'high' ? 'danger' : r.priority === 'medium' ? 'warning' : 'neutral'}>
                        {t(`admin.${r.priority[0]}_priority`)}
                      </StatusPill>
                    </td>
                    <td className="py-2.5 text-end font-mono text-xs text-muted-foreground">{r.sla}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
