import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Search, Plus, Users, KeyRound } from 'lucide-react';

const ROLE_TONE = { Admin: 'gold', Officer: 'info', Investor: 'success', Borrower: 'warning' };

export const ManageUsers = () => {
  const { t, fmtCurrency } = useI18n();
  const { users } = useStore();
  const [q, setQ] = useState('');
  const filtered = users.filter((u) => u.name.toLowerCase().includes(q.toLowerCase()) || u.id.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('nav.group_admin')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{t('admin_mgmt.users_title')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('admin_mgmt.users_sub')}</p>
        </div>
        <Button data-testid="manage-users-new"><Plus className="me-1 w-4 h-4" /> {t('admin_mgmt.new_user')}</Button>
      </div>

      <GlassCard>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="text-sm text-muted-foreground">{filtered.length} users</div>
          <div className="relative">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={q} onChange={(e) => setQ(e.target.value)}
              placeholder={t('common.type_to_search')}
              className="h-9 w-64 ps-9 pe-3 rounded-full border border-input bg-background text-sm"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Name</th>
                <th className="text-start py-3">Type</th>
                <th className="text-start py-3">KYC</th>
                <th className="text-start py-3">{t('common.status')}</th>
                <th className="text-end py-3">Joined</th>
                <th className="text-end py-3">Volume</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs text-muted-foreground">{u.id}</td>
                  <td className="py-3 font-medium">{u.name}</td>
                  <td className="py-3 capitalize">{u.type}</td>
                  <td className="py-3"><StatusPill tone={u.kyc === 'verified' ? 'success' : 'warning'}>{u.kyc}</StatusPill></td>
                  <td className="py-3"><StatusPill tone={u.status === 'active' ? 'success' : 'info'}>{u.status}</StatusPill></td>
                  <td className="py-3 text-end text-xs text-muted-foreground">{u.joined}</td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(u.invested ?? u.raised ?? 0)}</td>
                  <td className="py-3 text-end">
                    <Button size="sm" variant="ghost">{t('common.edit')}</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export const ManageRoles = () => {
  const { t } = useI18n();
  const { adminRoles } = useStore();
  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">{t('nav.group_admin')}</div>
          <h1 className="font-serif-display text-3xl text-primary">{t('admin_mgmt.roles_title')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('admin_mgmt.roles_sub')}</p>
        </div>
        <Button><Plus className="me-1 w-4 h-4" /> {t('admin_mgmt.new_role')}</Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {adminRoles.map((r) => (
          <GlassCard key={r.id} className="hover-lift">
            <div className="flex items-start justify-between mb-3">
              <div className="w-11 h-11 rounded-lg bg-gradient-gold grid place-items-center shadow-gold">
                <KeyRound className="w-5 h-5 text-primary" />
              </div>
              <StatusPill tone="gold">{r.id}</StatusPill>
            </div>
            <div className="font-serif-display text-lg text-primary">{r.name}</div>
            <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
              <Users className="w-3 h-3" /> {r.members} {t('admin_mgmt.members')}
            </div>
            <div className="divider-gold my-3" />
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">{t('admin_mgmt.permissions')}</div>
            <ul className="space-y-1">
              {r.permissions.map((p, i) => (
                <li key={i} className="text-sm flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-accent" /> {p}
                </li>
              ))}
            </ul>
            <Button size="sm" variant="outline" className="mt-4 w-full">{t('common.edit')}</Button>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

export const ManageGroups = () => {
  const { t } = useI18n();
  const { adminGroups } = useStore();
  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">{t('nav.group_admin')}</div>
          <h1 className="font-serif-display text-3xl text-primary">{t('admin_mgmt.groups_title')}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('admin_mgmt.groups_sub')}</p>
        </div>
        <Button><Plus className="me-1 w-4 h-4" /> {t('admin_mgmt.new_group')}</Button>
      </div>
      <GlassCard>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Name</th>
                <th className="text-start py-3">Type</th>
                <th className="text-end py-3">{t('admin_mgmt.members')}</th>
                <th className="text-end py-3">Region</th>
                <th className="text-end py-3">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {adminGroups.map((g) => (
                <tr key={g.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{g.id}</td>
                  <td className="py-3 font-medium">{g.name}</td>
                  <td className="py-3 capitalize"><StatusPill tone="info">{g.type}</StatusPill></td>
                  <td className="py-3 text-end num-display">{g.members}</td>
                  <td className="py-3 text-end text-muted-foreground">{g.region}</td>
                  <td className="py-3 text-end"><Button size="sm" variant="ghost">{t('common.edit')}</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};
