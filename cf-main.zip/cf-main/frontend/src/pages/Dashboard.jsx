import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { InvestorDashboard } from '@/pages/investor/Dashboard';
import { BorrowerDashboard } from '@/pages/borrower/Dashboard';
import { AdminDashboard } from '@/pages/admin/Dashboard';
import { RegulatorDashboard } from '@/pages/regulator/Dashboard';

export const Dashboard = () => {
  const { role } = useAuth();
  if (role === 'borrower') return <BorrowerDashboard />;
  if (role === 'admin') return <AdminDashboard />;
  if (role === 'regulator') return <RegulatorDashboard />;
  return <InvestorDashboard />;
};

export default Dashboard;
