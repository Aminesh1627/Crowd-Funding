import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useAuth } from '@/context/AuthContext';
import { Logo } from '@/components/Logo';
import { LangToggle } from '@/components/LangToggle';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  CheckCircle2, UserCircle2, Brain, IdCard, ScanSearch, Wallet,
  PartyPopper, ArrowRight, ArrowLeft, Loader2, ShieldCheck,
} from 'lucide-react';
import { GlassCard, StatusPill } from '@/components/Primitives';
import { RAWAFID } from '@/constants/testIds';
import { toast } from 'sonner';

const STEPS = [
  { key: 'personal', icon: UserCircle2, label: 'onboarding.step1' },
  { key: 'suitability', icon: Brain, label: 'onboarding.step2' },
  { key: 'kyc', icon: IdCard, label: 'onboarding.step3' },
  { key: 'aml', icon: ScanSearch, label: 'onboarding.step4' },
  { key: 'wallet', icon: Wallet, label: 'onboarding.step5' },
  { key: 'done', icon: PartyPopper, label: 'onboarding.step6' },
];

const categorize = (suit) => {
  // simple mock categorization
  const score = (suit.q1 || 0) + (suit.q2 || 0) + (suit.q3 || 0) + (suit.q4 || 0);
  if (score >= 12) return 'inst';
  if (score >= 9) return 'acc';
  if (score >= 6) return 'soph';
  return 'retail';
};

export const Onboarding = () => {
  const { t } = useI18n();
  const { completeInvestorOnboarding, user } = useAuth();
  const navigate = useNavigate();
  const [idx, setIdx] = useState(0);
  const [form, setForm] = useState({
    name: user?.name || 'Omar Al-Rashdi',
    mobile: '+968 ',
    email: user?.email || '',
    civilId: '',
    suit: {},
    agreed: { terms: false, risk: false, data: false },
  });
  const [amlRunning, setAmlRunning] = useState(false);
  const [amlDone, setAmlDone] = useState(false);

  const Step = STEPS[idx];
  const isFinal = idx === STEPS.length - 1;
  const progress = ((idx + 1) / STEPS.length) * 100;
  const allAgreed = form.agreed.terms && form.agreed.risk && form.agreed.data;

  // Trigger fake AML scan when reaching that step
  useEffect(() => {
    if (STEPS[idx].key === 'aml' && !amlDone) {
      setAmlRunning(true);
      const tid = setTimeout(() => {
        setAmlRunning(false);
        setAmlDone(true);
      }, 1800);
      return () => clearTimeout(tid);
    }
  }, [idx, amlDone]);

  const canProceed = () => {
    const k = STEPS[idx].key;
    if (k === 'personal') return form.name.trim() && form.mobile.trim();
    if (k === 'suitability') return [1, 2, 3, 4].every((q) => form.suit[`q${q}`]);
    if (k === 'kyc') return true;
    if (k === 'aml') return amlDone;
    if (k === 'wallet') return allAgreed;
    return true;
  };

  const next = () => {
    if (!canProceed()) return;
    if (idx === STEPS.length - 2) {
      const cat = categorize(form.suit);
      completeInvestorOnboarding({ category: cat });
      toast.success(t('investor.invest_confirm'));
    }
    setIdx((i) => Math.min(STEPS.length - 1, i + 1));
  };

  const back = () => setIdx((i) => Math.max(0, i - 1));

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <header className="px-6 lg:px-12 py-5 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Logo size="md" />
          <a href="/" className="hidden sm:inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
            <span aria-hidden>←</span> {t('common.back_to_home')}
          </a>
        </div>
        <LangToggle />
      </header>

      <div className="max-w-4xl mx-auto px-6 lg:px-12 py-8">
        {/* Title + progress */}
        <div className="text-center mb-10">
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
            {t('onboarding.title')}
          </div>
          <h1 className="font-serif-display text-4xl text-primary">{t('onboarding.subtitle')}</h1>
        </div>

        {/* Stepper */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
              {t('common.step')} {idx + 1} {t('common.of')} {STEPS.length}
            </span>
            <span className="text-xs text-muted-foreground">{t('onboarding.progress')}</span>
          </div>
          <Progress value={progress} className="h-1.5 bg-muted [&>div]:bg-gradient-gold" />
          <div className="mt-6 grid grid-cols-6 gap-2">
            {STEPS.map((s, i) => {
              const Icon = s.icon;
              const active = i === idx;
              const done = i < idx;
              return (
                <div key={s.key} className="flex flex-col items-center gap-1.5">
                  <div className={`w-10 h-10 rounded-full grid place-items-center transition-all ${
                    done
                      ? 'bg-success text-success-foreground'
                      : active
                        ? 'bg-gradient-gold text-primary shadow-gold ring-4 ring-accent/20'
                        : 'bg-muted text-muted-foreground'
                  }`}>
                    {done ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                  </div>
                  <span className={`text-[10px] uppercase tracking-wider text-center leading-tight ${
                    active ? 'text-primary font-semibold' : 'text-muted-foreground'
                  }`}>
                    {t(s.label)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step content */}
        <GlassCard className="p-8 lg:p-10">
          {Step.key === 'personal' && (
            <div>
              <h3 className="font-serif-display text-2xl text-primary mb-1">{t('onboarding.step1')}</h3>
              <p className="text-muted-foreground text-sm mb-7">{t('onboarding.personal_intro')}</p>
              <div className="grid sm:grid-cols-2 gap-5">
                <Field label={t('common.name')} value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} />
                <Field label={t('common.mobile')} value={form.mobile} onChange={(v) => setForm((f) => ({ ...f, mobile: v }))} />
                <Field label={t('common.email')} value={form.email} onChange={(v) => setForm((f) => ({ ...f, email: v }))} />
                <Field label={t('common.civil_id')} value={form.civilId} onChange={(v) => setForm((f) => ({ ...f, civilId: v }))} />
              </div>
            </div>
          )}

          {Step.key === 'suitability' && (
            <div>
              <h3 className="font-serif-display text-2xl text-primary mb-1">{t('onboarding.step2')}</h3>
              <p className="text-muted-foreground text-sm mb-7">{t('onboarding.suit_intro')}</p>
              <div className="space-y-6">
                <SuitQ qKey="q1" question={t('onboarding.suit_q1')} options={[t('onboarding.suit_q1_a'), t('onboarding.suit_q1_b'), t('onboarding.suit_q1_c'), t('onboarding.suit_q1_d')]} form={form} setForm={setForm} />
                <SuitQ qKey="q2" question={t('onboarding.suit_q2')} options={[t('onboarding.suit_q2_a'), t('onboarding.suit_q2_b'), t('onboarding.suit_q2_c'), t('onboarding.suit_q2_d')]} form={form} setForm={setForm} />
                <SuitQ qKey="q3" question={t('onboarding.suit_q3')} options={[t('onboarding.suit_q3_a'), t('onboarding.suit_q3_b'), t('onboarding.suit_q3_c')]} form={form} setForm={setForm} />
                <SuitQ qKey="q4" question={t('onboarding.suit_q4')} options={[t('onboarding.suit_q4_a'), t('onboarding.suit_q4_b'), t('onboarding.suit_q4_c'), t('onboarding.suit_q4_d')]} form={form} setForm={setForm} />
              </div>
            </div>
          )}

          {Step.key === 'kyc' && (
            <div>
              <h3 className="font-serif-display text-2xl text-primary mb-1">{t('onboarding.step3')}</h3>
              <p className="text-muted-foreground text-sm mb-7">{t('onboarding.kyc_intro')}</p>
              <div className="grid sm:grid-cols-3 gap-4">
                {['kyc_civil', 'kyc_passport', 'kyc_proof'].map((k) => (
                  <div key={k} className="p-5 rounded-xl border-2 border-dashed border-border bg-muted/30 text-center">
                    <IdCard className="w-7 h-7 mx-auto text-accent mb-2" />
                    <div className="text-sm font-medium text-foreground">{t(`onboarding.${k}`)}</div>
                    <StatusPill tone="success" >
                      <CheckCircle2 className="w-3 h-3" /> {t('common.verified')}
                    </StatusPill>
                  </div>
                ))}
              </div>
            </div>
          )}

          {Step.key === 'aml' && (
            <div>
              <h3 className="font-serif-display text-2xl text-primary mb-1">{t('onboarding.step4')}</h3>
              <p className="text-muted-foreground text-sm mb-7">{t('onboarding.aml_intro')}</p>
              <div className="rounded-xl border border-border p-8 bg-gradient-subtle text-center">
                {amlRunning && (
                  <>
                    <Loader2 className="w-10 h-10 mx-auto text-accent animate-spin mb-4" />
                    <div className="font-serif-display text-xl text-primary">{t('onboarding.aml_running')}</div>
                    <div className="mt-2 text-xs text-muted-foreground">Sanctions · PEP · Adverse Media · Watchlists</div>
                  </>
                )}
                {amlDone && (
                  <>
                    <CheckCircle2 className="w-12 h-12 mx-auto text-success mb-4" />
                    <div className="font-serif-display text-xl text-primary">{t('onboarding.aml_clear')}</div>
                    <div className="mt-4 inline-flex flex-wrap gap-2 justify-center">
                      {['Sanctions', 'PEP', 'Adverse Media', 'Interpol', 'OFAC'].map((s) => (
                        <StatusPill key={s} tone="success"><CheckCircle2 className="w-3 h-3" /> {s}</StatusPill>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {Step.key === 'wallet' && (
            <div>
              <h3 className="font-serif-display text-2xl text-primary mb-1">{t('onboarding.step5')}</h3>
              <p className="text-muted-foreground text-sm mb-7">{t('onboarding.wallet_intro')}</p>
              <div className="space-y-3">
                {['terms', 'risk', 'data'].map((k) => (
                  <label key={k} data-testid={`onboarding-agree-${k}-label`} className="flex items-start gap-3 p-4 rounded-lg border border-border hover:bg-muted/40 cursor-pointer">
                    <input
                      type="checkbox"
                      data-testid={`onboarding-agree-${k}`}
                      checked={form.agreed[k]}
                      onChange={(e) => setForm((f) => ({ ...f, agreed: { ...f.agreed, [k]: e.target.checked } }))}
                      className="mt-1"
                    />
                    <div className="text-sm">{t(`onboarding.agree_${k}`)}</div>
                  </label>
                ))}
              </div>
              <div className="mt-5 p-4 rounded-lg bg-accent/10 border border-accent/30 flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-accent mt-0.5" />
                <p className="text-xs text-foreground/80 leading-relaxed">
                  All capital is held in a regulated escrow account and ring-fenced from the platform.
                </p>
              </div>
            </div>
          )}

          {Step.key === 'done' && (
            <div className="text-center py-6">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-gold grid place-items-center shadow-gold mb-6">
                <PartyPopper className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-serif-display text-3xl text-primary">{t('onboarding.finish_title')}</h3>
              <p className="mt-3 text-muted-foreground max-w-md mx-auto">{t('onboarding.finish_sub')}</p>
              <div className="mt-6 inline-flex items-center gap-3 px-5 py-3 rounded-full bg-accent/10 border border-accent/30">
                <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{t('onboarding.assigned_category')}</span>
                <span className="font-serif-display text-lg text-primary">{t(`onboarding.category_${categorize(form.suit)}`)}</span>
              </div>
              <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
                <Button
                  data-testid={RAWAFID.onboardingFinish}
                  onClick={() => navigate('/app/marketplace')}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full h-11 px-6 font-semibold shadow-elegant"
                >
                  {t('common.go_to_marketplace')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate('/app/dashboard')}
                  className="rounded-full h-11 px-6"
                >
                  {t('common.go_to_dashboard')}
                </Button>
              </div>
            </div>
          )}

          {/* Footer nav */}
          {!isFinal && (
            <div className="flex items-center justify-between mt-10 pt-6 border-t border-border">
              <Button
                variant="ghost"
                onClick={back}
                data-testid={RAWAFID.onboardingBack}
                disabled={idx === 0}
                className="rounded-full"
              >
                <ArrowLeft className="me-1 w-4 h-4 rtl-flip" /> {t('common.back')}
              </Button>
              <Button
                onClick={next}
                data-testid={RAWAFID.onboardingNext}
                disabled={!canProceed()}
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full h-11 px-6 font-semibold"
              >
                {t('common.next')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
              </Button>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
};

const Field = ({ label, value, onChange }) => (
  <div>
    <label className="text-xs uppercase tracking-[0.16em] text-muted-foreground font-medium block mb-2">{label}</label>
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full h-11 px-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent/40"
    />
  </div>
);

const SuitQ = ({ qKey, question, options, form, setForm }) => (
  <div data-testid={`suit-${qKey}`}>
    <div className="text-sm font-medium text-foreground mb-3">{question}</div>
    <div className="grid sm:grid-cols-2 gap-2">
      {options.map((o, i) => {
        const value = i + 1;
        const active = form.suit[qKey] === value;
        return (
          <button
            type="button"
            key={i}
            data-testid={`suit-${qKey}-opt-${value}`}
            onClick={() => setForm((f) => ({ ...f, suit: { ...f.suit, [qKey]: value } }))}
            className={`text-start px-4 py-3 rounded-lg border text-sm transition-all ${
              active
                ? 'border-accent bg-accent/10 text-foreground font-semibold ring-1 ring-accent/40'
                : 'border-border bg-card hover:border-accent/50 hover:bg-muted/40'
            }`}
          >
            {o}
          </button>
        );
      })}
    </div>
  </div>
);

export default Onboarding;
