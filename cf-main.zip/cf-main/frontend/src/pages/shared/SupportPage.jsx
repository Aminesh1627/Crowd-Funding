import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { LifeBuoy, Send, MessageSquare, Plus } from 'lucide-react';
import { toast } from 'sonner';

const CATEGORIES = ['cat_account', 'cat_kyc', 'cat_wallet', 'cat_investment', 'cat_campaign', 'cat_repayment', 'cat_other'];
const STATUS_TONE = { open: 'warning', reviewing: 'info', resolved: 'success', closed: 'neutral', escalated: 'danger' };

export const SupportPage = () => {
  const { t } = useI18n();
  const { tickets, submitTicket } = useStore();
  const [tab, setTab] = useState('ticket');
  const [form, setForm] = useState({ subject: '', category: 'cat_account', message: '' });
  const [chat, setChat] = useState([
    { id: 1, who: 'agent', text: t('support.auto_reply'), at: 'just now' },
  ]);
  const [draft, setDraft] = useState('');

  const submit = (e) => {
    e?.preventDefault?.();
    if (!form.subject.trim() || !form.message.trim()) {
      toast.error('Please complete both subject and message.'); return;
    }
    const id = submitTicket({ subject: form.subject, category: form.category });
    toast.success(t('support.ticket_created').replace('{{ref}}', id));
    setForm({ subject: '', category: 'cat_account', message: '' });
  };

  const sendChat = (e) => {
    e?.preventDefault?.();
    if (!draft.trim()) return;
    const userMsg = { id: Date.now(), who: 'me', text: draft.trim(), at: 'now' };
    setChat((prev) => [...prev, userMsg]);
    setDraft('');
    setTimeout(() => {
      setChat((prev) => [...prev, {
        id: Date.now() + 1, who: 'agent', at: 'just now',
        text: `${t('support.reply_team')}: Thanks for the details — a specialist is on it. Reference TKT-${Math.floor(1000 + Math.random() * 9000)}.`,
      }]);
    }, 700);
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1 flex items-center gap-1.5">
          <LifeBuoy className="w-3.5 h-3.5" /> {t('nav.support')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('support.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('support.subtitle')}</p>
      </div>

      <div className="inline-flex p-1 rounded-full bg-muted">
        {[
          { k: 'ticket', l: 'support.new_ticket' },
          { k: 'chat', l: 'support.live_chat' },
        ].map((x) => (
          <button
            key={x.k}
            data-testid={`support-tab-${x.k}`}
            onClick={() => setTab(x.k)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              tab === x.k ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {t(x.l)}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {tab === 'ticket' ? (
          <GlassCard className="lg:col-span-2">
            <SectionHeader kicker="New" title={t('support.new_ticket')} />
            <form onSubmit={submit} className="space-y-4">
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('common.subject')}</label>
                <input
                  type="text" data-testid="support-subject"
                  value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))}
                  className="w-full h-11 px-3 rounded-lg border border-input bg-background"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('common.category')}</label>
                <select
                  data-testid="support-category"
                  value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="w-full h-11 px-3 rounded-lg border border-input bg-background"
                >
                  {CATEGORIES.map((c) => <option key={c} value={c}>{t(`support.${c}`)}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('common.message')}</label>
                <textarea
                  data-testid="support-message"
                  value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  rows={5}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background"
                />
              </div>
              <Button type="submit" data-testid="support-submit" className="bg-primary hover:bg-primary/90 rounded-full">
                <Send className="me-1 w-4 h-4" /> {t('common.submit_request')}
              </Button>
            </form>
          </GlassCard>
        ) : (
          <GlassCard className="lg:col-span-2">
            <SectionHeader kicker="Live" title={t('support.live_chat')} />
            <div className="rounded-xl border border-border bg-muted/30 h-[440px] flex flex-col">
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chat.map((m) => (
                  <div key={m.id} className={`flex ${m.who === 'me' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm ${
                      m.who === 'me'
                        ? 'bg-primary text-primary-foreground rounded-tr-sm'
                        : 'bg-card border border-border text-foreground rounded-tl-sm'
                    }`}>
                      {m.who === 'agent' && <div className="text-[10px] uppercase tracking-wider text-accent mb-1">{t('support.reply_team')}</div>}
                      <div>{m.text}</div>
                      <div className={`text-[10px] mt-1.5 ${m.who === 'me' ? 'text-white/60' : 'text-muted-foreground'}`}>{m.at}</div>
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={sendChat} className="border-t border-border p-3 flex items-center gap-2">
                <input
                  type="text" value={draft} onChange={(e) => setDraft(e.target.value)}
                  placeholder={t('support.chat_placeholder')}
                  data-testid="support-chat-input"
                  className="flex-1 h-10 px-3 rounded-full border border-input bg-background text-sm"
                />
                <Button type="submit" data-testid="support-chat-send" size="icon" className="rounded-full bg-primary hover:bg-primary/90">
                  <Send className="w-4 h-4" />
                </Button>
              </form>
              <div className="px-4 pb-3 text-[11px] text-muted-foreground">{t('support.chat_hint')}</div>
            </div>
          </GlassCard>
        )}

        <GlassCard>
          <SectionHeader kicker={t('support.my_tickets')} title="History" />
          {tickets.length === 0 ? (
            <div className="text-center text-sm text-muted-foreground py-8">{t('support.no_tickets')}</div>
          ) : (
            <div className="space-y-2">
              {tickets.map((tk) => (
                <div key={tk.id} className="p-3 rounded-lg border border-border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-xs text-muted-foreground">{tk.id}</span>
                    <StatusPill tone={STATUS_TONE[tk.status] || 'neutral'}>{tk.status}</StatusPill>
                  </div>
                  <div className="text-sm font-medium text-foreground line-clamp-2">{tk.subject}</div>
                  <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-2">
                    <span>{t(`support.${tk.category}`)}</span>
                    <span>·</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> {tk.messages}</span>
                    <span>·</span>
                    <span>{tk.updated}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
};

export default SupportPage;
