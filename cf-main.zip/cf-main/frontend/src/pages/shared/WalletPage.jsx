import React, { useState } from 'react';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { KpiTile, GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Wallet, ArrowDownToLine, ArrowUpFromLine, Banknote, Coins, TrendingUp,
  Building2, CreditCard, ShieldCheck, ArrowLeftRight,
} from 'lucide-react';
import { toast } from 'sonner';

const TX_META = {
  deposit: { icon: ArrowDownToLine, tone: 'success', dir: 'in', i18n: 'wallet.tx_deposit' },
  withdraw: { icon: ArrowUpFromLine, tone: 'warning', dir: 'out', i18n: 'wallet.tx_withdraw' },
  invest: { icon: TrendingUp, tone: 'info', dir: 'out', i18n: 'wallet.tx_invest' },
  return: { icon: Coins, tone: 'gold', dir: 'in', i18n: 'wallet.tx_return' },
  principal: { icon: ArrowLeftRight, tone: 'info', dir: 'in', i18n: 'wallet.tx_principal' },
};

export const WalletPage = () => {
  const { t, fmtCurrency } = useI18n();
  const { wallet, escrow, fundWallet, withdrawFromWallet } = useStore();
  const { user, role } = useAuth();
  const [fundOpen, setFundOpen] = useState(false);
  const [wdOpen, setWdOpen] = useState(false);
  const [amount, setAmount] = useState(500);
  const [method, setMethod] = useState('bank');

  const lifetimeDeposits = escrow.filter((x) => x.type === 'deposit').reduce((s, x) => s + x.amount, 0);
  const lifetimeReturns = escrow.filter((x) => x.type === 'return' || x.type === 'principal').reduce((s, x) => s + x.amount, 0);

  const handleFund = () => {
    if (amount <= 0) return;
    fundWallet(amount, method);
    setFundOpen(false);
    toast.success(t('wallet.funded_success'));
  };
  const handleWithdraw = () => {
    if (amount <= 0 || amount > wallet.available) {
      toast.error('Invalid withdrawal amount.'); return;
    }
    withdrawFromWallet(amount);
    setWdOpen(false);
    toast.success(t('wallet.withdrawn_success'));
  };

  const ESCROW_ACCOUNT = `OM-RWF-ESC-${role === 'investor' ? 'INV' : 'BOR'}-${(user?.civilId || '00000000').replace(/[^0-9]/g,'').slice(-6).padStart(6,'0')}`;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('roles.investor')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{t('wallet.title')}</h1>
          <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-accent" /> {t('wallet.subtitle')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button data-testid="wallet-fund-btn" onClick={() => { setAmount(1000); setFundOpen(true); }} className="bg-primary hover:bg-primary/90 rounded-full">
            <ArrowDownToLine className="me-1 w-4 h-4" /> {t('wallet.fund')}
          </Button>
          <Button data-testid="wallet-withdraw-btn" variant="outline" onClick={() => { setAmount(500); setWdOpen(true); }} className="rounded-full">
            <ArrowUpFromLine className="me-1 w-4 h-4" /> {t('wallet.withdraw')}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiTile label={t('wallet.available')} value={fmtCurrency(wallet.available)} icon={Wallet} accent />
        <KpiTile label={t('wallet.reserved')} value={fmtCurrency(wallet.reserved)} icon={Coins} />
        <KpiTile label={t('wallet.lifetime_in')} value={fmtCurrency(lifetimeDeposits)} icon={Banknote} />
        <KpiTile label={t('wallet.lifetime_returns')} value={fmtCurrency(lifetimeReturns)} icon={TrendingUp} delta={{ value: 8.7, label: 'YoY' }} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-1">
          <SectionHeader kicker={t('wallet.escrow_account')} title="Account details" />
          <div className="rounded-lg p-4 bg-gradient-royal text-white mb-4">
            <div className="text-[10px] uppercase tracking-wider text-accent/90">{t('wallet.escrow_account')}</div>
            <div className="font-mono text-base mt-1 num-display">{ESCROW_ACCOUNT}</div>
            <div className="mt-3 text-[11px] text-white/70">Ring-fenced · Bank Muscat Custodian Trust</div>
          </div>
          <Row label={t('wallet.account_name')} value={user?.name} />
          <Row label={t('wallet.bank')} value="Bank Muscat" />
          <Row label="Currency" value="OMR" />
          <div className="divider-gold my-4" />
          <SectionHeader kicker={t('wallet.bank_link')} title="Linked bank" />
          <Row label={t('wallet.iban')} value="OM81 0019 0123 4567 8901 2345" />
          <Row label={t('wallet.bank')} value="Bank Muscat" />
          <Row label={t('wallet.account_name')} value={user?.name} />
          <Row label="SWIFT" value="BMUSOMRX" />
        </GlassCard>

        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker={t('wallet.transactions')} title="Escrow ledger" />
          {escrow.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground text-sm">{t('wallet.no_tx')}</div>
          ) : (
            <div className="divide-y divide-border">
              {escrow.map((tx) => {
                const meta = TX_META[tx.type] || TX_META.deposit;
                const Icon = meta.icon;
                const positive = tx.amount > 0;
                return (
                  <div key={tx.id} data-testid={`wallet-tx-${tx.id}`} className="flex items-center gap-3 py-3">
                    <div className={`w-10 h-10 rounded-lg grid place-items-center shrink-0 ${
                      meta.tone === 'success' ? 'bg-success/10 text-success' :
                      meta.tone === 'warning' ? 'bg-warning/10 text-warning' :
                      meta.tone === 'gold' ? 'bg-accent/15 text-accent' : 'bg-info/10 text-info'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">{tx.label}</div>
                      <div className="text-[11px] text-muted-foreground">{tx.date} · {tx.ref}</div>
                    </div>
                    <div className={`text-end num-display font-semibold ${positive ? 'text-success' : 'text-foreground'}`}>
                      {positive ? '+' : ''}{fmtCurrency(tx.amount)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </GlassCard>
      </div>

      {/* Fund dialog */}
      <Dialog open={fundOpen} onOpenChange={setFundOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">{t('wallet.fund')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('wallet.enter_amount')}</label>
              <input
                type="number"
                data-testid="wallet-amount-input"
                value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-lg border border-input bg-background num-display"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('wallet.fund_method')}</label>
              <div className="grid grid-cols-2 gap-2">
                <MethodButton active={method === 'bank'} onClick={() => setMethod('bank')} icon={Building2} label={t('wallet.method_bank')} />
                <MethodButton active={method === 'card'} onClick={() => setMethod('card')} icon={CreditCard} label={t('wallet.method_card')} />
              </div>
            </div>
            <div className="rounded-lg p-3 bg-muted/40 text-xs text-muted-foreground flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-accent mt-0.5" />
              <div>Funds are credited to your escrow account at Bank Muscat. Settlement is typically instant in this prototype.</div>
            </div>
            <Button onClick={handleFund} className="w-full bg-primary hover:bg-primary/90 rounded-full" data-testid="wallet-confirm-fund">
              {t('wallet.confirm_fund')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Withdraw dialog */}
      <Dialog open={wdOpen} onOpenChange={setWdOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">{t('wallet.withdraw')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('wallet.enter_amount')}</label>
              <input
                type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-lg border border-input bg-background num-display"
              />
              <div className="text-[11px] text-muted-foreground mt-1.5">Available: {fmtCurrency(wallet.available)}</div>
            </div>
            <Button onClick={handleWithdraw} className="w-full bg-primary hover:bg-primary/90 rounded-full" data-testid="wallet-confirm-withdraw">
              {t('wallet.confirm_withdraw')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const Row = ({ label, value }) => (
  <div className="flex items-center justify-between py-1.5">
    <span className="text-xs text-muted-foreground">{label}</span>
    <span className="text-sm font-medium text-foreground font-mono">{value}</span>
  </div>
);
const MethodButton = ({ active, onClick, icon: Icon, label }) => (
  <button
    onClick={onClick}
    className={`p-3 rounded-lg border text-start text-sm transition-all flex items-center gap-2 ${
      active ? 'border-accent bg-accent/10 font-semibold' : 'border-border bg-card hover:bg-muted/40'
    }`}
  >
    <Icon className="w-4 h-4 text-accent" /> {label}
  </button>
);

export default WalletPage;
