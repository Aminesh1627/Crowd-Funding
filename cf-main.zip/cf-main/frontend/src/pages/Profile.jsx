import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useAuth } from '@/context/AuthContext';
import { useStore } from '@/context/DemoStoreContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, StatusPill } from '@/components/Primitives';
import { Switch } from '@/components/ui/switch';
import {
  CheckCircle2, Clock, AlertTriangle, RotateCcw, ShieldCheck, IdCard,
  ScanSearch, Wallet, FileSignature, UserCircle2, Building2, CreditCard,
  Bell, Mail, Smartphone, KeyRound, Globe, Award,
} from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { toast } from 'sonner';

const STATUS_TONE = { verified: 'success', pending: 'warning', in_review: 'info', failed: 'danger' };
const STATUS_ICON = { verified: CheckCircle2, pending: Clock, in_review: Clock, failed: AlertTriangle };

const STEPS_INVESTOR = [
  { k: 'suitability', icon: UserCircle2, label: 'onboarding.step2' },
  { k: 'kyc', icon: IdCard, label: 'onboarding.step3' },
  { k: 'amlScreening', icon: ScanSearch, label: 'onboarding.step4' },
  { k: 'wallet', icon: Wallet, label: 'onboarding.step5' },
  { k: 'agreements', icon: FileSignature, label: 'onboarding.agree_terms' },
];
const STEPS_BORROWER = [
  { k: 'crVerification', icon: IdCard, label: 'borrower.doc_cr' },
  { k: 'companyKyc', icon: UserCircle2, label: 'borrower.doc_lic' },
  { k: 'amlScreening', icon: ScanSearch, label: 'onboarding.step4' },
  { k: 'bankDetails', icon: Wallet, label: 'bank.bank_account' },
  { k: 'boardResolution', icon: FileSignature, label: 'borrower.doc_board' },
];

const BANK_BY_ROLE = {
  investor: {
    bank: 'Bank Muscat', branch: 'Qurum Branch', account: '0123 4567 8901',
    iban: 'OM81 0019 0123 4567 8901 2345', swift: 'BMUSOMRX',
  },
  borrower: {
    bank: 'Bank Dhofar', branch: 'CBD Muscat', account: '7788 5432 1100',
    iban: 'OM67 0033 7788 5432 1100 0019', swift: 'BDOFOMRU',
  },
  admin: {
    bank: 'N/A', branch: 'Platform Operations', account: '—',
    iban: '—', swift: '—',
  },
  regulator: {
    bank: 'CMA Treasury', branch: 'Regulator Office', account: '—',
    iban: 'OM00 0000 0000 0000 0000 0000', swift: 'CMAOOMRX',
  },
};

export const Profile = () => {
  const { t } = useI18n();
  const { user, role, onboarding } = useAuth();
  const { resetDemo } = useStore();
  const navigate = useNavigate();

  const roleOnb = onboarding?.[role === 'borrower' ? 'borrower' : 'investor'];
  const isInvestor = role === 'investor';
  const isBorrower = role === 'borrower';
  const showOnboarding = isInvestor || isBorrower;
  const STEPS = isInvestor ? STEPS_INVESTOR : STEPS_BORROWER;
  const bank = BANK_BY_ROLE[role] || BANK_BY_ROLE.investor;

  const ESCROW_ACCOUNT = `OM-RWF-ESC-${role.slice(0, 3).toUpperCase()}-${(user?.civilId || '00000000').replace(/[^0-9]/g, '').slice(-6).padStart(6, '0')}`;

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('common.profile')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">{t('profile.title')}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t('profile.sub')}</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* LEFT — Identity card */}
        <GlassCard className="text-center">
          <div
            className="w-24 h-24 mx-auto rounded-full grid place-items-center text-2xl font-bold text-white shadow-elegant"
            style={{ background: `hsl(${user?.avatarHue || 215} 50% 30%)` }}
          >
            {user?.initials}
          </div>
          <div className="mt-5 font-serif-display text-2xl text-primary">{user?.name}</div>
          <div className="text-sm text-muted-foreground">{user?.title}</div>
          <div className="mt-3 inline-flex items-center gap-2 flex-wrap justify-center">
            <StatusPill tone="gold">{t(`roles.${role}`)}</StatusPill>
            {(user?.category || roleOnb?.category) && (
              <StatusPill tone="info"><Award className="w-3 h-3" /> {user?.category || roleOnb?.category}</StatusPill>
            )}
          </div>
          <div className="divider-gold my-5" />
          <div className="text-start space-y-2">
            <Row label={t('common.email')} value={user?.email} />
            {user?.civilId && <Row label={t('common.civil_id')} value={user.civilId} />}
            {user?.company && <Row label={t('common.company')} value={user.company} />}
            {user?.crNumber && <Row label="CR Number" value={user.crNumber} />}
            {user?.team && <Row label="Team" value={user.team} />}
            {user?.entity && <Row label="Entity" value={user.entity} />}
            {user?.clearance && <Row label="Clearance" value={user.clearance} />}
            <Row label={t('profile.member_since')} value={roleOnb?.completedAt || '2024-08-12'} />
          </div>
        </GlassCard>

        {/* MIDDLE — Bank + Escrow */}
        <GlassCard className="lg:col-span-1">
          <SectionHeader kicker={t('bank.title')} title={t('bank.bank_account')} />
          <div className="space-y-2">
            <Row label={t('bank.bank')} value={bank.bank} />
            <Row label={t('bank.branch')} value={bank.branch} />
            <Row label={t('bank.account_holder')} value={user?.name} />
            <Row label={t('bank.account_number')} value={bank.account} mono />
            <Row label={t('bank.iban')} value={bank.iban} mono />
            <Row label={t('bank.swift')} value={bank.swift} mono />
          </div>
          <StatusPill tone="success" >
            <CheckCircle2 className="w-3 h-3" /> {t('bank.primary')} · {t('bank.verified_on')} 2024-09-04
          </StatusPill>

          <div className="divider-gold my-5" />
          <SectionHeader kicker={t('bank.escrow_account')} title="Custodian wallet" />
          <div className="rounded-lg p-4 bg-gradient-royal text-white mb-3">
            <div className="text-[10px] uppercase tracking-wider text-accent/90">{t('bank.escrow_account')}</div>
            <div className="font-mono text-base mt-1 num-display">{ESCROW_ACCOUNT}</div>
            <div className="mt-3 text-[11px] text-white/70">Ring-fenced · Bank Muscat Custodian Trust</div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-lg p-2.5 bg-muted/50">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Currency</div>
              <div className="font-semibold">OMR</div>
            </div>
            <div className="rounded-lg p-2.5 bg-muted/50">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</div>
              <div className="font-semibold text-success">Active</div>
            </div>
          </div>
          {(isInvestor || isBorrower) && (
            <Button variant="outline" size="sm" onClick={() => navigate('/app/wallet')} className="mt-4 w-full rounded-full">
              <Wallet className="me-1 w-4 h-4" /> {t('common.view')} {t('wallet.title')}
            </Button>
          )}
        </GlassCard>

        {/* RIGHT — Status / preferences / additional */}
        <GlassCard className="lg:col-span-1">
          {showOnboarding ? (
            <>
              <SectionHeader kicker={t('profile.status')} title={isInvestor ? t('onboarding.title') : 'Verification status'} />
              {isInvestor && !roleOnb?.completedAt ? (
                <div className="rounded-xl border border-warning/30 bg-warning/10 p-4 flex items-center justify-between gap-3 mb-4">
                  <div className="text-sm font-medium">{t('investor.onboarding_required')}</div>
                  <Button size="sm" onClick={() => navigate('/onboarding')} className="bg-warning text-warning-foreground hover:bg-warning/90 rounded-full">
                    {t('onboarding.resume')}
                  </Button>
                </div>
              ) : (
                <div className="rounded-xl border border-success/30 bg-success/10 p-4 flex items-center gap-3 mb-4">
                  <ShieldCheck className="w-5 h-5 text-success shrink-0" />
                  <div className="text-sm font-medium">{t('onboarding.already_done')}</div>
                </div>
              )}
              <div className="space-y-2">
                {STEPS.map((s) => {
                  const status = roleOnb?.[s.k] || 'pending';
                  const tone = STATUS_TONE[status] || 'neutral';
                  const StatusIcon = STATUS_ICON[status] || Clock;
                  const Icon = s.icon;
                  return (
                    <div key={s.k} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-muted/40">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-accent/10 grid place-items-center">
                          <Icon className="w-3.5 h-3.5 text-accent" />
                        </div>
                        <div className="text-sm font-medium">{t(s.label)}</div>
                      </div>
                      <StatusPill tone={tone}>
                        <StatusIcon className="w-3 h-3" />
                        {t(`common.${status === 'in_review' ? 'in_review' : status}`)}
                      </StatusPill>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <>
              <SectionHeader kicker={role === 'admin' ? 'Operations' : 'Oversight'} title="Access & responsibilities" />
              <div className="space-y-2">
                {(role === 'admin' ? [
                  { l: 'Review queues', d: 'Credit · Risk · Onboarding · Compliance' },
                  { l: 'User management', d: 'Manage users, roles and groups' },
                  { l: 'Workflow & engine', d: 'Configure decision rules + lifecycle' },
                  { l: 'Master data', d: 'Loans · Documents · Languages' },
                ] : [
                  { l: 'Compliance oversight', d: 'Read-only access to all flags & filings' },
                  { l: 'Audit logs', d: 'Immutable, four-eyes attested trail' },
                  { l: 'Law Suite', d: 'Litigation involving platform parties' },
                  { l: 'Regulator reports', d: 'Quarterly and ad-hoc disclosures' },
                ]).map((r, i) => (
                  <div key={i} className="p-3 rounded-lg border border-border bg-muted/30">
                    <div className="text-sm font-medium text-foreground">{r.l}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{r.d}</div>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="divider-gold my-5" />
          <SectionHeader kicker={t('bank.preferences_title')} title="Channels" />
          <div className="space-y-2">
            <PrefRow id="email" icon={Mail} label={t('bank.pref_email')} defaultOn />
            <PrefRow id="sms" icon={Smartphone} label={t('bank.pref_sms')} defaultOn />
            <PrefRow id="push" icon={Bell} label={t('bank.pref_push')} />
            <PrefRow id="2fa" icon={KeyRound} label={t('bank.pref_2fa')} defaultOn locked />
          </div>
        </GlassCard>
      </div>

      <GlassCard>
        <SectionHeader kicker={t('profile.preferences')} title="Demo controls" />
        <div className="flex flex-wrap items-center justify-between p-4 rounded-lg bg-muted/40 border border-border gap-3">
          <div>
            <div className="font-medium text-foreground">Reset prototype data</div>
            <div className="text-xs text-muted-foreground mt-0.5">
              Restores all campaigns, investments and onboarding state to the original seed.
            </div>
          </div>
          <Button
            data-testid={RAWAFID.resetDemo}
            variant="outline"
            onClick={() => { resetDemo(); toast.success(t('profile.reset_done')); }}
          >
            <RotateCcw className="me-1 w-4 h-4" /> {t('profile.reset_demo')}
          </Button>
        </div>
      </GlassCard>
    </div>
  );
};

const Row = ({ label, value, mono }) => (
  <div className="flex justify-between items-center gap-3 py-1">
    <span className="text-xs text-muted-foreground shrink-0">{label}</span>
    <span className={`text-sm font-medium text-foreground truncate ${mono ? 'font-mono' : ''}`}>{value || '—'}</span>
  </div>
);
const PrefRow = ({ id, icon: Icon, label, defaultOn, locked }) => (
  <div className="flex items-center justify-between p-2.5 rounded-lg hover:bg-muted/40">
    <div className="flex items-center gap-2.5">
      <Icon className="w-4 h-4 text-accent" />
      <span className="text-sm">{label}</span>
    </div>
    <Switch data-testid={`pref-${id}`} defaultChecked={defaultOn} disabled={locked} />
  </div>
);

export default Profile;
