import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { Logo } from '@/components/Logo';
import { LangToggle } from '@/components/LangToggle';
import { Button } from '@/components/ui/button';
import { stats, testimonials, seedCampaigns } from '@/data/mockData';
import { RAWAFID } from '@/constants/testIds';
import {
  ShieldCheck, Users, Sparkles, Globe2, ArrowRight, Building2,
  Compass, Banknote, RefreshCw, Award, ChevronDown, MapPin,
} from 'lucide-react';
import { GlassCard, StatusPill, RiskBadge } from '@/components/Primitives';

const HERO_IMG = 'https://images.unsplash.com/photo-1546412414-e1885259563a?w=1600&q=80&auto=format&fit=crop';

export const Landing = () => {
  const { t, lang, fmtNum, fmtCurrency } = useI18n();
  const navigate = useNavigate();
  const campaigns = seedCampaigns().slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="absolute top-0 inset-x-0 z-20 px-6 lg:px-12 py-5 flex items-center justify-between">
        <Logo size="md" light withTag />
        <nav className="hidden lg:flex items-center gap-8">
          {[
            { k: 'how', href: '#how' },
            { k: 'marketplace', href: '#market' },
            { k: 'for_borrowers', href: '#why' },
            { k: 'about', href: '#faq' },
          ].map((n) => (
            <a key={n.k} href={n.href} className="text-sm text-white/85 hover:text-accent transition-colors font-medium">
              {t(`nav.${n.k}`)}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <LangToggle light />
          <Button
            onClick={() => navigate('/login')}
            data-testid={RAWAFID.landingCtaSignin}
            className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full h-10 px-5 font-semibold shadow-gold"
          >
            {t('landing.cta_signin')}
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section
        data-testid={RAWAFID.landingHero}
        className="relative min-h-[100vh] flex items-center overflow-hidden grain-overlay"
      >
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="Muscat skyline" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/95 via-primary/85 to-primary/70" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,hsl(40_80%_60%/0.25),transparent_60%)]" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 lg:px-12 py-32 grid lg:grid-cols-12 gap-12 items-center w-full">
          <div className="lg:col-span-7 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-accent/30 backdrop-blur-md mb-8">
              <ShieldCheck className="w-3.5 h-3.5 text-accent" />
              <span className="text-[11px] uppercase tracking-[0.22em] text-white/90 font-medium">
                {t('landing.kicker')}
              </span>
            </div>
            <h1 className="font-serif-display text-5xl sm:text-6xl lg:text-7xl text-white leading-[1.05] tracking-tight">
              {t('landing.title_a')}
              <br />
              <span className="gradient-text-gold">{t('landing.title_b')}</span>
            </h1>
            <p className="mt-7 text-lg text-white/80 max-w-2xl leading-relaxed">
              {t('landing.subtitle')}
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Button
                onClick={() => navigate('/login')}
                data-testid={RAWAFID.landingCtaPrimary}
                className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full h-12 px-7 font-semibold shadow-gold"
              >
                {t('landing.cta_primary')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
              </Button>
              <Button
                onClick={() => navigate('/login')}
                variant="outline"
                data-testid={RAWAFID.landingCtaSecondary}
                className="border-white/30 text-white hover:bg-white/10 bg-transparent rounded-full h-12 px-7 font-semibold"
              >
                {t('landing.cta_secondary')}
              </Button>
            </div>
            <div className="mt-12 flex items-center gap-2 text-xs text-white/60">
              <Award className="w-3.5 h-3.5 text-accent" />
              <span className="tracking-wider">{t('landing.trust_pill')}</span>
            </div>
          </div>

          {/* Hero stats card */}
          <div className="lg:col-span-5 animate-fade-up" style={{ animationDelay: '120ms' }}>
            <div className="glass-dark rounded-2xl p-7 shadow-elegant">
              <div className="flex items-center justify-between mb-6">
                <div className="text-xs uppercase tracking-[0.22em] text-accent">{t('common.overview')}</div>
                <StatusPill tone="gold">Live</StatusPill>
              </div>
              <div className="grid grid-cols-2 gap-5">
                <div>
                  <div className="text-xs text-white/60 uppercase tracking-wider mb-1.5">{t('landing.stat_funded')}</div>
                  <div className="font-serif-display text-3xl text-white num-display">{fmtCurrency(stats.funded)}</div>
                </div>
                <div>
                  <div className="text-xs text-white/60 uppercase tracking-wider mb-1.5">{t('landing.stat_campaigns')}</div>
                  <div className="font-serif-display text-3xl text-white num-display">{stats.campaigns}</div>
                </div>
                <div>
                  <div className="text-xs text-white/60 uppercase tracking-wider mb-1.5">{t('landing.stat_investors')}</div>
                  <div className="font-serif-display text-3xl text-white num-display">{fmtNum(stats.investors)}</div>
                </div>
                <div>
                  <div className="text-xs text-white/60 uppercase tracking-wider mb-1.5">{t('landing.stat_return')}</div>
                  <div className="font-serif-display text-3xl gradient-text-gold num-display">{stats.avgReturn}%</div>
                </div>
              </div>
              <div className="divider-gold my-6" />
              <div className="flex items-center gap-3 text-xs text-white/70">
                <MapPin className="w-3.5 h-3.5 text-accent" />
                <span>Muscat · Sohar · Salalah · Nizwa</span>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-6 inset-x-0 grid place-items-center text-white/60 animate-fade-in" style={{ animationDelay: '600ms' }}>
          <ChevronDown className="w-5 h-5" />
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-24 pattern-arabesque">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="max-w-2xl">
            <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
              {t('landing.how_kicker')}
            </div>
            <h2 className="font-serif-display text-4xl sm:text-5xl text-primary leading-tight">
              {t('landing.how_title')}
            </h2>
            <p className="mt-5 text-muted-foreground text-lg">{t('landing.how_subtitle')}</p>
          </div>
          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Building2, t: 'landing.step1_title', d: 'landing.step1_desc' },
              { icon: ShieldCheck, t: 'landing.step2_title', d: 'landing.step2_desc' },
              { icon: Banknote, t: 'landing.step3_title', d: 'landing.step3_desc' },
              { icon: RefreshCw, t: 'landing.step4_title', d: 'landing.step4_desc' },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <div
                  key={i}
                  className="group relative p-7 rounded-xl bg-card border border-border shadow-card-elegant hover:shadow-elegant transition-all hover-lift"
                >
                  <div className="absolute top-7 end-7 text-6xl font-serif-display text-accent/15 group-hover:text-accent/30 transition-colors">
                    0{i + 1}
                  </div>
                  <div className="w-12 h-12 rounded-lg bg-gradient-gold grid place-items-center shadow-gold mb-5">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-serif-display text-xl text-primary mb-2">{t(s.t)}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{t(s.d)}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Rawafid */}
      <section id="why" className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute -top-32 -end-32 w-[500px] h-[500px] rounded-full bg-accent/10 blur-3xl" />
        <div className="absolute -bottom-32 -start-32 w-[400px] h-[400px] rounded-full bg-secondary/20 blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-12 gap-12 items-start">
            <div className="lg:col-span-4">
              <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
                {t('landing.pillars_kicker')}
              </div>
              <h2 className="font-serif-display text-4xl sm:text-5xl text-white leading-tight">
                {t('landing.pillars_title')}
              </h2>
            </div>
            <div className="lg:col-span-8 grid sm:grid-cols-2 gap-5">
              {[
                { icon: ShieldCheck, t: 'landing.pillar1', d: 'landing.pillar1_d' },
                { icon: Users, t: 'landing.pillar2', d: 'landing.pillar2_d' },
                { icon: Sparkles, t: 'landing.pillar3', d: 'landing.pillar3_d' },
                { icon: Globe2, t: 'landing.pillar4', d: 'landing.pillar4_d' },
              ].map((p, i) => {
                const Icon = p.icon;
                return (
                  <div key={i} className="glass-dark rounded-xl p-6 hover-lift">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 text-accent grid place-items-center mb-4">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif-display text-lg text-white mb-2">{t(p.t)}</h3>
                    <p className="text-sm text-white/70 leading-relaxed">{t(p.d)}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Marketplace preview */}
      <section id="market" className="py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl">
              <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
                {t('landing.market_kicker')}
              </div>
              <h2 className="font-serif-display text-4xl sm:text-5xl text-primary leading-tight">
                {t('landing.market_title')}
              </h2>
              <p className="mt-4 text-muted-foreground text-lg">{t('landing.market_subtitle')}</p>
            </div>
            <Button
              onClick={() => navigate('/login')}
              variant="outline"
              className="rounded-full h-11 px-5 border-primary/20 hover:bg-primary hover:text-primary-foreground"
            >
              {t('landing.market_view_all')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {campaigns.map((c) => {
              const pct = Math.round((c.raised / c.target) * 100);
              return (
                <div
                  key={c.id}
                  data-testid={`marketplace-card-${c.id}`}
                  className="group rounded-xl bg-card border border-border shadow-card-elegant overflow-hidden hover-lift"
                >
                  <div className="relative h-44 bg-gradient-primary overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,hsl(40_80%_60%/0.45),transparent_55%)]" />
                    <div className="absolute top-4 start-4 flex items-center gap-2">
                      <RiskBadge grade={c.riskGrade} />
                      <StatusPill tone="gold">{t(`sectors.${c.sector}`)}</StatusPill>
                    </div>
                    <div className="absolute bottom-4 start-4 end-4 text-white">
                      <div className="text-xs uppercase tracking-[0.18em] text-accent/90 mb-1">{c.id} · {c.region}</div>
                      <div className="font-serif-display text-lg leading-tight line-clamp-2">{c.title}</div>
                    </div>
                  </div>
                  <div className="p-5">
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{c.summary}</p>
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="text-muted-foreground">{t('investor.funded')}</span>
                      <span className="font-semibold text-primary num-display">{pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-3 text-center">
                      <div>
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('investor.expected_return')}</div>
                        <div className="font-serif-display text-lg text-primary num-display">{c.rate}%</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('common.tenure')}</div>
                        <div className="font-serif-display text-lg text-primary num-display">{c.tenure}m</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{t('investor.days_left')}</div>
                        <div className="font-serif-display text-lg text-primary num-display">{c.daysLeft || '—'}</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-gradient-subtle">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
              {t('landing.testi_kicker')}
            </div>
            <h2 className="font-serif-display text-4xl sm:text-5xl text-primary">{t('landing.testi_title')}</h2>
          </div>
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {testimonials.map((tm, i) => (
              <GlassCard key={i} className="hover-lift">
                <div className="font-serif-display text-3xl text-accent mb-3 leading-none">“</div>
                <p className="text-sm text-foreground leading-relaxed mb-5">{tm.quote}</p>
                <div className="divider-gold mb-4" />
                <div>
                  <div className="font-semibold text-primary text-sm">{tm.name}</div>
                  <div className="text-xs text-muted-foreground">{tm.role}</div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-12">
          <div className="text-center mb-12">
            <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-2">
              {t('landing.faq_kicker')}
            </div>
            <h2 className="font-serif-display text-4xl sm:text-5xl text-primary">{t('landing.faq_title')}</h2>
          </div>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <details key={i} className="group bg-card border border-border rounded-xl px-5 py-4 hover:shadow-card-elegant transition-shadow">
                <summary className="flex items-center justify-between cursor-pointer list-none">
                  <span className="font-serif-display text-lg text-primary">{t(`landing.faq_q${i}`)}</span>
                  <ChevronDown className="w-5 h-5 text-accent transition-transform group-open:rotate-180" />
                </summary>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{t(`landing.faq_a${i}`)}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gradient-royal text-white relative overflow-hidden">
        <div className="absolute -top-20 -end-20 w-96 h-96 rounded-full bg-accent/15 blur-3xl" />
        <div className="relative max-w-4xl mx-auto px-6 lg:px-12 text-center">
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-3">
            {t('landing.cta_final_kicker')}
          </div>
          <h2 className="font-serif-display text-4xl sm:text-6xl leading-tight">{t('landing.cta_final_title')}</h2>
          <p className="mt-5 text-white/75 text-lg max-w-2xl mx-auto">{t('landing.cta_final_sub')}</p>
          <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
            <Button
              onClick={() => navigate('/login')}
              className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full h-12 px-7 font-semibold shadow-gold"
            >
              {t('landing.cta_primary')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
            </Button>
            <Button
              onClick={() => navigate('/login')}
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 bg-transparent rounded-full h-12 px-7 font-semibold"
            >
              {t('landing.cta_secondary')}
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground/70 py-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex flex-wrap items-center justify-between gap-4">
          <Logo size="sm" light />
          <div className="text-xs">{t('landing.footer_built')}</div>
          <div className="text-xs">© {new Date().getFullYear()} Rawafid · {t('landing.footer_rights')}</div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
