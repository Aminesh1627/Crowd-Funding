import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { GlassCard, SectionHeader, RiskBadge, StatusPill } from '@/components/Primitives';
import { ArrowRight, Bookmark, Calculator, Filter, MapPin, Sparkles } from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { SECTORS, RISK_GRADES } from '@/data/mockData';

const SORTS = ['new', 'return', 'closing'];

export const Marketplace = () => {
  const { t, fmtCurrency } = useI18n();
  const { campaigns } = useStore();
  const { onboarding } = useAuth();
  const navigate = useNavigate();

  const [sector, setSector] = useState('all');
  const [risk, setRisk] = useState('all');
  const [sort, setSort] = useState('new');
  const [progressMax, setProgressMax] = useState(100);

  // Inline return calculator
  const [calcAmount, setCalcAmount] = useState(1000);
  const [calcRate, setCalcRate] = useState(11);
  const [calcTenure, setCalcTenure] = useState(24);
  const calcMonthly = (calcAmount * (calcRate / 100)) / 12;
  const calcProfit = (calcAmount * (calcRate / 100)) * (calcTenure / 12);
  const calcTotal = calcAmount + calcProfit;

  const filtered = useMemo(() => {
    let list = campaigns.filter((c) => c.stage === 'funding' || c.stage === 'submitted');
    if (sector !== 'all') list = list.filter((c) => c.sector === sector);
    if (risk !== 'all') list = list.filter((c) => c.riskGrade === risk);
    list = list.filter((c) => (c.raised / c.target) * 100 <= progressMax);
    if (sort === 'return') list.sort((a, b) => b.rate - a.rate);
    else if (sort === 'closing') list.sort((a, b) => a.daysLeft - b.daysLeft);
    else list.sort((a, b) => b.id.localeCompare(a.id));
    return list;
  }, [campaigns, sector, risk, sort, progressMax]);

  const onboardingDone = onboarding?.investor?.completedAt;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('investor.marketplace')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{t('landing.market_title')}</h1>
        </div>
        {!onboardingDone && (
          <StatusPill tone="warning"><Sparkles className="w-3 h-3" /> Complete onboarding to invest</StatusPill>
        )}
      </div>

      {/* Inline return calculator */}
      <GlassCard data-testid="marketplace-calculator" className="bg-gradient-royal text-white border-accent/30">
        <div className="grid lg:grid-cols-12 gap-5 items-center">
          <div className="lg:col-span-3">
            <div className="text-[11px] uppercase tracking-[0.22em] text-accent mb-1 flex items-center gap-1.5">
              <Calculator className="w-3.5 h-3.5" /> {t('investor.returns_calc')}
            </div>
            <div className="font-serif-display text-xl text-white">Preview returns before you invest</div>
          </div>
          <div className="lg:col-span-7 grid grid-cols-3 gap-3">
            <CalcInput light label={t('investor.calc_invest')} value={calcAmount} onChange={setCalcAmount} />
            <CalcInput light label={`${t('investor.calc_rate')} (%)`} value={calcRate} onChange={setCalcRate} step={0.1} />
            <CalcInput light label={`${t('investor.calc_tenure')} (m)`} value={calcTenure} onChange={setCalcTenure} />
          </div>
          <div className="lg:col-span-2 grid grid-cols-2 gap-2">
            <CalcStat label={t('investor.calc_monthly')} value={fmtCurrency(Math.round(calcMonthly))} />
            <CalcStat label={t('investor.calc_total_profit')} value={fmtCurrency(Math.round(calcProfit))} gold />
          </div>
        </div>
      </GlassCard>

      {/* Filters */}
      <GlassCard className="p-5">
        <div className="flex flex-wrap items-end gap-4">
          <div className="min-w-[160px]">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.filter_sector')}</label>
            <select
              data-testid={RAWAFID.marketplaceFilterSector}
              value={sector} onChange={(e) => setSector(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-accent/40"
            >
              <option value="all">{t('common.filter')} —</option>
              {SECTORS.map((s) => <option key={s} value={s}>{t(`sectors.${s}`)}</option>)}
            </select>
          </div>
          <div className="min-w-[140px]">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.filter_risk')}</label>
            <select
              data-testid={RAWAFID.marketplaceFilterRisk}
              value={risk} onChange={(e) => setRisk(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-accent/40"
            >
              <option value="all">{t('common.filter')} —</option>
              {RISK_GRADES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="min-w-[200px] flex-1">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.filter_progress')} (≤ {progressMax}%)</label>
            <Slider value={[progressMax]} onValueChange={(v) => setProgressMax(v[0])} max={100} step={5} />
          </div>
          <div className="min-w-[140px]">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.sort_by')}</label>
            <select
              data-testid={RAWAFID.marketplaceSort}
              value={sort} onChange={(e) => setSort(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-accent/40"
            >
              {SORTS.map((s) => <option key={s} value={s}>{t(`investor.sort_${s}`)}</option>)}
            </select>
          </div>
          <Button variant="ghost" onClick={() => { setSector('all'); setRisk('all'); setSort('new'); setProgressMax(100); }}>
            {t('common.clear')}
          </Button>
        </div>
      </GlassCard>

      {/* Grid */}
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
        {filtered.length === 0 && (
          <div className="col-span-full p-12 text-center text-muted-foreground">
            <Filter className="w-7 h-7 mx-auto mb-3 opacity-50" />
            {t('common.no_results')}
          </div>
        )}
        {filtered.map((c) => {
          const pct = Math.round((c.raised / c.target) * 100);
          return (
            <div
              key={c.id}
              data-testid={RAWAFID.marketplaceCard(c.id)}
              className="group rounded-xl bg-card border border-border shadow-card-elegant overflow-hidden hover-lift cursor-pointer"
              onClick={() => navigate(`/app/marketplace/${c.id}`)}
            >
              <div className="relative h-32 bg-gradient-primary overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,hsl(40_80%_60%/0.45),transparent_55%)]" />
                <div className="absolute top-4 start-4 flex items-center gap-2">
                  <RiskBadge grade={c.riskGrade} />
                  <StatusPill tone="gold">{t(`sectors.${c.sector}`)}</StatusPill>
                </div>
                <button onClick={(e) => e.stopPropagation()} className="absolute top-4 end-4 w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 grid place-items-center text-white backdrop-blur-sm">
                  <Bookmark className="w-3.5 h-3.5" />
                </button>
                <div className="absolute bottom-3 start-4 end-4 text-white">
                  <div className="text-[10px] uppercase tracking-[0.18em] text-accent/90 flex items-center gap-1.5">
                    {c.id} · <MapPin className="w-3 h-3" /> {c.region}
                  </div>
                </div>
              </div>
              <div className="p-5">
                <div className="font-serif-display text-base text-primary line-clamp-2 mb-2 min-h-[3rem]">{c.title}</div>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{c.borrower}</p>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">{fmtCurrency(c.raised)} / {fmtCurrency(c.target)}</span>
                  <span className="font-semibold text-primary num-display">{pct}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="bg-muted/50 rounded-md py-2">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{t('investor.expected_return')}</div>
                    <div className="font-serif-display text-base text-primary num-display">{c.rate}%</div>
                  </div>
                  <div className="bg-muted/50 rounded-md py-2">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{t('common.tenure')}</div>
                    <div className="font-serif-display text-base text-primary num-display">{c.tenure}m</div>
                  </div>
                  <div className="bg-muted/50 rounded-md py-2">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{t('investor.days_left')}</div>
                    <div className="font-serif-display text-base text-primary num-display">{c.daysLeft || '—'}</div>
                  </div>
                </div>
                <Button
                  onClick={(e) => { e.stopPropagation(); navigate(`/app/marketplace/${c.id}`); }}
                  className="mt-4 w-full bg-primary hover:bg-primary/90 rounded-lg"
                  size="sm"
                >
                  {t('common.view')} <ArrowRight className="ms-1 w-3.5 h-3.5 rtl-flip" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Marketplace;

const CalcInput = ({ label, value, onChange, light, step = 1 }) => (
  <div>
    <label className={`text-[10px] uppercase tracking-wider block mb-1 ${light ? 'text-white/70' : 'text-muted-foreground'}`}>{label}</label>
    <input
      type="number" step={step} value={value} onChange={(e) => onChange(Number(e.target.value) || 0)}
      className={`w-full h-10 px-3 rounded-lg num-display text-sm font-semibold ${
        light ? 'bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:bg-white/15 focus:outline-none focus:ring-2 focus:ring-accent/60'
              : 'bg-background border border-input'
      }`}
    />
  </div>
);
const CalcStat = ({ label, value, gold }) => (
  <div className="rounded-lg p-2.5 bg-white/10 border border-white/15">
    <div className="text-[9px] uppercase tracking-wider text-white/70">{label}</div>
    <div className={`font-serif-display text-base num-display mt-0.5 ${gold ? 'gradient-text-gold' : 'text-white'}`}>{value}</div>
  </div>
);
