import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useAuth } from '@/context/AuthContext';
import { useStore } from '@/context/DemoStoreContext';
import { KpiTile, GlassCard, SectionHeader, StatusPill, RiskBadge } from '@/components/Primitives';
import {
  ProfitAreaChart, PieAllocChart, CashFlowChart, RiskRadialChart,
} from '@/components/Charts';
import { Button } from '@/components/ui/button';
import {
  Wallet, TrendingUp, ListChecks, Coins, Activity, BarChart3, ArrowRight, Sparkles,
} from 'lucide-react';
import { monthlyReturnSeries, cashFlowForecast, riskDistribution, industryAlloc } from '@/data/mockData';

export const InvestorDashboard = () => {
  const { t, fmtCurrency, fmtNum } = useI18n();
  const { user, onboarding } = useAuth();
  const { wallet, investments } = useStore();
  const navigate = useNavigate();

  const totalInvested = investments.filter((i) => i.status === 'active').reduce((s, i) => s + i.amount, 0);
  const portfolioValue = totalInvested + wallet.available + wallet.reserved;
  const profitEarned = 1985;
  const onboardingDone = onboarding?.investor?.completedAt;

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
            {t('common.welcome')}
          </div>
          <h1 className="font-serif-display text-3xl text-primary">{user?.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('investor.dashboard')}</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={() => navigate('/app/wallet')}
            className="rounded-full h-10 px-5"
          >
            <Wallet className="w-4 h-4 me-1" /> {t('common.fund')}
          </Button>
          <Button
            onClick={() => navigate('/app/marketplace')}
            className="bg-primary hover:bg-primary/90 rounded-full h-10 px-5 font-semibold"
          >
            {t('common.go_to_marketplace')} <ArrowRight className="ms-1 w-4 h-4 rtl-flip" />
          </Button>
        </div>
      </div>

      {!onboardingDone && (
        <div className="rounded-xl border border-accent/30 bg-accent/[0.08] p-5 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-accent" />
            <div className="text-sm font-medium text-foreground">{t('investor.onboarding_required')}</div>
          </div>
          <Button onClick={() => navigate('/onboarding')} size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full">
            {t('investor.complete_onboarding')}
          </Button>
        </div>
      )}

      {/* KPI grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <KpiTile label={t('investor.kpi_portfolio')} value={fmtCurrency(portfolioValue)} delta={{ value: 4.2, label: 'MoM' }} icon={BarChart3} accent />
        <KpiTile label={t('investor.kpi_available')} value={fmtCurrency(wallet.available)} icon={Wallet} />
        <KpiTile label={t('investor.kpi_reserved')} value={fmtCurrency(wallet.reserved)} icon={Coins} />
        <KpiTile label={t('investor.kpi_active_inv')} value={fmtNum(investments.filter((i) => i.status === 'active').length)} icon={ListChecks} />
        <KpiTile label={t('investor.kpi_profit')} value={fmtCurrency(profitEarned)} delta={{ value: 8.7, label: 'YoY' }} icon={TrendingUp} />
        <KpiTile label={t('investor.kpi_diverse')} value={`${investments.length}/10`} sub="Across sectors" icon={Activity} />
      </div>

      {/* Charts row 1 */}
      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker={t('common.overview')} title={t('investor.return_trend')} />
          <ProfitAreaChart data={monthlyReturnSeries} />
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker={t('investor.industry_dist')} title={t('investor.portfolio_alloc')} />
          <PieAllocChart data={industryAlloc} />
        </GlassCard>
      </div>

      {/* Charts row 2 */}
      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker="Outlook" title={t('investor.cash_forecast')} />
          <CashFlowChart data={cashFlowForecast} />
          <div className="mt-3 flex items-center gap-5 text-xs text-muted-foreground">
            <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm bg-primary" /> Inflow</span>
            <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm bg-accent" /> Outflow</span>
          </div>
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker="Allocation" title={t('investor.risk_dist')} />
          <RiskRadialChart data={riskDistribution} />
        </GlassCard>
      </div>

      {/* Active investments table */}
      <GlassCard>
        <SectionHeader
          kicker={t('investor.portfolio_title')}
          title={t('investor.distributions')}
          action={<Button variant="ghost" size="sm" onClick={() => navigate('/app/portfolio')}>{t('common.view_all')} →</Button>}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3 font-medium">ID</th>
                <th className="text-start py-3 font-medium">{t('borrower.borrower' === 'borrower' ? 'Campaign' : '')}</th>
                <th className="text-start py-3 font-medium">{t('common.sector')}</th>
                <th className="text-end py-3 font-medium">{t('common.amount')}</th>
                <th className="text-end py-3 font-medium">{t('investor.calc_rate')}</th>
                <th className="text-end py-3 font-medium">{t('common.tenure')}</th>
                <th className="text-end py-3 font-medium">{t('common.status')}</th>
              </tr>
            </thead>
            <tbody>
              {investments.slice(0, 6).map((i) => (
                <tr key={i.id} className="border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors">
                  <td className="py-3 font-mono text-xs text-muted-foreground">{i.id}</td>
                  <td className="py-3 font-medium text-foreground">{i.name}</td>
                  <td className="py-3"><StatusPill tone="gold">{t(`sectors.${i.sector}`)}</StatusPill></td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(i.amount)}</td>
                  <td className="py-3 text-end num-display">{i.rate}%</td>
                  <td className="py-3 text-end num-display">{i.tenure}m</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={i.status === 'active' ? 'success' : 'info'}>{t(`common.${i.status}`)}</StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};
