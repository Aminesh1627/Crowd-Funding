import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { GlassCard, SectionHeader, RiskBadge, StatusPill } from '@/components/Primitives';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  ArrowLeft, MapPin, Calendar, Building2, FileText, ShieldCheck,
  TrendingUp, Wallet, CheckCircle2,
} from 'lucide-react';
import { RAWAFID } from '@/constants/testIds';
import { toast } from 'sonner';

export const CampaignDetail = () => {
  const { t, fmtCurrency } = useI18n();
  const { id } = useParams();
  const navigate = useNavigate();
  const { campaigns, investInCampaign, wallet } = useStore();
  const { onboarding } = useAuth();

  const c = campaigns.find((x) => x.id === id);
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(500);
  const [submitting, setSubmitting] = useState(false);

  if (!c) {
    return (
      <div className="p-12 text-center">
        <div className="text-muted-foreground">Campaign not found.</div>
        <Button className="mt-4" onClick={() => navigate('/app/marketplace')}>{t('common.back_to_home')}</Button>
      </div>
    );
  }

  const pct = Math.round((c.raised / c.target) * 100);
  const monthly = amount ? Math.round((amount * (c.rate / 100)) / 12) : 0;
  const totalProfit = amount ? Math.round((amount * (c.rate / 100)) * (c.tenure / 12)) : 0;
  const onboardingDone = onboarding?.investor?.completedAt;

  const handleInvest = () => {
    if (!onboardingDone) {
      toast.warning(t('investor.onboarding_required'));
      navigate('/onboarding');
      return;
    }
    if (amount > wallet.available) {
      toast.error('Insufficient wallet balance. Please fund your wallet first.');
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      investInCampaign(c.id, amount);
      setSubmitting(false);
      setOpen(false);
      toast.success(t('investor.invest_confirm'));
    }, 700);
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={() => navigate('/app/marketplace')} className="rounded-full">
        <ArrowLeft className="me-1 w-4 h-4 rtl-flip" /> {t('investor.marketplace')}
      </Button>

      {/* Hero */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-primary p-8 lg:p-10 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_85%_15%,hsl(40_80%_60%/0.35),transparent_55%)]" />
        <div className="relative grid lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7">
            <div className="flex items-center gap-2 mb-3">
              <RiskBadge grade={c.riskGrade} />
              <StatusPill tone="gold">{t(`sectors.${c.sector}`)}</StatusPill>
              <span className="text-xs text-white/70 flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {c.region}</span>
              <span className="text-xs text-white/70 flex items-center gap-1.5"><Building2 className="w-3 h-3" /> Est. {c.established}</span>
            </div>
            <div className="text-xs uppercase tracking-[0.22em] text-accent/90 mb-2">{c.id} · {c.borrower}</div>
            <h1 className="font-serif-display text-3xl lg:text-4xl text-white leading-tight">{c.title}</h1>
            <p className="mt-4 text-white/80 max-w-2xl leading-relaxed">{c.summary}</p>
            <div className="mt-7 flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20">
                <ShieldCheck className="w-3.5 h-3.5 text-accent" /> 4-eyes approved
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20">
                <Calendar className="w-3.5 h-3.5 text-accent" /> {c.daysLeft} {t('common.days')} {t('investor.days_left').toLowerCase()}
              </div>
            </div>
          </div>
          <div className="lg:col-span-5">
            <div className="glass-dark rounded-xl p-6">
              <div className="grid grid-cols-2 gap-5">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/60 mb-1">{t('investor.campaign_target')}</div>
                  <div className="font-serif-display text-2xl text-white num-display">{fmtCurrency(c.target)}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/60 mb-1">{t('investor.funded')}</div>
                  <div className="font-serif-display text-2xl gradient-text-gold num-display">{fmtCurrency(c.raised)}</div>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs text-white/70 mb-1.5">
                  <span>{pct}% {t('investor.funded')}</span>
                  <span>{c.investors} investors</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-gradient-gold" style={{ width: `${pct}%` }} />
                </div>
              </div>
              <div className="divider-gold my-5" />
              <div className="grid grid-cols-3 gap-3 text-center">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/60">{t('investor.expected_return')}</div>
                  <div className="font-serif-display text-xl text-accent num-display">{c.rate}%</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/60">{t('common.tenure')}</div>
                  <div className="font-serif-display text-xl text-white num-display">{c.tenure}m</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-white/60">{t('investor.days_left')}</div>
                  <div className="font-serif-display text-xl text-white num-display">{c.daysLeft || '—'}</div>
                </div>
              </div>
              <Button
                data-testid={RAWAFID.investNowButton}
                onClick={() => setOpen(true)}
                disabled={c.stage !== 'funding'}
                className="w-full mt-6 h-12 bg-accent text-accent-foreground hover:bg-accent/90 rounded-full font-semibold shadow-gold"
              >
                <TrendingUp className="me-1 w-4 h-4" /> {t('investor.invest_now')}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker={t('investor.about_borrower')} title={c.borrower} />
          <p className="text-sm text-foreground/80 leading-relaxed">{c.summary}</p>
          <div className="mt-6 grid sm:grid-cols-2 gap-4">
            <DetailRow label="Sector" value={t(`sectors.${c.sector}`)} />
            <DetailRow label="Region" value={c.region} />
            <DetailRow label="Established" value={c.established} />
            <DetailRow label="Purpose" value={c.purpose} />
          </div>

          <div className="mt-8">
            <SectionHeader kicker={t('investor.financial_snapshot')} title={t('investor.risk_profile')} />
            <div className="grid sm:grid-cols-4 gap-3">
              <MetricBox label="DSCR" value={c.metrics.dscr} />
              <MetricBox label="DTI" value={c.metrics.dti} />
              <MetricBox label="LTV" value={c.metrics.ltv} />
              <MetricBox label="Score" value={c.metrics.creditScore} />
            </div>
          </div>

          <div className="mt-8">
            <SectionHeader kicker={t('investor.docs_disclosures')} title="Documents" />
            <div className="grid sm:grid-cols-2 gap-3">
              {['Audited financials FY24', 'CR Certificate', 'Bank statements (6m)', 'Board resolution'].map((d) => (
                <div key={d} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-accent" />
                    <span className="text-sm">{d}</span>
                  </div>
                  <Button size="sm" variant="ghost">{t('common.download')}</Button>
                </div>
              ))}
            </div>
          </div>
        </GlassCard>

        <GlassCard>
          <SectionHeader kicker={t('investor.returns_calc')} title="Estimate returns" />
          <div className="space-y-4">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.calc_invest')}</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent/40 num-display"
              />
            </div>
            <Stat label={t('investor.calc_rate')} value={`${c.rate}%`} />
            <Stat label={t('investor.calc_tenure')} value={`${c.tenure} ${t('common.months')}`} />
            <div className="rounded-lg p-4 bg-gradient-subtle border border-border space-y-2">
              <Stat label={t('investor.calc_monthly')} value={fmtCurrency(monthly)} accent />
              <Stat label={t('investor.calc_total_profit')} value={fmtCurrency(totalProfit)} accent />
              <Stat label={t('investor.calc_irr')} value={`${(c.rate * 1.05).toFixed(2)}%`} accent />
            </div>
            <Button
              onClick={() => setOpen(true)}
              className="w-full bg-primary hover:bg-primary/90 rounded-full h-11 font-semibold"
            >
              {t('investor.invest_now')}
            </Button>
          </div>
        </GlassCard>
      </div>

      {/* Invest dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif-display text-2xl text-primary">{t('investor.review_invest')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.id} · {c.borrower}</div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground block mb-1">{t('investor.investment_amount')}</label>
              <input
                data-testid={RAWAFID.investAmountInput}
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-accent/40 num-display"
              />
              <div className="text-[11px] text-muted-foreground mt-1.5 flex items-center gap-1">
                <Wallet className="w-3 h-3" /> Available: {fmtCurrency(wallet.available)}
              </div>
            </div>
            <div className="rounded-lg p-4 bg-muted/40 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">{t('investor.expected_return')}</span><span className="font-semibold">{c.rate}%</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('common.tenure')}</span><span className="font-semibold">{c.tenure}m</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{t('investor.calc_monthly')}</span><span className="font-semibold">{fmtCurrency(monthly)}</span></div>
              <div className="flex justify-between border-t pt-2"><span className="font-semibold">{t('investor.calc_total_profit')}</span><span className="font-bold text-accent">{fmtCurrency(totalProfit)}</span></div>
            </div>
            <Button
              data-testid={RAWAFID.investConfirm}
              disabled={submitting}
              onClick={handleInvest}
              className="w-full bg-primary hover:bg-primary/90 rounded-full h-11 font-semibold"
            >
              {submitting ? t('common.loading') : (<><CheckCircle2 className="me-1 w-4 h-4" /> {t('investor.confirm_invest')}</>)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const DetailRow = ({ label, value }) => (
  <div className="flex justify-between p-3 rounded-lg bg-muted/40 text-sm">
    <span className="text-muted-foreground">{label}</span>
    <span className="font-medium text-foreground">{value}</span>
  </div>
);

const MetricBox = ({ label, value }) => (
  <div className="rounded-lg border border-border bg-card p-4 text-center">
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    <div className="font-serif-display text-xl text-primary num-display mt-1">{value}</div>
  </div>
);

const Stat = ({ label, value, accent }) => (
  <div className="flex items-center justify-between text-sm">
    <span className="text-muted-foreground">{label}</span>
    <span className={`num-display font-semibold ${accent ? 'text-primary' : 'text-foreground'}`}>{value}</span>
  </div>
);

export default CampaignDetail;
