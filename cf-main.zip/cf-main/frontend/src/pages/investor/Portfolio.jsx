import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useI18n } from '@/context/I18nContext';
import { useStore } from '@/context/DemoStoreContext';
import { GlassCard, SectionHeader, StatusPill, KpiTile } from '@/components/Primitives';
import { PieAllocChart, ProfitAreaChart } from '@/components/Charts';
import { monthlyReturnSeries, industryAlloc } from '@/data/mockData';
import { distributionsFor } from '@/data/mockDataV2';
import { Coins, TrendingUp, ListChecks, Calendar } from 'lucide-react';

export const Portfolio = () => {
  const { t, fmtCurrency } = useI18n();
  const { investments } = useStore();
  const navigate = useNavigate();

  const totalInvested = investments.filter((i) => i.status === 'active').reduce((s, i) => s + i.amount, 0);
  const expectedProfit = investments.reduce((s, i) => s + (i.amount * (i.rate / 100) * (i.tenure / 12)), 0);

  // Generate monthly distributions across all active investments
  const distributions = useMemo(() => {
    return investments
      .filter((i) => i.status === 'active')
      .flatMap((i) => distributionsFor(i, 2))
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [investments]);

  const nextDue = distributions.find((d) => d.status === 'pending');

  return (
    <div className="space-y-6">
      <div>
        <div className="text-[11px] uppercase tracking-[0.22em] text-accent font-semibold mb-1">
          {t('investor.portfolio_title')}
        </div>
        <h1 className="font-serif-display text-3xl text-primary">My Portfolio</h1>
        <p className="text-sm text-muted-foreground mt-1">One-time investments with monthly profit + principal distributions credited to your wallet.</p>
      </div>

      <div className="grid sm:grid-cols-4 gap-4">
        <KpiTile label={t('investor.kpi_portfolio')} value={fmtCurrency(totalInvested)} icon={Coins} accent />
        <KpiTile label="Expected Profit" value={fmtCurrency(Math.round(expectedProfit))} delta={{ value: 6.4, label: 'YoY' }} icon={TrendingUp} />
        <KpiTile label={t('investor.kpi_active_inv')} value={investments.filter((i) => i.status === 'active').length} icon={ListChecks} />
        <KpiTile label={t('distributions.next_distribution')} value={nextDue ? fmtCurrency(nextDue.total) : '—'} sub={nextDue?.date || '—'} icon={Calendar} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="lg:col-span-2">
          <SectionHeader kicker={t('common.overview')} title={t('investor.return_trend')} />
          <ProfitAreaChart data={monthlyReturnSeries} />
        </GlassCard>
        <GlassCard>
          <SectionHeader kicker={t('investor.industry_dist')} title="Diversification" />
          <PieAllocChart data={industryAlloc} />
        </GlassCard>
      </div>

      <GlassCard>
        <SectionHeader kicker={t('investor.portfolio_title')} title="All investments" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">ID</th>
                <th className="text-start py-3">Campaign</th>
                <th className="text-start py-3">{t('common.sector')}</th>
                <th className="text-end py-3">{t('common.amount')}</th>
                <th className="text-end py-3">Rate</th>
                <th className="text-end py-3">{t('common.tenure')}</th>
                <th className="text-end py-3">{t('common.date')}</th>
                <th className="text-end py-3">{t('common.status')}</th>
              </tr>
            </thead>
            <tbody>
              {investments.map((i) => (
                <tr key={i.id} className="border-b border-border last:border-b-0 hover:bg-muted/40 cursor-pointer" onClick={() => navigate(`/app/marketplace/${i.campaignId}`)}>
                  <td className="py-3 font-mono text-xs text-muted-foreground">{i.id}</td>
                  <td className="py-3 font-medium">{i.name}</td>
                  <td className="py-3"><StatusPill tone="gold">{t(`sectors.${i.sector}`)}</StatusPill></td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(i.amount)}</td>
                  <td className="py-3 text-end num-display">{i.rate}%</td>
                  <td className="py-3 text-end num-display">{i.tenure}m</td>
                  <td className="py-3 text-end text-muted-foreground">{i.invested}</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={i.status === 'active' ? 'success' : 'info'}>{t(`common.${i.status}`)}</StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <GlassCard>
        <SectionHeader kicker={t('distributions.title')} title={t('distributions.subtitle')} />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-start py-3">Campaign</th>
                <th className="text-start py-3">Month</th>
                <th className="text-end py-3">{t('common.date')}</th>
                <th className="text-end py-3">{t('distributions.profit')}</th>
                <th className="text-end py-3">{t('distributions.principal')}</th>
                <th className="text-end py-3">{t('distributions.total')}</th>
                <th className="text-end py-3">{t('common.status')}</th>
              </tr>
            </thead>
            <tbody>
              {distributions.slice(0, 18).map((d) => (
                <tr key={d.id} className="border-b border-border last:border-b-0 hover:bg-muted/40">
                  <td className="py-3 font-mono text-xs">{d.campaignId}</td>
                  <td className="py-3">#{d.month}</td>
                  <td className="py-3 text-end text-muted-foreground">{d.date}</td>
                  <td className="py-3 text-end num-display">{fmtCurrency(d.profit)}</td>
                  <td className="py-3 text-end num-display">{fmtCurrency(d.principal)}</td>
                  <td className="py-3 text-end num-display font-semibold">{fmtCurrency(d.total)}</td>
                  <td className="py-3 text-end">
                    <StatusPill tone={d.status === 'paid' ? 'success' : 'info'}>{t(`distributions.${d.status}`)}</StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export default Portfolio;
