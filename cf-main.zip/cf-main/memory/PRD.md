# Rawafid — Premium P2P Crowdfunding Prototype (Phase 1)

## Original Problem Statement
Frontend-only Phase-1 prototype of "Rawafid" — a Sultanate of Oman P2P crowdfunding platform, suitable for an institutional client demo. Premium fintech navy + royal gold visual identity, full EN ↔ AR with RTL layout flip, top-bar role switcher across 4 portals, all data mocked in `localStorage`.

## Architecture
React 19 + CRA + Tailwind + Shadcn UI + Recharts + Sonner + react-router-dom v7. No backend.

```
/app/frontend/src/
  App.js                          # full routing tree
  index.css / tailwind.config.js  # design tokens
  context/
    I18nContext.jsx               # EN/AR + RTL + Intl. Deep-merges base translations with overlay v2.
    AuthContext.jsx               # 4-role mock auth + onboarding state
    DemoStoreContext.jsx          # global wrapper for useDemoStore
  hooks/useDemoStore.js           # campaigns, investments, escrow ledger, tickets, decision rules,
                                  # roles/groups, loan/doc/lang master data, law suite — all in localStorage,
                                  # actions: invest, createCampaign, decideCampaign, fundWallet,
                                  # withdrawFromWallet, submitTicket, updateDecisionRule, addDecisionRule, resetDemo
  data/
    translations.js + translations_v2.js  (deep-merged)
    mockData.js + mockDataV2.js
  components/
    Logo · LangToggle · RoleSwitcher · NotificationBell · UserMenu
    Sidebar (grouped per-role nav) · AppHeader (right-aligned)
    SlideOver (right-side panel) · Charts · Primitives · ProtectedRoute
  layouts/AppShell.jsx
  pages/
    Landing · Login · Onboarding · Dashboard (role router) · Profile
    investor/{Dashboard,Marketplace,CampaignDetail,Portfolio}
    borrower/{Dashboard,CreateCampaign,MyCampaigns,Repayments,SubscriptionDecisions}
    admin/{Dashboard,ReviewQueue,Officers,Workflow,DecisionEngine,Manage,MasterData}
    regulator/{Dashboard,Compliance,AuditLogs,LawSuite}
    shared/{WalletPage,SupportPage}
```

## What's been implemented

### v1 (initial release)
- Premium fintech design system (navy + gold, glass, grain, arabesque)
- Bilingual EN ↔ AR with full RTL flip
- Mock login → role picker → role-aware redirect
- Top-bar 4-portal switcher
- Premium landing page (hero · how-it-works · pillars · marketplace · testimonials · FAQ · CTA)
- 6-step investor onboarding (personal → suitability → KYC → AML → wallet → done)
- Per-role dashboards with KPIs and Recharts visualisations
- Investor: marketplace + filters + campaign detail + invest dialog + portfolio
- Campaign Creator: 4-step create wizard + my campaigns
- Admin: review queue with decision dialog
- Regulator: compliance flags + audit logs
- Notification center (bell + sonner toasts)
- Profile page with onboarding status & demo-reset

### v2 (Feb 2026 — current batch)
- Login: **Back to home** link
- Header: dropped wide search; cluster (lang/bell/role-switcher/user) right-aligned
- **Investor**:
  - Sidebar: new **Escrow Wallet** + **Support** items; removed top-level Users
  - Dashboard "Fund Wallet" navigates to dedicated wallet page
  - **/app/wallet** — Escrow Wallet with KPIs, fund/withdraw dialogs, escrow account card with mocked IBAN/SWIFT, lifetime transaction ledger
  - **Marketplace**: inline **Return Calculator** widget (amount/rate/tenure → monthly + total profit)
  - **Portfolio**: replaced "repayments" with **Monthly distributions** (one-time investment, monthly profit + principal payouts), added "Next distribution" KPI
  - **Profile**: filled blank space with Bank Account panel (Bank Muscat, IBAN, SWIFT) + Escrow Account card + Notification preferences switches
- **Campaign Creator**:
  - Sidebar: new **Repayments** + **Subscription Decisions** + **Support** items
  - **/app/repayments**: 4 KPIs (outstanding/paid/next-due/overdue), expandable per-campaign installment schedule with Pay Now, Restructure dialog, Early Settlement dialog
  - **/app/subscription**: oversubscription decisions per campaign (Accept all / Accept up to target / Reject excess)
  - Profile: Bank Dhofar + Escrow `OM-RWF-ESC-BOR-` account
- **Platform Admin** (big restructure):
  - Sidebar grouped: Dashboard / Create Campaign / Marketplace · **Officers** (Credit / Risk / Onboarding / Compliance & Committee) · **Workflow & Engine** · **Administration** (Manage Users / Roles / Groups) · **Master Data** (Loan Types / Document Types / Language Settings)
  - Removed top-level Profile + Users
  - **Officer pages**: queue table → right-side **SlideOver panel** with Ma'la'a credit pull (CB score, status, exposure, delinquent, inquiries, as-of), policy checks (pass/warn/fail), scorecard (factor/weight/score/contribution + composite), conditions adder, reviewer comments, Approve / Reject / Escalate / Clarify
  - **Workflow page**: 9-stage pipeline diagram + flags trend
  - **Decision Engine**: 4 category tabs, editable rule table (toggle on/off, edit threshold/weight, add new rule), scorecard simulator
  - **Manage Users / Roles / Groups** screens
  - **Master Data**: Loan Types (toggle enabled), Document Types, Language Settings (coverage bars)
- **Regulator**:
  - Sidebar: added **Law Suite** entry
  - **/app/law-suite**: 5 KPIs + cases table with stage filter + search
  - **/app/compliance**: per-flag SlideOver review panel with Summary / Evidence / Timeline / Actions and Escalate / Attach / Close
  - Profile: filled with "Access & responsibilities" panel + Bank/Escrow + Preferences
- Wallet ledger rows and notification preference switches all have data-testids

### Testing status
- iteration_1.json (v1): 100 % of requested flows verified, no critical bugs.
- iteration_2.json (v2): 40/43 (~93 %) assertions passed. The 3 minor issues raised have been fixed in this session:
  - Admin / Regulator sidebar first item renamed to **Dashboard** per spec
  - Slide-over footer right-padded so the Emergent badge no longer covers the Approve button (verified manually: queue 4→3 after approve + success toast)
  - Wallet ledger rows + preference switches now carry per-row data-testids
- Production-ready prototype quality.

## Backlog / Roadmap

### P1
- Real FastAPI + Mongo backend, replace localStorage mocks
- Real authentication (Emergent Google OAuth or JWT)
- Stripe / Thawani wallet top-ups
- Email/SMS notifications (SendGrid / Twilio)
- Live Ma'la'a (Oman Credit Bureau) API integration

### P2
- Islamic finance compliance toggle (Mudarabah / Musharakah) — explicitly deferred
- Multi-currency display (OMR + USD)
- Mobile-first responsive polish
- Voting center for investor restructure votes

## Tech stack notes
- No backend services used or required.
- All charts themed with palette tokens (gold `#d4a23a`, navy `#1d3a66`, emerald `#2d6a4f`).
- Hero image: Unsplash architectural backdrop.
